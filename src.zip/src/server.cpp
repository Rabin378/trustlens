// server.cpp
// -----------------------------------------------------------------------------
//  TrustLens WEB SERVER  -  the backend of the website (pure C++17)
//
//  What it does
//    * serves the website files from web/   (HTML, CSS, JavaScript)
//    * exposes a JSON API under /api/...    (used by the website's JavaScript)
//    * runs the trained machine learning models on demand
//    * reads / writes the SQLite database created by `./trustlens run`
//
//  Start it:      ./trustlens_server            then open  http://127.0.0.1:8080
//  Options:       ./trustlens_server 9000 --host 0.0.0.0 --web web --db db/trustlens.db
//
//  API overview
//    GET  /api/health                 server + model status
//    GET  /api/overview               headline numbers
//    GET  /api/analytics              data for the dashboard charts
//    GET  /api/models                 model leaderboard, importance, top words
//    GET  /api/roc?task=&model=       ROC curve points
//    GET  /api/examples               random sample inputs for the scanner
//    POST /api/scan-url   {"url":..}  classify a URL
//    POST /api/check-news {"text":..} classify an article
//    GET  /api/history                recent scans
//    GET  /api/data/news|urls         browse the dataset (search, filters, paging)
//    GET  /api/data/news/<id>         one article + model predictions
//    GET  /api/data/urls/<id>         one URL + its features + predictions
//    GET  /api/sql-lab[/<n>]          list / run the prepared analysis queries
// -----------------------------------------------------------------------------

#include <sqlite3.h>

#include <variant>

#include "../include/common.hpp"
#include "../include/csv.hpp"
#include "../include/http.hpp"
#include "../include/json.hpp"
#include "../include/models.hpp"
#include "../include/sqlstore.hpp"
#include "../include/text.hpp"
#include "../include/url_features.hpp"

using namespace tl;

namespace {

// =============================================================================
//  Database helper (SQLite with bound parameters -> no SQL injection)
// =============================================================================

using Param = std::variant<std::string, long long, double>;
using Params = std::vector<Param>;

std::string cell_json(sqlite3_stmt* st, int c) {
    switch (sqlite3_column_type(st, c)) {
        case SQLITE_INTEGER: return std::to_string(sqlite3_column_int64(st, c));
        case SQLITE_FLOAT: return jnum(sqlite3_column_double(st, c));
        case SQLITE_TEXT: return jstr(reinterpret_cast<const char*>(sqlite3_column_text(st, c)));
        default: return "null";
    }
}

class Db {
public:
    bool open(const std::string& path) {
        if (!std::filesystem::exists(path)) return false;
        if (sqlite3_open_v2(path.c_str(), &db_, SQLITE_OPEN_READWRITE | SQLITE_OPEN_FULLMUTEX, nullptr) != SQLITE_OK) return false;
        sqlite3_busy_timeout(db_, 3000);
        exec("CREATE TABLE IF NOT EXISTS scan_history ("
             "scan_id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, input TEXT NOT NULL, "
             "verdict TEXT NOT NULL, score REAL NOT NULL, scanned_at TEXT NOT NULL);");
        return true;
    }

    void exec(const std::string& sql, const Params& ps = {}) {
        std::lock_guard<std::mutex> lk(m_);
        sqlite3_stmt* st = prepare(sql, ps);
        if (!st) return;
        while (sqlite3_step(st) == SQLITE_ROW) {}
        sqlite3_finalize(st);
    }

    // [ {col: value, ...}, ... ]
    std::string rows_json(const std::string& sql, const Params& ps = {}) {
        std::lock_guard<std::mutex> lk(m_);
        sqlite3_stmt* st = prepare(sql, ps);
        if (!st) return "[]";
        std::string out = "[";
        int cols = sqlite3_column_count(st);
        bool first = true;
        while (sqlite3_step(st) == SQLITE_ROW) {
            if (!first) out += ",";
            first = false;
            out += "{";
            for (int c = 0; c < cols; ++c) {
                if (c) out += ",";
                out += jstr(sqlite3_column_name(st, c)) + ":" + cell_json(st, c);
            }
            out += "}";
        }
        sqlite3_finalize(st);
        return out + "]";
    }

    // one object, or null when there is no row
    std::string first_json(const std::string& sql, const Params& ps = {}) {
        std::string arr = rows_json(sql, ps);
        if (arr.size() < 3) return "null";
        int depth = 0;
        for (size_t i = 1; i < arr.size(); ++i) {   // cut the first {...} out of [ {...}, {...} ]
            if (arr[i] == '"') { for (++i; i < arr.size() && arr[i] != '"'; ++i) if (arr[i] == '\\') ++i; }
            else if (arr[i] == '{') ++depth;
            else if (arr[i] == '}' && --depth == 0) return arr.substr(1, i);
        }
        return "null";
    }

    // {"columns":[...], "rows":[[...],...]} for the SQL Lab page
    std::string table_json(const std::string& sql) {
        std::lock_guard<std::mutex> lk(m_);
        sqlite3_stmt* st = prepare(sql, {});
        if (!st) return "{\"columns\":[],\"rows\":[]}";
        int cols = sqlite3_column_count(st);
        std::string out = "{\"columns\":[";
        for (int c = 0; c < cols; ++c) out += (c ? "," : "") + jstr(sqlite3_column_name(st, c));
        out += "],\"rows\":[";
        bool first = true;
        int count = 0;
        while (sqlite3_step(st) == SQLITE_ROW && count++ < 500) {
            if (!first) out += ",";
            first = false;
            out += "[";
            for (int c = 0; c < cols; ++c) out += (c ? "," : "") + cell_json(st, c);
            out += "]";
        }
        sqlite3_finalize(st);
        return out + "]}";
    }

    long long scalar(const std::string& sql, const Params& ps = {}) {
        std::lock_guard<std::mutex> lk(m_);
        sqlite3_stmt* st = prepare(sql, ps);
        if (!st) return 0;
        long long v = 0;
        if (sqlite3_step(st) == SQLITE_ROW) v = sqlite3_column_int64(st, 0);
        sqlite3_finalize(st);
        return v;
    }

private:
    sqlite3_stmt* prepare(const std::string& sql, const Params& ps) {
        sqlite3_stmt* st = nullptr;
        if (sqlite3_prepare_v2(db_, sql.c_str(), -1, &st, nullptr) != SQLITE_OK) {
            std::cerr << "  [sql error] " << sqlite3_errmsg(db_) << "\n";
            return nullptr;
        }
        int i = 1;
        for (const auto& p : ps) {
            if (auto s = std::get_if<std::string>(&p)) sqlite3_bind_text(st, i, s->c_str(), -1, SQLITE_TRANSIENT);
            else if (auto n = std::get_if<long long>(&p)) sqlite3_bind_int64(st, i, *n);
            else sqlite3_bind_double(st, i, std::get<double>(p));
            ++i;
        }
        return st;
    }
    sqlite3* db_ = nullptr;
    std::mutex m_;
};

// =============================================================================
//  Application state (models + database)
// =============================================================================

struct UrlModel {
    StandardScaler scaler;
    LogisticRegression lr;
    RandomForest forest;
};

struct App {
    Db db;
    std::string web_dir = "web";
    UrlModel url_model;
    bool url_ok = false;
    TfidfVectorizer vec;
    LogisticRegression news_lr;
    bool news_ok = false;
    std::vector<std::pair<std::string, std::string>> queries;   // SQL Lab
} app;

// ---- helpers ----------------------------------------------------------------

std::string round1(double v) { return jnum(std::round(v * 10.0) / 10.0); }

std::string cut_utf8(const std::string& s, size_t max_bytes) {
    if (s.size() <= max_bytes) return s;
    size_t n = max_bytes;
    while (n > 0 && (static_cast<unsigned char>(s[n]) & 0xC0) == 0x80) --n;   // don't split a character
    return s.substr(0, n);
}

std::string like_escape(const std::string& s) {
    std::string o;
    for (char c : s) { if (c == '%' || c == '_' || c == '\\') o += '\\'; o += c; }
    return o;
}

long long to_int(const std::string& s, long long def, long long lo, long long hi) {
    if (s.empty()) return def;
    char* end = nullptr;
    long long v = std::strtoll(s.c_str(), &end, 10);
    if (end == s.c_str()) return def;
    return std::max(lo, std::min(hi, v));
}


void log_scan(const std::string& kind, const std::string& input, const std::string& verdict, double score) {
    app.db.exec("INSERT INTO scan_history (kind, input, verdict, score, scanned_at) VALUES (?, ?, ?, ?, ?)",
                {kind, cut_utf8(input, 300), verdict, std::round(score * 10.0) / 10.0, now_string()});
}

// =============================================================================
//  API handlers
// =============================================================================

void h_health(const Request&, Response& res) {
    res.json("{\"status\":\"ok\",\"time\":" + jstr(now_string()) + ",\"models\":{\"url\":" + jbool(app.url_ok) +
             ",\"news\":" + jbool(app.news_ok) + "}}");
}

void h_overview(const Request&, Response& res) {
    long long articles = app.db.scalar("SELECT COUNT(*) FROM news_articles");
    long long urls = app.db.scalar("SELECT COUNT(*) FROM urls");
    long long fake = app.db.scalar("SELECT COUNT(*) FROM news_articles WHERE label = 1");
    long long phish = app.db.scalar("SELECT COUNT(*) FROM urls WHERE label = 1");
    long long scans = app.db.scalar("SELECT COUNT(*) FROM scan_history");
    std::string best = app.db.rows_json(
        "SELECT task, model, ROUND(f1, 4) AS f1, ROUND(accuracy, 4) AS accuracy, ROUND(auc, 4) AS auc "
        "FROM model_runs m WHERE f1 = (SELECT MAX(f1) FROM model_runs WHERE task = m.task) ORDER BY task");
    res.json("{\"articles\":" + std::to_string(articles) + ",\"urls\":" + std::to_string(urls) +
             ",\"fake_pct\":" + round1(articles ? 100.0 * fake / articles : 0) +
             ",\"phishing_pct\":" + round1(urls ? 100.0 * phish / urls : 0) +
             ",\"scans\":" + std::to_string(scans) + ",\"best_models\":" + best + "}");
}

void h_analytics(const Request&, Response& res) {
    auto& db = app.db;
    std::string j = "{";
    j += "\"news_by_source\":" + db.rows_json(
        "SELECT source, COUNT(*) AS articles, ROUND(100.0 * AVG(label), 1) AS pct_fake FROM news_articles "
        "GROUP BY source ORDER BY pct_fake DESC");
    j += ",\"news_by_subject\":" + db.rows_json(
        "SELECT subject, COUNT(*) AS articles, ROUND(100.0 * AVG(label), 1) AS pct_fake FROM news_articles "
        "GROUP BY subject ORDER BY articles DESC");
    j += ",\"news_by_year\":" + db.rows_json(
        "SELECT strftime('%Y', published_date) AS year, SUM(label = 0) AS real_articles, SUM(label = 1) AS fake_articles "
        "FROM news_articles GROUP BY year ORDER BY year");
    j += ",\"news_style\":" + db.rows_json(
        "SELECT CASE label WHEN 1 THEN 'fake' ELSE 'real' END AS class, ROUND(AVG(word_count), 1) AS avg_words, "
        "ROUND(AVG(exclamation_count), 2) AS avg_exclamations, ROUND(100 * AVG(caps_ratio), 2) AS avg_caps_pct "
        "FROM news_articles GROUP BY label ORDER BY label");
    j += ",\"urls_by_tld\":" + db.rows_json(
        "SELECT tld, COUNT(*) AS urls, ROUND(100.0 * AVG(label), 1) AS pct_phishing FROM urls "
        "GROUP BY tld HAVING COUNT(*) >= 25 ORDER BY urls DESC LIMIT 12");
    j += ",\"url_features\":" + db.rows_json(
        "SELECT CASE u.label WHEN 1 THEN 'phishing' ELSE 'legitimate' END AS class, "
        "ROUND(AVG(f.url_length), 1) AS avg_length, ROUND(AVG(f.keyword_count), 2) AS avg_keywords, "
        "ROUND(100 * AVG(f.uses_https), 1) AS pct_https, ROUND(100 * AVG(f.has_ip_host), 1) AS pct_ip_host, "
        "ROUND(100 * AVG(f.brand_mismatch), 1) AS pct_brand_mismatch, ROUND(100 * AVG(f.suspicious_tld), 1) AS pct_bad_tld "
        "FROM urls u JOIN url_features f ON f.url_id = u.url_id GROUP BY u.label ORDER BY u.label");
    j += ",\"news_balance\":" + db.rows_json(
        "SELECT CASE label WHEN 1 THEN 'fake' ELSE 'real' END AS class, COUNT(*) AS n FROM news_articles GROUP BY label ORDER BY label");
    j += ",\"url_balance\":" + db.rows_json(
        "SELECT CASE label WHEN 1 THEN 'phishing' ELSE 'legitimate' END AS class, COUNT(*) AS n FROM urls GROUP BY label ORDER BY label");
    j += ",\"scans_by_verdict\":" + db.rows_json(
        "SELECT kind, verdict, COUNT(*) AS n FROM scan_history GROUP BY kind, verdict ORDER BY kind, n DESC");
    res.json(j + "}");
}

void h_models(const Request&, Response& res) {
    std::string j = "{\"runs\":" + app.db.rows_json(
        "SELECT run_id, task, model, ROUND(accuracy,4) AS accuracy, ROUND(precision_score,4) AS precision, "
        "ROUND(recall_score,4) AS recall, ROUND(f1,4) AS f1, ROUND(auc,4) AS auc, ROUND(cv_f1_mean,4) AS cv_f1_mean, "
        "ROUND(cv_f1_sd,4) AS cv_f1_sd, tp, fp, tn, fn, trained_at FROM model_runs ORDER BY task, f1 DESC");

    j += ",\"url_importance\":[";
    try {
        Row h;
        auto rows = read_csv("results/url_importance.csv", h);
        for (size_t i = 0; i < rows.size(); ++i)
            j += (i ? "," : "") + std::string("{\"feature\":") + jstr(rows[i][0]) + ",\"importance\":" + rows[i][1] + "}";
    } catch (...) {}
    j += "],\"news_words\":[";
    try {
        Row h;
        auto rows = read_csv("results/news_words.csv", h);
        for (size_t i = 0; i < rows.size(); ++i)
            j += (i ? "," : "") + std::string("{\"term\":") + jstr(rows[i][0]) + ",\"weight\":" + rows[i][1] +
                 ",\"direction\":" + jstr(rows[i][2]) + "}";
    } catch (...) {}
    res.json(j + "]}");
}

void h_roc(const Request& req, Response& res) {
    std::string task = req.param("task"), model = req.param("model");
    if (task != "fake_news" && task != "phishing") { res.error(400, "unknown task"); return; }
    std::string safe = to_lower(model);
    for (auto& c : safe) if (!std::isalnum(static_cast<unsigned char>(c))) c = '_';
    std::string path = "results/roc_" + task + "_" + safe + ".csv";
    if (!std::filesystem::exists(path)) { res.error(404, "no ROC data for that model"); return; }
    Row h;
    auto rows = read_csv(path, h);
    const size_t max_pts = 150;
    std::string j = "{\"points\":[";
    size_t step = std::max<size_t>(1, rows.size() / max_pts);
    bool first = true;
    for (size_t i = 0; i < rows.size(); i += step) {
        if (!first) j += ",";
        first = false;
        j += "[" + rows[i][0] + "," + rows[i][1] + "]";
    }
    if (!rows.empty() && (rows.size() - 1) % step != 0) j += ",[" + rows.back()[0] + "," + rows.back()[1] + "]";
    res.json(j + "]}");
}

void h_examples(const Request&, Response& res) {
    auto& db = app.db;
    res.json("{\"phishing\":" + db.rows_json("SELECT url FROM urls WHERE label = 1 ORDER BY RANDOM() LIMIT 4") +
             ",\"legit\":" + db.rows_json("SELECT url FROM urls WHERE label = 0 ORDER BY RANDOM() LIMIT 4") +
             ",\"fake\":" + db.rows_json("SELECT title, body AS text FROM news_articles WHERE label = 1 ORDER BY RANDOM() LIMIT 2") +
             ",\"real\":" + db.rows_json("SELECT title, body AS text FROM news_articles WHERE label = 0 ORDER BY RANDOM() LIMIT 2") + "}");
}

void h_history(const Request& req, Response& res) {
    long long limit = to_int(req.param("limit"), 10, 1, 100);
    res.json("{\"scans\":" + app.db.rows_json(
        "SELECT scan_id, kind, substr(input, 1, 110) AS input, verdict, score, scanned_at "
        "FROM scan_history ORDER BY scan_id DESC LIMIT ?", {limit}) + "}");
}

// ---- URL scanner --------------------------------------------------------------

void h_scan_url(const Request& req, Response& res) {
    if (!app.url_ok) { res.error(503, "The phishing model is not trained yet. Run ./trustlens run first."); return; }
    std::string url;
    if (!json_get_string(req.body, "url", url)) { res.error(400, "Please send a JSON body like {\"url\": \"https://...\"}"); return; }
    url = trim(url);
    bool has_space = url.find_first_of(" \t\r\n") != std::string::npos;
    if (url.size() < 4 || url.size() > 2000 || has_space || url.find('.') == std::string::npos) {
        res.error(400, "That does not look like a web address. Try something like https://example.com/page");
        return;
    }

    auto f = extract_url_features(url);
    ParsedUrl p = parse_url(url);
    double p_rf = app.url_model.forest.predict_proba(f);
    double p_lr = app.url_model.lr.predict_proba_dense(app.url_model.scaler.transform(f));
    double risk = 100.0 * p_rf;

    std::string verdict = risk >= 70 ? "phishing" : risk >= 40 ? "suspicious" : "safe";
    std::string title = verdict == "phishing" ? "Likely phishing" : verdict == "suspicious" ? "Suspicious link" : "Looks legitimate";
    std::string advice =
        verdict == "phishing" ? "Do not open this link or enter any passwords or card details. If it arrived in an email or message, report it as phishing and delete it."
        : verdict == "suspicious" ? "Be careful. Do not type credentials here. Instead, go to the website by typing its official address yourself."
                                  : "No strong warning signs in the address itself. Remember this check only looks at the URL text, not at the page behind it.";

    std::string flags = "[";
    auto fl = url_red_flags(f);
    for (size_t i = 0; i < fl.size(); ++i) flags += (i ? "," : "") + jstr(fl[i]);
    flags += "]";

    size_t subdomains = 0;
    const auto& names = url_feature_names();
    for (size_t i = 0; i < names.size(); ++i) if (names[i] == "num_subdomains") subdomains = static_cast<size_t>(f[i]);

    std::string feats = "[";
    for (size_t i = 0; i < names.size(); ++i)
        feats += (i ? "," : "") + std::string("{\"name\":") + jstr(names[i]) + ",\"value\":" + jnum(f[i]) + "}";
    feats += "]";

    std::string j = "{\"url\":" + jstr(url) + ",\"verdict\":" + jstr(verdict) + ",\"title\":" + jstr(title) +
                    ",\"risk\":" + round1(risk) + ",\"risk_forest\":" + round1(100.0 * p_rf) +
                    ",\"risk_logistic\":" + round1(100.0 * p_lr) + ",\"advice\":" + jstr(advice) +
                    ",\"flags\":" + flags + ",\"parsed\":{\"scheme\":" + jstr(p.scheme) + ",\"host\":" + jstr(p.host) +
                    ",\"registered_domain\":" + jstr(p.registered_domain) + ",\"tld\":" + jstr(p.tld) +
                    ",\"path\":" + jstr(p.path + (p.query.empty() ? "" : "?" + p.query)) +
                    ",\"subdomains\":" + std::to_string(subdomains) + ",\"is_ip\":" + jbool(p.is_ip) +
                    "},\"features\":" + feats + "}";
    log_scan("url", url, verdict, risk);
    res.json(j);
}

// ---- news checker -------------------------------------------------------------

std::string friendly_term(const std::string& t, bool& is_style) {
    is_style = !t.empty() && t[0] == '<';
    if (t == "<exclamation_rate>") return "Exclamation marks";
    if (t == "<caps_ratio>") return "CAPITAL LETTERS";
    if (t == "<article_length>") return "Text length";
    std::string o = t;
    std::replace(o.begin(), o.end(), '_', ' ');
    return o;
}

void h_check_news(const Request& req, Response& res) {
    if (!app.news_ok) { res.error(503, "The fake-news model is not trained yet. Run ./trustlens run first."); return; }
    std::string text;
    if (!json_get_string(req.body, "text", text)) { res.error(400, "Please send a JSON body like {\"text\": \"...\"}"); return; }
    text = trim(text);
    if (text.size() < 20) { res.error(400, "Please paste at least a sentence or two (20+ characters)."); return; }
    if (text.size() > 20000) { res.error(400, "That text is too long. The limit is 20,000 characters."); return; }

    SparseVec x = app.vec.transform(text);
    double p = app.news_lr.predict_proba(x);
    int recognised = 0;
    for (auto& pr : x) if (pr.first < app.vec.vocab_size()) ++recognised;

    std::string verdict = p >= 0.75 ? "fake" : p >= 0.5 ? "leans_fake" : p >= 0.25 ? "leans_real" : "real";
    std::string title = verdict == "fake" ? "Very likely fake / misleading" : verdict == "leans_fake" ? "Leans fake"
                       : verdict == "leans_real" ? "Leans real" : "Very likely real";
    double dist = std::fabs(p - 0.5);
    std::string confidence = (recognised < 5 || dist < 0.15) ? "low" : dist < 0.35 ? "medium" : "high";

    struct Contribution { std::string term; double value; bool style; };
    std::vector<Contribution> contrib;
    for (auto& pr : x) {
        bool is_style = false;
        std::string term = friendly_term(app.vec.feature_name(pr.first), is_style);
        contrib.push_back({term, app.news_lr.weights()[pr.first] * pr.second, is_style});
    }
    std::sort(contrib.begin(), contrib.end(), [](auto& a, auto& b) { return std::fabs(a.value) > std::fabs(b.value); });
    std::string reasons = "[";
    for (size_t i = 0; i < contrib.size() && i < 8; ++i)
        reasons += (i ? "," : "") + std::string("{\"term\":") + jstr(contrib[i].term) + ",\"effect\":" +
                   jnum(std::round(contrib[i].value * 1000.0) / 1000.0) + ",\"direction\":" +
                   jstr(contrib[i].value > 0 ? "fake" : "real") + ",\"kind\":" + jstr(contrib[i].style ? "style" : "word") + "}";
    reasons += "]";

    // plain statistics about the text
    int words = 0, excl = 0, upper_words = 0;
    double letters = 0, upper = 0;
    bool in_word = false;
    std::string cur;
    for (unsigned char c : text) {
        if (std::isalpha(c)) { ++letters; if (std::isupper(c)) ++upper; }
        if (c == '!') ++excl;
        if (std::isspace(c)) {
            if (in_word) { ++words; if (cur.size() >= 3 && std::all_of(cur.begin(), cur.end(), [](unsigned char ch) { return !std::isalpha(ch) || std::isupper(ch); })
                                           && std::any_of(cur.begin(), cur.end(), [](unsigned char ch) { return std::isalpha(ch); })) ++upper_words; }
            in_word = false; cur.clear();
        } else { in_word = true; cur += static_cast<char>(c); }
    }
    if (in_word) ++words;

    std::string j = "{\"verdict\":" + jstr(verdict) + ",\"title\":" + jstr(title) + ",\"p_fake\":" + round1(100.0 * p) +
                    ",\"confidence\":" + jstr(confidence) + ",\"recognised_terms\":" + std::to_string(recognised) +
                    ",\"reasons\":" + reasons + ",\"stats\":{\"words\":" + std::to_string(words) + ",\"exclamations\":" +
                    std::to_string(excl) + ",\"shouting_words\":" + std::to_string(upper_words) + ",\"caps_pct\":" +
                    round1(letters > 0 ? 100.0 * upper / letters : 0) + "}}";
    log_scan("news", text, verdict, 100.0 * p);
    res.json(j);
}

// ---- dataset explorer -----------------------------------------------------------

void h_list(const Request& req, Response& res, bool news) {
    long long page = to_int(req.param("page"), 1, 1, 100000);
    long long per = to_int(req.param("per"), 12, 5, 50);
    std::string q = trim(req.param("q")), label = req.param("label");

    std::vector<std::string> where;
    Params ps;
    if (!q.empty()) {
        std::string like = "%" + like_escape(q) + "%";
        if (news) { where.push_back("(title LIKE ? ESCAPE '\\' OR body LIKE ? ESCAPE '\\')"); ps.push_back(like); ps.push_back(like); }
        else { where.push_back("url LIKE ? ESCAPE '\\'"); ps.push_back(like); }
    }
    if (label == "0" || label == "1") { where.push_back("label = ?"); ps.push_back(static_cast<long long>(label == "1")); }
    std::string extra_col = req.param(news ? "subject" : "tld");
    if (!extra_col.empty()) { where.push_back(std::string(news ? "subject" : "tld") + " = ?"); ps.push_back(extra_col); }

    std::string w;
    for (size_t i = 0; i < where.size(); ++i) w += (i ? " AND " : " WHERE ") + where[i];

    const std::string table = news ? "news_articles" : "urls";
    long long total = app.db.scalar("SELECT COUNT(*) FROM " + table + w, ps);
    long long pages = std::max<long long>(1, (total + per - 1) / per);
    page = std::min(page, pages);

    Params ps2 = ps;
    ps2.push_back(per);
    ps2.push_back((page - 1) * per);
    std::string cols = news
        ? "article_id AS id, title, substr(body, 1, 170) AS snippet, subject, source, published_date AS date, label, word_count"
        : "url_id AS id, url, host, tld, label, source, collected_date AS date";
    std::string rows = app.db.rows_json("SELECT " + cols + " FROM " + table + w + " ORDER BY " +
                                        (news ? "article_id" : "url_id") + " LIMIT ? OFFSET ?", ps2);
    std::string options = app.db.rows_json(news ? "SELECT DISTINCT subject AS value FROM news_articles ORDER BY subject"
                                                : "SELECT tld AS value FROM urls GROUP BY tld HAVING COUNT(*) >= 25 ORDER BY COUNT(*) DESC");
    res.json("{\"total\":" + std::to_string(total) + ",\"page\":" + std::to_string(page) + ",\"pages\":" +
             std::to_string(pages) + ",\"per\":" + std::to_string(per) + ",\"rows\":" + rows + ",\"filter_options\":" + options + "}");
}

void h_detail(const Request& req, Response& res, bool news) {
    std::string prefix = news ? "/api/data/news/" : "/api/data/urls/";
    long long id = to_int(req.path.substr(prefix.size()), -1, -1, 1LL << 40);
    if (id < 0) { res.error(400, "bad id"); return; }
    std::string task = news ? "fake_news" : "phishing";
    std::string item = news
        ? app.db.first_json("SELECT article_id AS id, title, body, subject, source, published_date AS date, label, word_count, "
                            "exclamation_count, ROUND(100 * caps_ratio, 2) AS caps_pct FROM news_articles WHERE article_id = ?", {id})
        : app.db.first_json("SELECT url_id AS id, url, host, tld, registered_domain, label, source, collected_date AS date "
                            "FROM urls WHERE url_id = ?", {id});
    if (item == "null") { res.error(404, "not found"); return; }
    std::string preds = app.db.rows_json("SELECT model, predicted_label, ROUND(probability, 4) AS probability FROM predictions "
                                         "WHERE task = ? AND item_id = ? ORDER BY model", {task, id});
    std::string j = "{\"item\":" + item + ",\"predictions\":" + preds;
    if (!news) j += ",\"features\":" + app.db.first_json("SELECT * FROM url_features WHERE url_id = ?", {id});
    res.json(j + "}");
}

// ---- SQL lab ----------------------------------------------------------------------

void h_sql_list(const Request&, Response& res) {
    std::string j = "{\"queries\":[";
    for (size_t i = 0; i < app.queries.size(); ++i)
        j += (i ? "," : "") + std::string("{\"id\":") + std::to_string(i + 1) + ",\"title\":" + jstr(app.queries[i].first) +
             ",\"sql\":" + jstr(app.queries[i].second) + "}";
    res.json(j + "]}");
}

void h_sql_run(const Request& req, Response& res) {
    long long id = to_int(req.path.substr(std::string("/api/sql-lab/").size()), 0, 0, 1000);
    if (id < 1 || id > static_cast<long long>(app.queries.size())) { res.error(404, "no such query"); return; }
    const auto& q = app.queries[static_cast<size_t>(id - 1)];
    res.json("{\"id\":" + std::to_string(id) + ",\"title\":" + jstr(q.first) + ",\"sql\":" + jstr(q.second) +
             ",\"result\":" + app.db.table_json(q.second) + "}");
}

// =============================================================================
//  Static files (the website itself)
// =============================================================================

std::string mime_for(const std::string& ext) {
    static const std::map<std::string, std::string> m = {
        {".html", "text/html; charset=utf-8"}, {".css", "text/css; charset=utf-8"},
        {".js", "text/javascript; charset=utf-8"}, {".json", "application/json; charset=utf-8"},
        {".svg", "image/svg+xml"}, {".png", "image/png"}, {".jpg", "image/jpeg"}, {".jpeg", "image/jpeg"},
        {".ico", "image/x-icon"}, {".webp", "image/webp"}, {".txt", "text/plain; charset=utf-8"},
        {".woff2", "font/woff2"}};
    auto it = m.find(ext);
    return it == m.end() ? "application/octet-stream" : it->second;
}

bool load_static(const std::string& rel, Response& res) {
    namespace fs = std::filesystem;
    if (rel.find("..") != std::string::npos || rel.find('\\') != std::string::npos || rel.find('\0') != std::string::npos) return false;
    fs::path p = fs::path(app.web_dir) / rel.substr(1);
    if (fs::is_directory(p)) p /= "index.html";
    if (!fs::exists(p) && p.extension().empty()) p += ".html";   // /scanner -> scanner.html
    if (!fs::is_regular_file(p)) return false;
    std::ifstream in(p, std::ios::binary);
    std::ostringstream ss;
    ss << in.rdbuf();
    res.status = 200;
    res.body = ss.str();
    res.content_type = mime_for(to_lower(p.extension().string()));
    res.headers["Cache-Control"] = "no-cache";
    return true;
}

void h_static(const Request& req, Response& res) {
    std::string path = req.path == "/" ? "/index.html" : req.path;
    if (starts_with(path, "/api/")) { res.error(404, "Unknown API endpoint"); return; }
    if (load_static(path, res)) return;
    Response nf;
    if (load_static("/404.html", nf)) { res = nf; res.status = 404; return; }
    res.status = 404;
    res.body = "404 - page not found";
}

// =============================================================================
//  Start-up
// =============================================================================

void load_models() {
    {
        std::ifstream in("models/url_model.txt");
        app.url_ok = in && app.url_model.scaler.load(in) && app.url_model.lr.load(in) && app.url_model.forest.load(in);
    }
    {
        std::ifstream in("models/news_lr.txt");
        app.news_ok = in && app.vec.load("models/news_vectorizer.txt") && app.news_lr.load(in);
    }
}

}  // namespace

int main(int argc, char** argv) {
    int port = 8080;
    std::string host = "127.0.0.1", db_path = "db/trustlens.db";
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--host" && i + 1 < argc) host = argv[++i];
        else if (a == "--web" && i + 1 < argc) app.web_dir = argv[++i];
        else if (a == "--db" && i + 1 < argc) db_path = argv[++i];
        else if (std::all_of(a.begin(), a.end(), [](unsigned char c) { return std::isdigit(c); }) && !a.empty()) port = std::atoi(a.c_str());
        else { std::cerr << "Unknown option: " << a << "\nUsage: trustlens_server [port] [--host IP] [--web DIR] [--db FILE]\n"; return 1; }
    }

    if (!app.db.open(db_path)) {
        std::cerr << "\nCould not open the database: " << db_path
                  << "\nRun the pipeline first so it can be created:   ./trustlens run\n\n";
        return 1;
    }
    if (!std::filesystem::exists(app.web_dir + "/index.html")) {
        std::cerr << "Could not find " << app.web_dir << "/index.html - run the server from the project folder.\n";
        return 1;
    }
    load_models();
    app.queries = read_query_file("sql/analysis_queries.sql");

    HttpServer server;
    server.route("GET", "/api/health", h_health);
    server.route("GET", "/api/overview", h_overview);
    server.route("GET", "/api/analytics", h_analytics);
    server.route("GET", "/api/models", h_models);
    server.route("GET", "/api/roc", h_roc);
    server.route("GET", "/api/examples", h_examples);
    server.route("GET", "/api/history", h_history);
    server.route("POST", "/api/scan-url", h_scan_url);
    server.route("POST", "/api/check-news", h_check_news);
    server.route("GET", "/api/data/news", [](const Request& r, Response& s) { h_list(r, s, true); });
    server.route("GET", "/api/data/urls", [](const Request& r, Response& s) { h_list(r, s, false); });
    server.route_prefix("GET", "/api/data/news/", [](const Request& r, Response& s) { h_detail(r, s, true); });
    server.route_prefix("GET", "/api/data/urls/", [](const Request& r, Response& s) { h_detail(r, s, false); });
    server.route("GET", "/api/sql-lab", h_sql_list);
    server.route_prefix("GET", "/api/sql-lab/", h_sql_run);
    server.fallback(h_static);

    std::cout << "\n  TrustLens web server\n  --------------------\n"
              << "  website : http://" << (host == "0.0.0.0" ? "127.0.0.1" : host) << ":" << port << "\n"
              << "  database: " << db_path << "   models: url=" << (app.url_ok ? "ok" : "MISSING")
              << " news=" << (app.news_ok ? "ok" : "MISSING") << "\n"
              << "  press Ctrl+C to stop\n\n";
    if (host != "127.0.0.1")
        std::cout << "  NOTE: listening on " << host << " - anyone on your network can open the site.\n\n";
    return server.serve(host, port) ? 0 : 1;
}
