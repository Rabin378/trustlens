// generate_data.cpp
// -----------------------------------------------------------------------------
// Builds two practice datasets so the project runs out of the box:
//
//     data/news.csv   -> fake vs. real news articles
//     data/urls.csv   -> phishing vs. legitimate website URLs
//
// IMPORTANT: this data is SYNTHETIC. It is made from templates + random noise so
// you can learn the full pipeline without downloading anything. For your final
// submission you should swap in real data (see README -> "Using your own data"):
//     * Fake news : Kaggle "Fake and Real News Dataset" (ISOT) or LIAR
//     * Phishing  : PhishTank / OpenPhish URLs + Tranco top sites (legit)
//
// To make life realistic we deliberately add mess: duplicate rows, empty text,
// bad labels, odd spacing, label noise, and "hard" cases that look like the
// opposite class. The cleaning step in main.cpp has to deal with all of it.
// -----------------------------------------------------------------------------

#include <iostream>
#include <random>
#include <string>
#include <vector>

#include "../include/common.hpp"
#include "../include/csv.hpp"

using namespace tl;

static std::mt19937 rng(2024);

static int rnd(int lo, int hi) { return std::uniform_int_distribution<int>(lo, hi)(rng); }
static double rnd01() { return std::uniform_real_distribution<double>(0.0, 1.0)(rng); }
static bool chance(double p) { return rnd01() < p; }

template <typename T>
static const T& pick(const std::vector<T>& v) { return v[rnd(0, static_cast<int>(v.size()) - 1)]; }

static std::string replace_all(std::string s, const std::string& from, const std::string& to) {
    size_t pos = 0;
    while ((pos = s.find(from, pos)) != std::string::npos) {
        s.replace(pos, from.size(), to);
        pos += to.size();
    }
    return s;
}

static std::string capitalize(std::string s) {
    if (!s.empty()) s[0] = static_cast<char>(std::toupper(static_cast<unsigned char>(s[0])));
    return s;
}

static std::string random_token(int len) {
    static const std::string chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    std::string t;
    for (int i = 0; i < len; ++i) t += chars[rnd(0, static_cast<int>(chars.size()) - 1)];
    return t;
}

static std::string random_date() {
    char buf[16];
    std::snprintf(buf, sizeof(buf), "%d-%02d-%02d", rnd(2023, 2025), rnd(1, 12), rnd(1, 28));
    return buf;
}

// =============================================================================
//  PART 1 - FAKE NEWS
// =============================================================================

struct SubjectInfo { std::string name; std::vector<std::string> topics; };

static const std::vector<SubjectInfo> kSubjects = {
    {"politics",   {"the new election law", "the national budget", "the transport bill", "the tax reform plan"}},
    {"economy",    {"the inflation figures", "the housing market", "interest rates", "the unemployment numbers"}},
    {"health",     {"the vaccination programme", "hospital waiting times", "the flu season", "a new diabetes treatment"}},
    {"science",    {"the climate report", "a Mars probe", "a battery research project", "a coral reef study"}},
    {"technology", {"the chip shortage", "a new smartphone", "an AI safety rule", "the broadband rollout"}},
    {"sports",     {"the national football team", "the city marathon", "the cricket final", "the Olympic squad"}},
    {"world",      {"the border talks", "the trade summit", "the flood relief effort", "the peace negotiations"}},
};

static const std::vector<std::string> kPersons = {
    "Daniel Harper", "Maria Gonzalez", "Ahmed Rahman", "Sophie Laurent", "Kenji Watanabe",
    "Priya Nair", "Carlos Mendes", "Laura Bennett", "Tom Fischer", "Ananya Rao"};
static const std::vector<std::string> kOrgs = {
    "Ministry of Finance", "Health Council", "National Statistics Office", "Institute for Public Research",
    "City Council", "Transport Authority", "Energy Agency", "Sports Federation"};
static const std::vector<std::string> kPlaces = {
    "Riverton", "Lakeside", "Northport", "Eastvale", "Greenfield", "Marlow", "Harborview"};
static const std::vector<std::string> kDays = {
    "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

// Calm, sourced, "newsroom" style sentences.
static const std::vector<std::string> kRealSentences = {
    "The {org} said on {day} that {topic} would be reviewed over the coming {num} months.",
    "According to figures released by the {org}, {topic} changed by {num} percent compared with last year.",
    "{person}, a spokesperson for the {org}, told reporters in {place} that officials were studying {topic}.",
    "Analysts at the {org} said the impact of {topic} remains uncertain and will depend on several factors.",
    "The report, published on {day}, covers {num} regions and draws on data collected over two years.",
    "Critics argued that {topic} does not go far enough, while supporters called it a step forward.",
    "Officials in {place} confirmed that {num} people were consulted before {topic} was announced.",
    "A statement from the {org} noted that further details on {topic} will be released next month.",
    "Researchers reviewed {num} earlier studies before drawing conclusions about {topic}.",
    "The {org} declined to comment beyond its written statement on {topic}.",
    "Meetings are scheduled in {place} later this week to discuss {topic}, officials said.",
    "Independent experts cautioned that the early evidence on {topic} should be interpreted with care.",
};

// Loud, emotional, conspiracy-flavoured sentences.
static const std::vector<std::string> kFakeSentences = {
    "BREAKING: {person} secretly admits that {topic} is a total hoax and the media is hiding it from you!",
    "You will not believe what the {org} does not want you to know about {topic}!!!",
    "Share this before it gets deleted: insiders reveal the shocking truth behind {topic}.",
    "Doctors hate this one weird trick that the elites tried to ban, and it is all connected to {topic}.",
    "Wake up people! {topic} is a massive cover up and {num} million sheep still believe the lies.",
    "A secret document leaked by an anonymous patriot proves {person} lied about {topic} to everyone.",
    "The mainstream media will never tell you this, but {topic} is a deliberate plot to control your life!",
    "SHOCKING video shows {person} caught red handed in {place} while the {org} stays silent.",
    "They are poisoning you and nobody is talking about {topic}, so spread the word now!!!",
    "100 percent PROOF that {topic} was staged, and thousands of brave readers are already sharing it.",
    "Miracle cure discovered in {place} and big pharma is furious, the {org} wants it silenced.",
    "Experts are SPEECHLESS after {person} exposes the real story behind {topic}.",
};

// Neutral filler that shows up in BOTH classes (so words alone can't give it away).
static const std::vector<std::string> kSharedSentences = {
    "Many people in {place} have been talking about {topic} this week.",
    "The story has been widely discussed on social media since {day}.",
    "{person} has been involved in public life for over {num} years.",
    "The {org} is based in {place} and has been active since the nineties.",
    "Reactions to {topic} have been mixed across the country.",
    "Several readers asked for more information about {topic}.",
};

static const std::vector<std::string> kRealTitles = {
    "{Topic}: officials outline next steps", "What {topic} means for {place}",
    "{Topic} under review, says {org}", "Report examines {topic} in {num} regions",
    "{Topic} draws mixed reaction"};
static const std::vector<std::string> kFakeTitles = {
    "SHOCKING truth about {topic} they do not want you to see", "{Topic} is a HOAX and {person} just proved it",
    "You won't believe what happened with {topic}!!!", "BREAKING: {person} exposes {topic} cover up",
    "The {topic} lie: what the elites are hiding"};

static std::string fill(std::string tpl, const SubjectInfo& subj) {
    std::string topic = pick(subj.topics);
    tpl = replace_all(tpl, "{Topic}", capitalize(topic));
    tpl = replace_all(tpl, "{topic}", topic);
    tpl = replace_all(tpl, "{org}", pick(kOrgs));
    tpl = replace_all(tpl, "{person}", pick(kPersons));
    tpl = replace_all(tpl, "{place}", pick(kPlaces));
    tpl = replace_all(tpl, "{day}", pick(kDays));
    tpl = replace_all(tpl, "{num}", std::to_string(rnd(2, 95)));
    return tpl;
}

struct NewsRow { std::string title, text, subject, source, date; std::string label; };

static NewsRow make_article(int true_label) {
    const SubjectInfo& subj = pick(kSubjects);

    // ~8 % of the time the writing STYLE belongs to the other class.
    // (Sober fake news and sensational real headlines both exist in real life!)
    int style = true_label;
    if (chance(0.08)) style = 1 - true_label;

    const auto& pool = style == 1 ? kFakeSentences : kRealSentences;
    const auto& titles = style == 1 ? kFakeTitles : kRealTitles;

    std::string text;
    int sentences = rnd(4, 9);
    for (int i = 0; i < sentences; ++i) {
        const auto& src = chance(0.30) ? kSharedSentences : pool;
        text += fill(pick(src), subj) + " ";
    }

    static const std::vector<std::string> real_sources = {"Daily Ledger", "Metro Herald", "Global Wire", "National Courier"};
    static const std::vector<std::string> fake_sources = {"TruthBomb24", "WakeUpNow", "ViralPulse", "RealPatriotNews"};
    std::string source = true_label == 1 ? pick(fake_sources) : pick(real_sources);
    if (chance(0.10)) source = true_label == 1 ? pick(real_sources) : pick(fake_sources);

    // ~2 % annotation noise: the label itself is wrong.
    int written_label = true_label;
    if (chance(0.02)) written_label = 1 - written_label;

    NewsRow r;
    r.title = fill(pick(titles), subj);
    r.text = trim(text);
    r.subject = subj.name;
    r.source = source;
    r.date = random_date();
    r.label = std::to_string(written_label);
    return r;
}

static void generate_news(const std::string& path, int n) {
    std::ofstream out(path);
    write_csv_row(out, {"id", "title", "text", "subject", "source", "published_date", "label"});

    std::vector<NewsRow> rows;
    for (int i = 0; i < n; ++i) rows.push_back(make_article(chance(0.47) ? 1 : 0));

    // Add the kind of mess you meet in real files.
    int dup = n / 50, empty = n / 100, badlabel = n / 100;
    for (int i = 0; i < dup; ++i) rows.push_back(rows[rnd(0, n - 1)]);
    for (int i = 0; i < empty; ++i) { NewsRow r = make_article(0); r.text = ""; r.title = "Update"; rows.push_back(r); }
    for (int i = 0; i < badlabel; ++i) { NewsRow r = make_article(1); r.label = "unknown"; rows.push_back(r); }
    std::shuffle(rows.begin(), rows.end(), rng);

    int id = 1;
    for (auto& r : rows) {
        write_csv_row(out, {std::to_string(id++), r.title, "  " + r.text + " ", r.subject, r.source, r.date, r.label});
    }
    std::cout << "  wrote " << path << "  (" << rows.size() << " raw rows)\n";
}

// =============================================================================
//  PART 2 - PHISHING URLS
// =============================================================================

static const std::vector<std::string> kBrands = {
    "paypal", "apple", "google", "amazon", "microsoft", "netflix", "facebook",
    "instagram", "dropbox", "linkedin", "ebay", "chase", "wellsfargo", "dhl"};
static const std::vector<std::string> kKeywords = {
    "login", "verify", "secure", "account", "update", "confirm", "signin",
    "password", "banking", "wallet", "support", "billing"};
static const std::vector<std::string> kBadTlds = {
    "xyz", "top", "tk", "ml", "ga", "cf", "click", "work", "online", "site", "ru", "cn"};
static const std::vector<std::string> kGoodTlds = {"com", "org", "net", "io", "edu", "co"};
static const std::vector<std::string> kWords = {
    "bluepine", "greenleaf", "cityhub", "techwave", "dailybite", "openbooks", "travelnest",
    "fitjourney", "codecraft", "homegarden", "musicbox", "learnfast", "petcare", "skyline",
    "cookbook", "gadgetly", "mapquestly", "recipehub", "newsroomx", "artstudio"};
static const std::vector<std::string> kShorteners = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly"};

static std::string random_ip() {
    return std::to_string(rnd(11, 223)) + "." + std::to_string(rnd(1, 254)) + "." +
           std::to_string(rnd(1, 254)) + "." + std::to_string(rnd(1, 254));
}

static std::string legit_url() {
    std::string scheme = chance(0.88) ? "https://" : "http://";
    std::string www = chance(0.6) ? "www." : "";
    std::string host, path;

    if (chance(0.35)) {
        // A real brand on its real domain, sometimes on a login page (legit!).
        std::string b = pick(kBrands);
        static const std::vector<std::string> subs = {"www.", "accounts.", "support.", "mail.", ""};
        host = pick(subs) + b + ".com";
        static const std::vector<std::string> paths = {
            "/", "/help/contact", "/signin", "/account/settings", "/security/overview", "/login?next=/home"};
        path = pick(paths);
    } else {
        host = www + pick(kWords) + (chance(0.3) ? "-" + pick(kWords) : "") + "." + pick(kGoodTlds);
        int kind = rnd(0, 5);
        if (kind == 0) path = "/";
        else if (kind == 1) path = "/blog/" + pick(kWords);
        else if (kind == 2) path = "/products/" + std::to_string(rnd(100, 99999));
        else if (kind == 3) path = "/news/" + std::to_string(rnd(2022, 2025)) + "/" + pick(kWords);
        else if (kind == 4) path = "/search?q=" + pick(kWords) + "&page=" + std::to_string(rnd(1, 9));
        else path = "/docs/" + pick(kWords) + "/index.html";
    }
    // a few legit but ugly URLs (long tracking links)
    if (chance(0.06)) path += "?utm_source=mail&utm_campaign=" + random_token(8) + "&ref=" + random_token(6);
    return scheme + host + path;
}

static std::string phishing_url() {
    std::string brand = pick(kBrands), kw = pick(kKeywords), kw2 = pick(kKeywords);
    std::string bad = pick(kBadTlds);
    int kind = rnd(0, 7);
    std::string scheme = chance(0.25) ? "https://" : "http://";   // phishers use HTTPS too!

    switch (kind) {
        case 0: return scheme + brand + "-" + kw + "." + bad + "/" + kw2 + "/" + random_token(10);
        case 1: return "http://" + random_ip() + "/" + brand + "/" + kw + ".php?id=" + random_token(8);
        case 2: return scheme + brand + "." + kw + "." + pick(kWords) + "." + bad + "/" + kw2;
        case 3: return "http://" + pick(kShorteners) + "/" + random_token(7);
        case 4: return scheme + pick(kWords) + ".com/" + brand + "@" + random_token(6) + "/" + kw;
        case 5: {  // typosquatting
            std::string typo = brand;
            if (typo.size() > 3) typo[rnd(1, static_cast<int>(typo.size()) - 2)] = chance(0.5) ? '1' : '0';
            return scheme + typo + "-" + kw + ".com/" + kw2 + "?session=" + random_token(12);
        }
        case 6: return scheme + kw + "-" + brand + "-" + kw2 + "." + pick(kWords) + "." + bad + "/index.php";
        default:  // "hard" case: looks harmless
            return "https://www." + pick(kWords) + "." + pick(kGoodTlds) + "/" + kw + "/" + random_token(5);
    }
}

static void generate_urls(const std::string& path, int n) {
    std::ofstream out(path);
    write_csv_row(out, {"id", "url", "label", "source", "collected_date"});

    struct U { std::string url, label, source; };
    std::vector<U> rows;
    for (int i = 0; i < n; ++i) {
        bool phish = chance(0.40);
        std::string url = phish ? phishing_url() : legit_url();
        int written = phish ? 1 : 0;
        if (chance(0.015)) written = 1 - written;                      // label noise
        std::string src = written == 1 ? "phishtank-style" : "top-sites-style";
        rows.push_back({url, std::to_string(written), src});
    }
    int dup = n / 60, blank = n / 150;
    for (int i = 0; i < dup; ++i) rows.push_back(rows[rnd(0, n - 1)]);
    for (int i = 0; i < blank; ++i) rows.push_back({"", "0", "top-sites-style"});
    std::shuffle(rows.begin(), rows.end(), rng);

    int id = 1;
    for (auto& r : rows) {
        std::string url = r.url;
        if (!url.empty() && chance(0.05)) url = to_lower(url);          // inconsistent case
        if (!url.empty() && chance(0.03)) url = " " + url + " ";        // stray whitespace
        write_csv_row(out, {std::to_string(id++), url, r.label, r.source, random_date()});
    }
    std::cout << "  wrote " << path << "  (" << rows.size() << " raw rows)\n";
}

int main(int argc, char** argv) {
    int news_n = 2400, url_n = 4000;
    if (argc > 1) news_n = std::atoi(argv[1]);
    if (argc > 2) url_n = std::atoi(argv[2]);

    ensure_dir("data");
    std::cout << "Generating synthetic practice data...\n";
    generate_news("data/news.csv", news_n);
    generate_urls("data/urls.csv", url_n);
    std::cout << "Done. Now run:  ./trustlens run\n";
    return 0;
}
