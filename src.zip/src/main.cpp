// main.cpp
// -----------------------------------------------------------------------------
//  TrustLens  -  Fake News & Phishing Website Classifier (pure C++17)
//
//  The whole data-science life-cycle in one program:
//
//    1. Load + clean the raw CSV files
//    2. Exploratory data analysis (EDA)
//    3. Store everything in a SQL database and query it
//    4. Fake-news models   : TF-IDF + Naive Bayes / Logistic Regression
//    5. Phishing models    : URL feature engineering + LR / Tree / Random Forest
//    6. Evaluation         : hold-out test, cross-validation, ROC, error analysis
//    7. Reporting          : metrics.csv, report.html, SQL leaderboard
//    8. Deployment         : `predict-url` and `predict-news` commands
//
//  Usage:
//      ./trustlens run                       full pipeline
//      ./trustlens predict-url  "<url>"      classify one URL
//      ./trustlens predict-news "<text>"     classify one article
//      ./trustlens demo                      a few ready-made examples
// -----------------------------------------------------------------------------

#include <functional>

#include "../include/common.hpp"
#include "../include/csv.hpp"
#include "../include/data.hpp"
#include "../include/eda.hpp"
#include "../include/metrics.hpp"
#include "../include/models.hpp"
#include "../include/report.hpp"
#include "../include/sqlstore.hpp"
#include "../include/text.hpp"
#include "../include/url_features.hpp"

using namespace tl;

namespace {

const unsigned kSeed = 42;
const char* kNewsCsv = "data/news.csv";
const char* kUrlsCsv = "data/urls.csv";

// ---------------------------------------------------------------------------
//  small helpers
// ---------------------------------------------------------------------------

struct NewsStats { int words = 0, exclamations = 0; double caps_ratio = 0; };

NewsStats news_stats(const std::string& text) {
    NewsStats s;
    double letters = 0, upper = 0;
    bool in_word = false;
    for (unsigned char c : text) {
        if (std::isalpha(c)) { ++letters; if (std::isupper(c)) ++upper; }
        if (c == '!') ++s.exclamations;
        if (std::isspace(c)) in_word = false;
        else if (!in_word) { in_word = true; ++s.words; }
    }
    s.caps_ratio = letters > 0 ? upper / letters : 0.0;
    return s;
}

std::string safe_name(std::string s) {
    for (auto& c : s) if (!std::isalnum(static_cast<unsigned char>(c))) c = '_';
    return to_lower(s);
}

void write_roc_csv(const std::string& task, const std::string& model,
                   const std::vector<int>& y, const std::vector<double>& p) {
    std::ofstream out("results/roc_" + task + "_" + safe_name(model) + ".csv");
    out << "fpr,tpr\n";
    for (auto& pt : roc_curve(y, p)) out << pt.first << "," << pt.second << "\n";
}

std::string num_or_null(double v, bool has) { return has ? fmt(v, 6) : std::string("NULL"); }

void store_model_run(Database& db, const ModelResult& r) {
    db.exec("INSERT INTO model_runs (task, model, accuracy, precision_score, recall_score, f1, auc, "
            "cv_f1_mean, cv_f1_sd, tp, fp, tn, fn, trained_at) VALUES (" +
            sql_quote(r.task) + ", " + sql_quote(r.model) + ", " + fmt(r.test.accuracy, 6) + ", " +
            fmt(r.test.precision, 6) + ", " + fmt(r.test.recall, 6) + ", " + fmt(r.test.f1, 6) + ", " +
            fmt(r.test.auc, 6) + ", " + num_or_null(r.cv.mean_f1, r.has_cv) + ", " +
            num_or_null(r.cv.sd_f1, r.has_cv) + ", " + std::to_string(r.test.tp) + ", " +
            std::to_string(r.test.fp) + ", " + std::to_string(r.test.tn) + ", " + std::to_string(r.test.fn) +
            ", " + sql_quote(now_string()) + ");");
}

void store_predictions(Database& db, const std::string& task, const std::string& model,
                       const std::vector<int>& ids, const std::vector<int>& y, const std::vector<double>& p) {
    db.begin();
    for (size_t i = 0; i < ids.size(); ++i) {
        db.exec("INSERT INTO predictions (task, item_id, model, true_label, predicted_label, probability) VALUES (" +
                sql_quote(task) + ", " + std::to_string(ids[i]) + ", " + sql_quote(model) + ", " +
                std::to_string(y[i]) + ", " + std::to_string(p[i] >= 0.5 ? 1 : 0) + ", " + fmt(p[i], 6) + ");");
    }
    db.commit();
}

std::vector<int> concat_except(const std::vector<std::vector<int>>& folds, size_t skip) {
    std::vector<int> o;
    for (size_t f = 0; f < folds.size(); ++f)
        if (f != skip) o.insert(o.end(), folds[f].begin(), folds[f].end());
    return o;
}

using DenseScorer = std::function<double(const std::vector<double>&)>;

// Generic k-fold cross-validation for dense-feature models.
// `train` receives the training rows and returns a function that scores one row.
CvResult cv_dense(const Dense& X, const std::vector<int>& y, int k,
                  const std::function<DenseScorer(const Dense&, const std::vector<int>&)>& train) {
    auto folds = stratified_folds(y, k, kSeed);
    std::vector<Metrics> ms;
    for (int f = 0; f < k; ++f) {
        auto tr = concat_except(folds, f);
        auto scorer = train(pick_rows(X, tr), pick_rows(y, tr));
        std::vector<double> p;
        for (int i : folds[f]) p.push_back(scorer(X[i]));
        ms.push_back(evaluate(pick_rows(y, folds[f]), p));
    }
    return summarize_cv(ms);
}

// ---------------------------------------------------------------------------
//  STAGE: fake news
// ---------------------------------------------------------------------------

void run_fake_news(const std::vector<NewsRecord>& news, Database& db, ReportData& rep,
                   std::vector<ModelResult>& all) {
    banner("4. FAKE NEWS CLASSIFICATION  (TF-IDF + Naive Bayes / Logistic Regression)");

    std::vector<std::string> docs;
    std::vector<int> y, ids;
    for (auto& n : news) { docs.push_back(n.title + ". " + n.text); y.push_back(n.label); ids.push_back(n.id); }

    Split sp = stratified_split(y, 0.20, kSeed);
    auto train_docs = pick_rows(docs, sp.train), test_docs = pick_rows(docs, sp.test);
    auto ytr = pick_rows(y, sp.train), yte = pick_rows(y, sp.test);
    auto test_ids = pick_rows(ids, sp.test);
    std::cout << "  train/test split: " << ytr.size() << " / " << yte.size() << " articles (stratified 80/20)\n";

    // Fit the vectorizer on TRAIN ONLY -> no leakage from the test set.
    TfidfVectorizer vec;
    vec.fit(train_docs, 3, 4000);
    std::vector<SparseVec> Xtr, Xte;
    for (auto& d : train_docs) Xtr.push_back(vec.transform(d));
    for (auto& d : test_docs) Xte.push_back(vec.transform(d));
    std::cout << "  vocabulary: " << vec.vocab_size() << " terms (unigrams + bigrams) + 3 style features\n";

    // ---- hyper-parameter search (3-fold CV inside the training set) --------
    section("Hyper-parameter tuning for Logistic Regression (3-fold CV on training data)");
    const std::vector<double> lrs = {0.5, 2.0};
    const std::vector<double> l2s = {1e-5, 1e-4, 1e-3};
    LogisticRegression::Params best_params;
    double best_f1 = -1;
    auto folds = stratified_folds(ytr, 3, kSeed);
    for (double lr : lrs) {
        for (double l2 : l2s) {
            LogisticRegression::Params p;
            p.lr = lr; p.l2 = l2; p.epochs = 40;
            std::vector<Metrics> ms;
            for (int f = 0; f < 3; ++f) {
                auto tr = concat_except(folds, f);
                LogisticRegression m(p);
                m.fit(pick_rows(Xtr, tr), pick_rows(ytr, tr), vec.dim());
                std::vector<double> pr;
                for (int i : folds[f]) pr.push_back(m.predict_proba(Xtr[i]));
                ms.push_back(evaluate(pick_rows(ytr, folds[f]), pr));
            }
            CvResult cv = summarize_cv(ms);
            std::cout << "    lr=" << std::setw(4) << lr << "  l2=" << std::setw(7) << l2 << "  ->  CV F1 = "
                      << fmt(cv.mean_f1, 4) << "\n";
            if (cv.mean_f1 > best_f1) { best_f1 = cv.mean_f1; best_params = p; }
        }
    }
    best_params.epochs = 60;
    std::cout << "  chosen: lr=" << best_params.lr << ", l2=" << best_params.l2 << "\n";

    // ---- final models ------------------------------------------------------
    NaiveBayes nb;
    nb.fit(Xtr, ytr, vec.dim());
    LogisticRegression lr(best_params);
    lr.fit(Xtr, ytr, vec.dim());

    std::vector<double> p_nb, p_lr;
    for (auto& x : Xte) { p_nb.push_back(nb.predict_proba(x)); p_lr.push_back(lr.predict_proba(x)); }

    // 5-fold CV on ALL the data, refitting the vectorizer inside each fold (the honest way).
    auto news_cv = [&](bool use_lr) {
        auto fl = stratified_folds(y, 5, kSeed);
        std::vector<Metrics> ms;
        for (int f = 0; f < 5; ++f) {
            auto tr = concat_except(fl, f);
            TfidfVectorizer v;
            v.fit(pick_rows(docs, tr), 3, 4000);
            std::vector<SparseVec> a, b;
            for (int i : tr) a.push_back(v.transform(docs[i]));
            for (int i : fl[f]) b.push_back(v.transform(docs[i]));
            auto ya = pick_rows(y, tr), yb = pick_rows(y, fl[f]);
            std::vector<double> p;
            if (use_lr) { LogisticRegression m(best_params); m.fit(a, ya, v.dim()); for (auto& x : b) p.push_back(m.predict_proba(x)); }
            else { NaiveBayes m; m.fit(a, ya, v.dim()); for (auto& x : b) p.push_back(m.predict_proba(x)); }
            ms.push_back(evaluate(yb, p));
        }
        return summarize_cv(ms);
    };

    ModelResult r_nb{"fake_news", "Naive Bayes", evaluate(yte, p_nb), news_cv(false), true};
    ModelResult r_lr{"fake_news", "Logistic Regression", evaluate(yte, p_lr), news_cv(true), true};

    // Baseline: always guess the majority class.
    double majority = std::max(std::count(yte.begin(), yte.end(), 0), std::count(yte.begin(), yte.end(), 1)) /
                      static_cast<double>(yte.size());

    section("Results on the held-out TEST set");
    std::cout << "  baseline (always guess the majority class): accuracy " << fmt(majority, 3) << "\n";
    print_metrics("Naive Bayes", r_nb.test);
    print_metrics("Logistic Regression", r_lr.test);
    std::cout << "  5-fold CV F1:  NB " << fmt(r_nb.cv.mean_f1, 3) << " +/- " << fmt(r_nb.cv.sd_f1, 3)
              << "   LR " << fmt(r_lr.cv.mean_f1, 3) << " +/- " << fmt(r_lr.cv.sd_f1, 3) << "\n";
    std::cout << "\n  Confusion matrix - Logistic Regression\n";
    print_confusion(r_lr.test, "real", "fake");

    // ---- interpretability: which words matter? ------------------------------
    std::vector<NamedScore> all_words;
    for (int j = 0; j < vec.dim(); ++j) all_words.push_back({vec.feature_name(j), lr.weights()[j]});
    std::sort(all_words.begin(), all_words.end(), [](auto& a, auto& b) { return a.second > b.second; });
    section("What did the model learn? (largest Logistic Regression weights)");
    std::cout << "  towards FAKE: ";
    for (int i = 0; i < 10; ++i) std::cout << all_words[i].first << (i < 9 ? ", " : "\n");
    std::cout << "  towards REAL: ";
    for (int i = 0; i < 10; ++i) std::cout << all_words[all_words.size() - 1 - i].first << (i < 9 ? ", " : "\n");
    for (int i = 0; i < 12; ++i) {
        rep.fake_words.push_back(all_words[i]);
        rep.real_words.push_back({all_words[all_words.size() - 1 - i].first,
                                  all_words[all_words.size() - 1 - i].second});
    }

    // ---- save everything ------------------------------------------------------
    {   // top words in both directions, for the website's "Models" page
        std::ofstream out("results/news_words.csv");
        out << "term,weight,direction\n";
        for (int i = 0; i < 20; ++i) out << csv_escape(all_words[i].first) << "," << all_words[i].second << ",fake\n";
        for (int i = 0; i < 20; ++i) {
            const auto& w = all_words[all_words.size() - 1 - i];
            out << csv_escape(w.first) << "," << w.second << ",real\n";
        }
    }
    vec.save("models/news_vectorizer.txt");
    { std::ofstream out("models/news_lr.txt"); lr.save(out); }
    write_roc_csv("fake_news", "Naive Bayes", yte, p_nb);
    write_roc_csv("fake_news", "Logistic Regression", yte, p_lr);

    store_model_run(db, r_nb);
    store_model_run(db, r_lr);
    store_predictions(db, "fake_news", "Naive Bayes", test_ids, yte, p_nb);
    store_predictions(db, "fake_news", "Logistic Regression", test_ids, yte, p_lr);

    all.push_back(r_nb);
    all.push_back(r_lr);
}

// ---------------------------------------------------------------------------
//  STAGE: phishing URLs
// ---------------------------------------------------------------------------

void run_phishing(const std::vector<UrlRecord>& urls, const Dense& X, Database& db, ReportData& rep,
                  std::vector<ModelResult>& all) {
    banner("5. PHISHING URL CLASSIFICATION  (21 engineered features)");

    std::vector<int> y, ids;
    for (auto& u : urls) { y.push_back(u.label); ids.push_back(u.id); }
    Split sp = stratified_split(y, 0.20, kSeed);
    Dense Xtr = pick_rows(X, sp.train), Xte = pick_rows(X, sp.test);
    auto ytr = pick_rows(y, sp.train), yte = pick_rows(y, sp.test);
    auto test_ids = pick_rows(ids, sp.test);
    std::cout << "  train/test split: " << ytr.size() << " / " << yte.size() << " URLs (stratified 80/20)\n";

    // Logistic regression needs scaled inputs; trees do not.
    StandardScaler scaler;
    scaler.fit(Xtr);
    Dense Xtr_s = scaler.transform(Xtr);

    LogisticRegression::Params lp;
    lp.lr = 0.3; lp.l2 = 1e-4; lp.epochs = 60;
    LogisticRegression lr(lp);
    {
        std::vector<SparseVec> sp_tr;
        for (auto& r : Xtr_s) sp_tr.push_back(to_sparse(r));
        lr.fit(sp_tr, ytr, static_cast<int>(Xtr_s[0].size()));
    }

    TreeParams tp_single; tp_single.max_depth = 6; tp_single.min_samples_leaf = 5;
    std::mt19937 rng(kSeed);
    DecisionTree tree;
    {
        std::vector<int> all_idx(Xtr.size());
        std::iota(all_idx.begin(), all_idx.end(), 0);
        tree.fit(Xtr, ytr, all_idx, tp_single, rng);
    }

    TreeParams tp_forest; tp_forest.max_depth = 10; tp_forest.min_samples_leaf = 2;
    RandomForest forest(100, tp_forest, kSeed);
    forest.fit(Xtr, ytr);

    std::vector<double> p_lr, p_dt, p_rf;
    for (auto& x : Xte) {
        p_lr.push_back(lr.predict_proba_dense(scaler.transform(x)));
        p_dt.push_back(tree.predict_proba(x));
        p_rf.push_back(forest.predict_proba(x));
    }

    // Cross-validation (everything re-trained inside each fold).
    auto cv_lr = cv_dense(X, y, 5, [&](const Dense& a, const std::vector<int>& ya) -> DenseScorer {
        auto sc = std::make_shared<StandardScaler>(); sc->fit(a);
        auto m = std::make_shared<LogisticRegression>(lp);
        std::vector<SparseVec> s;
        for (auto& r : sc->transform(a)) s.push_back(to_sparse(r));
        m->fit(s, ya, static_cast<int>(a[0].size()));
        return [sc, m](const std::vector<double>& x) { return m->predict_proba_dense(sc->transform(x)); };
    });
    auto cv_dt = cv_dense(X, y, 5, [&](const Dense& a, const std::vector<int>& ya) -> DenseScorer {
        auto m = std::make_shared<DecisionTree>();
        std::mt19937 r(kSeed);
        std::vector<int> idx(a.size()); std::iota(idx.begin(), idx.end(), 0);
        m->fit(a, ya, idx, tp_single, r);
        return [m](const std::vector<double>& x) { return m->predict_proba(x); };
    });
    auto cv_rf = cv_dense(X, y, 5, [&](const Dense& a, const std::vector<int>& ya) -> DenseScorer {
        auto m = std::make_shared<RandomForest>(60, tp_forest, kSeed);
        m->fit(a, ya);
        return [m](const std::vector<double>& x) { return m->predict_proba(x); };
    });

    ModelResult r_lr{"phishing", "Logistic Regression", evaluate(yte, p_lr), cv_lr, true};
    ModelResult r_dt{"phishing", "Decision Tree", evaluate(yte, p_dt), cv_dt, true};
    ModelResult r_rf{"phishing", "Random Forest", evaluate(yte, p_rf), cv_rf, true};

    double majority = std::max(std::count(yte.begin(), yte.end(), 0), std::count(yte.begin(), yte.end(), 1)) /
                      static_cast<double>(yte.size());
    section("Results on the held-out TEST set");
    std::cout << "  baseline (always guess the majority class): accuracy " << fmt(majority, 3) << "\n";
    print_metrics("Logistic Regression", r_lr.test);
    print_metrics("Decision Tree", r_dt.test);
    print_metrics("Random Forest", r_rf.test);
    std::cout << "  5-fold CV F1:  LR " << fmt(r_lr.cv.mean_f1, 3) << "   DT " << fmt(r_dt.cv.mean_f1, 3)
              << "   RF " << fmt(r_rf.cv.mean_f1, 3) << " +/- " << fmt(r_rf.cv.sd_f1, 3) << "\n";
    std::cout << "\n  Confusion matrix - Random Forest\n";
    print_confusion(r_rf.test, "legit", "phishing");

    section("Precision/recall trade-off (Random Forest, changing the alert threshold)");
    for (double t : {0.3, 0.5, 0.7}) {
        Metrics m = evaluate(yte, p_rf, t);
        std::cout << "  threshold " << fmt(t, 1) << ": precision " << fmt(m.precision, 3) << ", recall "
                  << fmt(m.recall, 3) << "  (missed phishing: " << m.fn << ", false alarms: " << m.fp << ")\n";
    }
    std::cout << "  -> lower threshold = catch more phishing but annoy users with more false alarms.\n";

    // Feature importance
    const auto& names = url_feature_names();
    std::vector<NamedScore> imp;
    for (size_t j = 0; j < names.size(); ++j) imp.push_back({names[j], forest.importance()[j]});
    std::sort(imp.begin(), imp.end(), [](auto& a, auto& b) { return a.second > b.second; });
    section("Random Forest feature importance (top 10)");
    for (int i = 0; i < 10; ++i)
        std::cout << "  " << std::left << std::setw(22) << imp[i].first << std::right << bar(imp[i].second / imp[0].second, 30)
                  << " " << fmt(imp[i].second, 3) << "\n";
    rep.url_importance.assign(imp.begin(), imp.begin() + 12);
    {
        std::ofstream out("results/url_importance.csv");
        out << "feature,importance\n";
        for (auto& p : imp) out << p.first << "," << p.second << "\n";
    }

    // Save the deployable model: scaler + LR + forest in ONE file.
    {
        std::ofstream out("models/url_model.txt");
        scaler.save(out);
        lr.save(out);
        forest.save(out);
    }
    write_roc_csv("phishing", "Logistic Regression", yte, p_lr);
    write_roc_csv("phishing", "Decision Tree", yte, p_dt);
    write_roc_csv("phishing", "Random Forest", yte, p_rf);

    for (auto* r : {&r_lr, &r_dt, &r_rf}) store_model_run(db, *r);
    store_predictions(db, "phishing", "Logistic Regression", test_ids, yte, p_lr);
    store_predictions(db, "phishing", "Decision Tree", test_ids, yte, p_dt);
    store_predictions(db, "phishing", "Random Forest", test_ids, yte, p_rf);

    all.push_back(r_lr);
    all.push_back(r_dt);
    all.push_back(r_rf);
}

// ---------------------------------------------------------------------------
//  The full pipeline
// ---------------------------------------------------------------------------

int run_pipeline() {
    ensure_dir("models"); ensure_dir("results"); ensure_dir("db");

    banner("1. LOAD & CLEAN THE RAW DATA");
    CleaningReport rn, ru;
    auto news = load_news(kNewsCsv, rn);
    auto urls = load_urls(kUrlsCsv, ru);
    rn.print("news.csv");
    ru.print("urls.csv");

    // ---------------- EDA ----------------
    banner("2. EXPLORATORY DATA ANALYSIS");
    std::vector<int> yn, yu;
    std::vector<double> wc, ex, caps;
    for (auto& n : news) {
        yn.push_back(n.label);
        NewsStats s = news_stats(n.title + ". " + n.text);
        wc.push_back(s.words); ex.push_back(s.exclamations); caps.push_back(s.caps_ratio);
    }
    print_class_balance("Fake news dataset", yn, "real", "fake");
    section("Writing style: class 0 = real, class 1 = fake");
    print_feature_by_class("word_count", wc, yn);
    print_feature_by_class("exclamation_count", ex, yn);
    print_feature_by_class("caps_ratio", caps, yn);

    Dense Xu;
    for (auto& u : urls) { Xu.push_back(extract_url_features(u.url)); yu.push_back(u.label); }
    std::cout << "\n";
    print_class_balance("Phishing dataset", yu, "legitimate", "phishing");
    section("Correlation of each URL feature with 'is phishing'");
    const auto& names = url_feature_names();
    std::vector<NamedScore> corr;
    for (size_t j = 0; j < names.size(); ++j) {
        std::vector<double> col;
        for (auto& r : Xu) col.push_back(r[j]);
        corr.push_back({names[j], correlation(col, yu)});
    }
    std::sort(corr.begin(), corr.end(), [](auto& a, auto& b) { return std::fabs(a.second) > std::fabs(b.second); });
    for (int i = 0; i < 8; ++i)
        std::cout << "  " << std::left << std::setw(22) << corr[i].first << std::right << std::setw(8)
                  << fmt(corr[i].second, 3) << "  " << bar(std::fabs(corr[i].second), 30) << "\n";

    // ---------------- SQL ----------------
    banner("3. SQL DATABASE");
    Database db("db/trustlens.db", "db/trustlens_full.sql");
    db.open();
    std::string schema = read_file("sql/schema.sql");
    if (schema.empty()) throw std::runtime_error("sql/schema.sql not found - run from the project folder");
    db.exec(schema);

    db.begin();
    for (auto& n : news) {
        NewsStats s = news_stats(n.title + ". " + n.text);
        db.exec("INSERT INTO news_articles VALUES (" + std::to_string(n.id) + ", " + sql_quote(n.title) + ", " +
                sql_quote(n.text) + ", " + sql_quote(n.subject) + ", " + sql_quote(n.source) + ", " +
                sql_quote(n.date) + ", " + std::to_string(n.label) + ", " + std::to_string(s.words) + ", " +
                std::to_string(s.exclamations) + ", " + fmt(s.caps_ratio, 5) + ");");
    }
    for (auto& u : urls) {
        ParsedUrl p = parse_url(u.url);
        db.exec("INSERT INTO urls VALUES (" + std::to_string(u.id) + ", " + sql_quote(u.url) + ", " +
                sql_quote(p.host) + ", " + sql_quote(p.tld) + ", " + sql_quote(p.registered_domain) + ", " +
                std::to_string(u.label) + ", " + sql_quote(u.source) + ", " + sql_quote(u.date) + ");");
    }
    for (size_t i = 0; i < urls.size(); ++i) {
        std::string cols = "url_id", vals = std::to_string(urls[i].id);
        for (size_t j = 0; j < names.size(); ++j) { cols += ", " + names[j]; vals += ", " + fmt(Xu[i][j], 6); }
        db.exec("INSERT INTO url_features (" + cols + ") VALUES (" + vals + ");");
    }
    db.commit();
    std::cout << "  inserted " << news.size() << " articles, " << urls.size() << " URLs and "
              << urls.size() << " feature rows\n";
    std::cout << "  mode: " << (db.live() ? "LIVE SQLite database -> db/trustlens.db"
                                          : "script only (SQLite library not found)") << "\n";
    std::cout << "  SQL script: db/trustlens_full.sql\n";

    // ---------------- models ----------------
    ReportData rep;
    std::vector<ModelResult> results;
    rep.news_info = "Fake news: " + std::to_string(news.size()) + " cleaned articles (" +
                    std::to_string(std::count(yn.begin(), yn.end(), 1)) + " fake, " +
                    std::to_string(std::count(yn.begin(), yn.end(), 0)) + " real). Synthetic practice data.";
    rep.url_info = "Phishing: " + std::to_string(urls.size()) + " cleaned URLs (" +
                   std::to_string(std::count(yu.begin(), yu.end(), 1)) + " phishing, " +
                   std::to_string(std::count(yu.begin(), yu.end(), 0)) + " legitimate), 21 engineered features.";

    run_fake_news(news, db, rep, results);
    run_phishing(urls, Xu, db, rep, results);

    // ---------------- reporting ----------------
    banner("6. SAVE RESULTS");
    {
        std::ofstream out("results/metrics.csv");
        write_csv_row(out, {"task", "model", "accuracy", "precision", "recall", "f1", "auc", "cv_f1_mean", "cv_f1_sd"});
        for (auto& r : results)
            write_csv_row(out, {r.task, r.model, fmt(r.test.accuracy, 4), fmt(r.test.precision, 4), fmt(r.test.recall, 4),
                                fmt(r.test.f1, 4), fmt(r.test.auc, 4), fmt(r.cv.mean_f1, 4), fmt(r.cv.sd_f1, 4)});
    }
    rep.results = results;
    write_html_report("results/report.html", rep);
    std::cout << "  results/metrics.csv      (all metrics)\n"
              << "  results/report.html      (open in your browser)\n"
              << "  results/roc_*.csv        (ROC curve points - plot in Excel)\n"
              << "  models/*.txt             (trained models for predict-url / predict-news)\n";

    // ---------------- SQL analysis ----------------
    banner("7. SQL ANALYSIS");
    auto queries = read_query_file("sql/analysis_queries.sql");
    for (auto& q : queries) db.query(q.first, q.second);
    db.close();

    std::cout << "\nAll done. Try:  ./trustlens demo\n";
    return 0;
}

// ---------------------------------------------------------------------------
//  Deployment: classify a single item with the saved models
// ---------------------------------------------------------------------------

struct UrlModel {
    StandardScaler scaler;
    LogisticRegression lr;
    RandomForest forest;
};

bool load_url_model(UrlModel& m) {
    std::ifstream in("models/url_model.txt");
    if (!in) return false;
    return m.scaler.load(in) && m.lr.load(in) && m.forest.load(in);
}

int predict_url(const std::string& url) {
    UrlModel m;
    if (!load_url_model(m)) { std::cerr << "No trained model found. Run  ./trustlens run  first.\n"; return 1; }
    auto f = extract_url_features(url);
    double p_rf = m.forest.predict_proba(f);
    double p_lr = m.lr.predict_proba_dense(m.scaler.transform(f));
    std::string verdict = p_rf >= 0.7 ? "PHISHING - do not click" : p_rf >= 0.4 ? "SUSPICIOUS - be careful"
                                                                                 : "looks legitimate";
    std::cout << "\n  URL      : " << url << "\n"
              << "  verdict  : " << verdict << "\n"
              << "  risk     : " << fmt(100 * p_rf, 1) << "% (random forest)   "
              << fmt(100 * p_lr, 1) << "% (logistic regression)\n";
    auto flags = url_red_flags(f);
    if (flags.empty()) std::cout << "  red flags: none found\n";
    else { std::cout << "  red flags:\n"; for (auto& s : flags) std::cout << "    - this URL " << s << "\n"; }
    return 0;
}

int predict_news(const std::string& text) {
    TfidfVectorizer vec;
    LogisticRegression lr;
    std::ifstream in("models/news_lr.txt");
    if (!vec.load("models/news_vectorizer.txt") || !in || !lr.load(in)) {
        std::cerr << "No trained model found. Run  ./trustlens run  first.\n";
        return 1;
    }
    SparseVec x = vec.transform(text);
    double p = lr.predict_proba(x);
    std::string verdict = p >= 0.75 ? "very likely FAKE" : p >= 0.5 ? "leans FAKE" : p >= 0.25 ? "leans REAL" : "very likely REAL";

    std::vector<NamedScore> contrib;
    for (auto& pr : x) contrib.push_back({vec.feature_name(pr.first), lr.weights()[pr.first] * pr.second});
    std::sort(contrib.begin(), contrib.end(), [](auto& a, auto& b) { return std::fabs(a.second) > std::fabs(b.second); });

    std::string shown = text.size() > 90 ? text.substr(0, 90) + "..." : text;
    std::cout << "\n  text     : " << shown << "\n"
              << "  verdict  : " << verdict << "\n"
              << "  P(fake)  : " << fmt(100 * p, 1) << "%\n  main reasons:\n";
    for (size_t i = 0; i < contrib.size() && i < 5; ++i)
        std::cout << "    - \"" << contrib[i].first << "\" pushes towards "
                  << (contrib[i].second > 0 ? "FAKE" : "REAL") << " (" << fmt(contrib[i].second, 3) << ")\n";
    std::cout << "  note: the model judges WRITING STYLE, not facts. Always verify with trusted sources.\n";
    return 0;
}

int demo() {
    banner("DEMO: URLs");
    for (auto* u : {"https://www.google.com/search?q=weather", "http://paypal-secure-login.xyz/verify/account?id=x83kd9",
                    "http://192.168.44.12/apple/signin.php", "http://bit.ly/3xYz9Qa",
                    "https://accounts.google.com/signin"})
        predict_url(u);
    banner("DEMO: NEWS");
    predict_news("The Ministry of Finance said on Tuesday that inflation figures would be reviewed over the coming "
                 "six months, according to a statement. Analysts cautioned that the impact remains uncertain.");
    predict_news("SHOCKING!!! You will not believe what the elites are hiding about the vaccine! Share this before "
                 "it gets deleted, the mainstream media will never tell you the truth!!!");
    return 0;
}

void print_help() {
    std::cout << "TrustLens - fake news & phishing classifier (C++17)\n\n"
                 "  ./trustlens run                    run the full pipeline (clean, EDA, SQL, ML, report)\n"
                 "  ./trustlens predict-url  \"<url>\"   classify one URL\n"
                 "  ./trustlens predict-news \"<text>\"  classify one article / headline\n"
                 "  ./trustlens demo                   run a handful of examples\n"
                 "  ./trustlens help                   this message\n\n"
                 "First time? Run  make data  to create practice CSV files.\n";
}

}  // namespace

int main(int argc, char** argv) {
    try {
        std::string cmd = argc > 1 ? argv[1] : "help";
        if (cmd == "run") return run_pipeline();
        if (cmd == "predict-url" && argc > 2) return predict_url(argv[2]);
        if (cmd == "predict-news" && argc > 2) return predict_news(argv[2]);
        if (cmd == "demo") return demo();
        print_help();
        return cmd == "help" ? 0 : 1;
    } catch (const std::exception& e) {
        std::cerr << "\nError: " << e.what() << "\n";
        return 1;
    }
}
