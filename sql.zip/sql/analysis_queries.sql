-- analysis_queries.sql
-- SQL used for EDA and for model error analysis.
-- The C++ program runs every block below (a block starts with "-- Q:").
-- You can also run them yourself:   sqlite3 -header -column db/trustlens.db < sql/analysis_queries.sql

-- Q: 1. Class balance of the news table
SELECT CASE label WHEN 1 THEN 'fake' ELSE 'real' END AS class,
       COUNT(*) AS articles,
       ROUND(100.0 * COUNT(*) / (SELECT COUNT(*) FROM news_articles), 1) AS percent
FROM news_articles
GROUP BY label;

-- Q: 2. Writing style: real vs fake (averages)
SELECT CASE label WHEN 1 THEN 'fake' ELSE 'real' END AS class,
       ROUND(AVG(word_count), 1)        AS avg_words,
       ROUND(AVG(exclamation_count), 2) AS avg_exclamations,
       ROUND(AVG(caps_ratio), 4)        AS avg_caps_ratio
FROM news_articles
GROUP BY label;

-- Q: 3. Share of fake articles per publisher (JOIN-free aggregation)
SELECT source,
       COUNT(*) AS articles,
       ROUND(100.0 * SUM(label) / COUNT(*), 1) AS pct_fake
FROM news_articles
GROUP BY source
ORDER BY pct_fake DESC;

-- Q: 4. Fake-news rate per subject
SELECT subject, COUNT(*) AS articles, ROUND(100.0 * AVG(label), 1) AS pct_fake
FROM news_articles
GROUP BY subject
ORDER BY pct_fake DESC;

-- Q: 5. Articles per year and class (date functions)
SELECT strftime('%Y', published_date) AS year,
       SUM(label = 0) AS real_articles,
       SUM(label = 1) AS fake_articles
FROM news_articles
GROUP BY year
ORDER BY year;

-- Q: 6. Phishing rate by top-level domain (only TLDs with 25+ URLs)
SELECT tld, COUNT(*) AS urls, ROUND(100.0 * AVG(label), 1) AS pct_phishing
FROM urls
GROUP BY tld
HAVING COUNT(*) >= 25
ORDER BY pct_phishing DESC;

-- Q: 7. Feature averages: phishing vs legitimate (JOIN urls + url_features)
SELECT CASE u.label WHEN 1 THEN 'phishing' ELSE 'legitimate' END AS class,
       ROUND(AVG(f.url_length), 1)      AS avg_length,
       ROUND(AVG(f.keyword_count), 2)   AS avg_keywords,
       ROUND(100 * AVG(f.uses_https), 1) AS pct_https,
       ROUND(100 * AVG(f.has_ip_host), 1) AS pct_ip_host,
       ROUND(100 * AVG(f.brand_mismatch), 1) AS pct_brand_mismatch
FROM urls u
JOIN url_features f ON f.url_id = u.url_id
GROUP BY u.label;

-- Q: 8. Window function: rank TLDs by number of phishing URLs
SELECT tld, phishing_urls, RANK() OVER (ORDER BY phishing_urls DESC) AS rnk
FROM (SELECT tld, SUM(label) AS phishing_urls FROM urls GROUP BY tld)
WHERE phishing_urls > 0
LIMIT 8;

-- Q: 9. Model leaderboard (uses the view v_model_leaderboard)
SELECT * FROM v_model_leaderboard;

-- Q: 10. Error analysis: which publishers does the fake-news model get wrong most often?
SELECT n.source,
       COUNT(*) AS test_articles,
       SUM(p.true_label <> p.predicted_label) AS mistakes,
       ROUND(100.0 * SUM(p.true_label <> p.predicted_label) / COUNT(*), 1) AS error_rate_pct
FROM predictions p
JOIN news_articles n ON n.article_id = p.item_id
WHERE p.task = 'fake_news' AND p.model = 'Logistic Regression'
GROUP BY n.source
ORDER BY error_rate_pct DESC;

-- Q: 11. Missed phishing sites (false negatives) - the dangerous mistakes
SELECT u.url, ROUND(p.probability, 3) AS predicted_prob
FROM predictions p
JOIN urls u ON u.url_id = p.item_id
WHERE p.task = 'phishing' AND p.model = 'Random Forest'
  AND p.true_label = 1 AND p.predicted_label = 0
ORDER BY p.probability ASC
LIMIT 8;

-- Q: 12. CTE: accuracy of the fake-news model for each subject
WITH scored AS (
    SELECT n.subject, (p.true_label = p.predicted_label) AS correct
    FROM predictions p
    JOIN news_articles n ON n.article_id = p.item_id
    WHERE p.task = 'fake_news' AND p.model = 'Logistic Regression'
)
SELECT subject, COUNT(*) AS n, ROUND(100.0 * AVG(correct), 1) AS accuracy_pct
FROM scored
GROUP BY subject
ORDER BY accuracy_pct;
