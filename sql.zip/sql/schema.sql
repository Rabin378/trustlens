-- schema.sql
-- Relational design for the TrustLens project (SQLite dialect).
--
--   news_articles  1 row per cleaned article
--   urls           1 row per cleaned URL
--   url_features   1 row per URL, the 21 engineered features  (1-to-1 with urls)
--   model_runs     1 row per trained model: its test metrics
--   predictions    1 row per test item per model (links back to news/urls)
--   scan_history   1 row per scan made through the website
--
-- Only the C++ program inserts data; this file only describes the structure.

DROP VIEW  IF EXISTS v_model_leaderboard;
DROP VIEW  IF EXISTS v_label_names;
DROP TABLE IF EXISTS scan_history;
DROP TABLE IF EXISTS predictions;
DROP TABLE IF EXISTS model_runs;
DROP TABLE IF EXISTS url_features;
DROP TABLE IF EXISTS urls;
DROP TABLE IF EXISTS news_articles;

CREATE TABLE news_articles (
    article_id        INTEGER PRIMARY KEY,
    title             TEXT    NOT NULL,
    body              TEXT    NOT NULL,
    subject           TEXT,
    source            TEXT,
    published_date    TEXT,
    label             INTEGER NOT NULL CHECK (label IN (0, 1)),   -- 1 = fake
    word_count        INTEGER NOT NULL,
    exclamation_count INTEGER NOT NULL,
    caps_ratio        REAL    NOT NULL
);

CREATE TABLE urls (
    url_id            INTEGER PRIMARY KEY,
    url               TEXT    NOT NULL UNIQUE,
    host              TEXT    NOT NULL,
    tld               TEXT,
    registered_domain TEXT,
    label             INTEGER NOT NULL CHECK (label IN (0, 1)),   -- 1 = phishing
    source            TEXT,
    collected_date    TEXT
);

CREATE TABLE url_features (
    url_id INTEGER PRIMARY KEY REFERENCES urls(url_id) ON DELETE CASCADE,
    url_length REAL NOT NULL,
    host_length REAL NOT NULL,
    path_length REAL NOT NULL,
    num_dots REAL NOT NULL,
    num_hyphens_host REAL NOT NULL,
    num_digits REAL NOT NULL,
    digit_ratio REAL NOT NULL,
    num_subdomains REAL NOT NULL,
    has_ip_host REAL NOT NULL,
    has_at_symbol REAL NOT NULL,
    uses_https REAL NOT NULL,
    num_query_params REAL NOT NULL,
    has_port REAL NOT NULL,
    keyword_count REAL NOT NULL,
    is_shortener REAL NOT NULL,
    suspicious_tld REAL NOT NULL,
    host_entropy REAL NOT NULL,
    double_slash_in_path REAL NOT NULL,
    num_special_chars REAL NOT NULL,
    brand_mismatch REAL NOT NULL,
    path_depth REAL NOT NULL
);

CREATE TABLE model_runs (
    run_id          INTEGER PRIMARY KEY AUTOINCREMENT,
    task            TEXT NOT NULL,          -- 'fake_news' or 'phishing'
    model           TEXT NOT NULL,
    accuracy        REAL,
    precision_score REAL,
    recall_score    REAL,
    f1              REAL,
    auc             REAL,
    cv_f1_mean      REAL,
    cv_f1_sd        REAL,
    tp              INTEGER,
    fp              INTEGER,
    tn              INTEGER,
    fn              INTEGER,
    trained_at      TEXT
);

CREATE TABLE predictions (
    pred_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    task            TEXT    NOT NULL,
    item_id         INTEGER NOT NULL,       -- article_id or url_id, depending on task
    model           TEXT    NOT NULL,
    true_label      INTEGER NOT NULL,
    predicted_label INTEGER NOT NULL,
    probability     REAL    NOT NULL
);

-- Every scan made through the website is logged here.
CREATE TABLE scan_history (
    scan_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    kind       TEXT NOT NULL CHECK (kind IN ('url', 'news')),
    input      TEXT NOT NULL,
    verdict    TEXT NOT NULL,
    score      REAL NOT NULL,           -- risk / P(fake) in percent
    scanned_at TEXT NOT NULL
);

-- Indexes: speed up the joins and GROUP BYs used in analysis_queries.sql
CREATE INDEX idx_news_label   ON news_articles(label);
CREATE INDEX idx_news_source  ON news_articles(source);
CREATE INDEX idx_urls_label   ON urls(label);
CREATE INDEX idx_urls_tld     ON urls(tld);
CREATE INDEX idx_pred_lookup  ON predictions(task, model, item_id);

-- A view is a saved query: handy for dashboards and for the report.
CREATE VIEW v_model_leaderboard AS
    SELECT task, model, ROUND(accuracy, 4) AS accuracy, ROUND(f1, 4) AS f1, ROUND(auc, 4) AS auc
    FROM model_runs
    ORDER BY task, f1 DESC;
