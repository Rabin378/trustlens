#!/bin/sh
# Quick check that the website backend works. Usage:  make test
# Starts the server on a spare port, calls each API endpoint, then stops it.
PORT=8765
./trustlens_server $PORT > /tmp/trustlens_smoke.log 2>&1 &
PID=$!
sleep 1
B=http://127.0.0.1:$PORT
FAIL=0
check() {  # name, expected-substring, actual
  case "$3" in *"$2"*) echo "  ok    $1";; *) echo "  FAIL  $1"; FAIL=1;; esac
}
check "home page"        "TrustLens"      "$(curl -s $B/)"
check "health"           '"status":"ok"'  "$(curl -s $B/api/health)"
check "overview"         '"articles"'     "$(curl -s $B/api/overview)"
check "phishing URL"     '"phishing"'     "$(curl -s -X POST $B/api/scan-url -d '{"url":"http://paypal-secure-login.xyz/verify/account"}')"
check "news checker"     '"p_fake"'       "$(curl -s -X POST $B/api/check-news -d '{"text":"SHOCKING!!! They are hiding the truth, share before it is deleted!!!"}')"
check "bad input -> 400" '"error"'        "$(curl -s -X POST $B/api/scan-url -d '{"url":"hello"}')"
check "dataset browser"  '"rows"'         "$(curl -s "$B/api/data/news?per=5")"
check "sql lab"          '"columns"'      "$(curl -s $B/api/sql-lab/1)"
check "404 page"         "404"            "$(curl -s $B/does-not-exist)"
kill $PID 2>/dev/null
[ $FAIL -eq 0 ] && echo "All checks passed." || { echo "Some checks FAILED (see /tmp/trustlens_smoke.log)"; exit 1; }
