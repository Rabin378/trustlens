// explorer.js - browse the SQL tables: search, filters, paging, detail popup
(function () {
  'use strict';
  var el = TL.el, $ = TL.$, I = TL.I;
  $('#eic-news').innerHTML = I.news; $('#eic-urls').innerHTML = I.link;

  var state = { tab: 'news', page: 1, q: '', label: '', extra: '' };
  var seq = 0;

  var CFG = {
    news: {
      api: '/api/data/news', extraParam: 'subject', extraAll: 'All subjects',
      labels: [['', 'All labels'], ['0', 'Real'], ['1', 'Fake']],
      head: ['ID', 'Headline', 'Subject', 'Publisher', 'Date', 'Label'],
      badge: function (l) { return l ? ['fake', 'Fake'] : ['real', 'Real']; }
    },
    urls: {
      api: '/api/data/urls', extraParam: 'tld', extraAll: 'All endings',
      labels: [['', 'All labels'], ['0', 'Legitimate'], ['1', 'Phishing']],
      head: ['ID', 'Address', 'Ending', 'Source', 'Date', 'Label'],
      badge: function (l) { return l ? ['phishing', 'Phishing'] : ['safe', 'Legitimate']; }
    }
  };

  function fillSelect(sel, pairs, keep) {
    TL.clear(sel);
    pairs.forEach(function (p) { sel.appendChild(el('option', { value: p[0], text: p[1] })); });
    sel.value = keep || '';
  }

  function render(d) {
    var c = CFG[state.tab];
    var head = $('#thead'), body = $('#tbody');
    TL.clear(head).appendChild(el('tr', {}, c.head.map(function (h) { return el('th', { text: h }); })));
    TL.clear(body);
    if (!d.rows.length) body.appendChild(el('tr', {}, [el('td', { colspan: '6', class: 'muted', text: 'No results. Try a different search or filter.' })]));
    d.rows.forEach(function (r) {
      var b = c.badge(r.label);
      var main = state.tab === 'news'
        ? el('td', {}, [el('div', { style: 'font-weight:650', text: r.title }), el('div', { class: 'small muted ellip', text: r.snippet + '…' })])
        : el('td', { class: 'mono ellip', title: r.url, text: r.url });
      var tr = el('tr', { class: 'clickable', tabindex: '0', role: 'button', 'aria-label': 'Open details for item ' + r.id }, [
        el('td', { class: 'muted', text: String(r.id) }), main,
        el('td', { text: state.tab === 'news' ? r.subject : '.' + r.tld }),
        el('td', { text: r.source }), el('td', { class: 'nowrap', text: r.date }),
        el('td', {}, [el('span', { class: 'badge ' + b[0], text: b[1] })])
      ]);
      function open() { showDetail(r.id); }
      tr.addEventListener('click', open);
      tr.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); open(); } });
      body.appendChild(tr);
    });
    $('#pager-info').textContent = TL.num(d.total) + ' results · page ' + d.page + ' of ' + d.pages;
    $('#prev').disabled = d.page <= 1; $('#next').disabled = d.page >= d.pages;
    state.page = d.page;
  }

  function load(keepOptions) {
    var c = CFG[state.tab], my = ++seq;
    var qs = new URLSearchParams({ page: state.page, per: 12, q: state.q, label: state.label });
    if (state.extra) qs.set(c.extraParam, state.extra);
    TL.api(c.api + '?' + qs.toString()).then(function (d) {
      if (my !== seq) return;   // a newer request already replaced this one
      if (!keepOptions) {
        var pairs = [['', c.extraAll]].concat(d.filter_options.map(function (o) { return [o.value, state.tab === 'urls' ? '.' + o.value : o.value]; }));
        fillSelect($('#f-extra'), pairs, state.extra);
      }
      render(d);
    }).catch(function (e) { TL.toast(e.message, true); });
  }

  function setTab(t) {
    state = { tab: t, page: 1, q: '', label: '', extra: '' };
    TL.$$('.tab').forEach(function (b) { b.setAttribute('aria-selected', b.getAttribute('data-tab') === t ? 'true' : 'false'); });
    $('#q').value = '';
    $('#q').placeholder = t === 'news' ? 'Search headlines and text...' : 'Search addresses, e.g. paypal or .xyz';
    fillSelect($('#f-label'), CFG[t].labels, '');
    load(false);
  }

  // ---- detail popup ----
  function predictionBlock(preds, trueLabel, names) {
    if (!preds.length) return el('p', { class: 'small muted', text: 'This row was part of the training data, so no held-out prediction was stored for it.' });
    var wrap = el('div', {});
    preds.forEach(function (p) {
      var ok = p.predicted_label === trueLabel;
      var pct = Math.round(p.probability * 1000) / 10;
      var f = el('span', { class: 'fill ' + (ok ? 'ok' : 'danger') });
      requestAnimationFrame(function () { requestAnimationFrame(function () { f.style.width = Math.max(1.5, pct) + '%'; }); });
      wrap.appendChild(el('div', { class: 'meter', style: 'grid-template-columns:170px 1fr 120px' }, [
        el('span', { text: p.model }), el('span', { class: 'track' }, [f]),
        el('span', { class: 'small' }, [el('b', { text: pct + '% ' + names[1].toLowerCase() }), ' ', el('span', { class: 'badge ' + (ok ? 'ok' : 'danger'), text: ok ? 'correct' : 'wrong' })])
      ]));
    });
    return wrap;
  }

  function showDetail(id) {
    var c = CFG[state.tab], isNews = state.tab === 'news';
    TL.api(c.api + '/' + id).then(function (d) {
      var it = d.item, names = isNews ? ['Real', 'Fake'] : ['Legitimate', 'Phishing'];
      var b = c.badge(it.label);
      var body = el('div', { class: 'stack' });
      if (isNews) {
        body.appendChild(el('div', { class: 'article-body', text: it.body }));
        var kv = el('dl', { class: 'kv' });
        [['Subject', it.subject], ['Publisher', it.source], ['Date', it.date], ['Words', it.word_count], ['Exclamation marks', it.exclamation_count], ['Capital letters', it.caps_pct + '%']].forEach(function (r) {
          kv.appendChild(el('dt', { text: r[0] })); kv.appendChild(el('dd', { text: String(r[1]) }));
        });
        body.appendChild(kv);
      } else {
        body.appendChild(el('div', { class: 'article-body mono', text: it.url }));
        var kv2 = el('dl', { class: 'kv' });
        [['Host', it.host], ['Main domain', it.registered_domain], ['Ending', '.' + it.tld], ['Source', it.source], ['Collected', it.date]].forEach(function (r) {
          kv2.appendChild(el('dt', { text: r[0] })); kv2.appendChild(el('dd', { text: String(r[1]) }));
        });
        body.appendChild(kv2);
        body.appendChild(el('a', { class: 'btn btn-ghost', href: '/scanner?url=' + encodeURIComponent(it.url), text: 'Scan this address live' }));
        var f = d.features || {};
        var rows = Object.keys(f).filter(function (k) { return k !== 'url_id'; }).map(function (k) {
          return el('tr', {}, [el('td', { class: 'mono', text: k }), el('td', { class: 'num', text: String(f[k]) })]);
        });
        body.appendChild(el('details', {}, [el('summary', { text: 'The 21 engineered features (SQL table url_features)' }),
          el('div', { class: 'table-wrap' }, [el('table', { class: 'table' }, [el('tbody', {}, rows)])])]));
      }
      body.appendChild(el('div', {}, [el('h3', { text: 'What the models predicted' }), predictionBlock(d.predictions, it.label, names)]));
      TL.openModal(isNews ? it.title : 'Web address #' + it.id, body, [el('span', { class: 'badge ' + b[0], text: 'Truth: ' + b[1] })]);
    }).catch(function (e) { TL.toast(e.message, true); });
  }

  // ---- events ----
  TL.$$('.tab').forEach(function (b) { b.addEventListener('click', function () { setTab(b.getAttribute('data-tab')); }); });
  var timer = null;
  $('#q').addEventListener('input', function () {
    clearTimeout(timer);
    var v = this.value;
    timer = setTimeout(function () { state.q = v; state.page = 1; load(true); }, 280);
  });
  $('#f-label').addEventListener('change', function () { state.label = this.value; state.page = 1; load(true); });
  $('#f-extra').addEventListener('change', function () { state.extra = this.value; state.page = 1; load(true); });
  $('#prev').addEventListener('click', function () { state.page = Math.max(1, state.page - 1); load(true); });
  $('#next').addEventListener('click', function () { state.page += 1; load(true); });

  setTab('news');
})();
