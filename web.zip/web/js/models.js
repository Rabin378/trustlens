// models.js - leaderboard, confusion matrix, ROC curve, feature importance
(function () {
  'use strict';
  var el = TL.el, $ = TL.$;
  var TASK = { fake_news: { name: 'Fake news', neg: 'real', pos: 'fake', deployed: 'Logistic Regression' },
               phishing: { name: 'Phishing', neg: 'legitimate', pos: 'phishing', deployed: 'Random Forest' } };
  var runs = [], selected = null;

  function pretty(s) {
    var map = { '<exclamation_rate>': 'exclamation marks', '<caps_ratio>': 'CAPITAL LETTERS', '<article_length>': 'text length' };
    return map[s] || s.replace(/_/g, ' ');
  }

  function metric(t, v) { return el('div', { class: 'tile' }, [el('div', { class: 't', text: t }), el('div', { class: 'n', text: v })]); }

  function showDetail(run) {
    selected = run;
    TL.$$('tr[data-run]').forEach(function (tr) { tr.classList.toggle('selected', tr.getAttribute('data-run') === String(run.run_id)); });
    var t = TASK[run.task];
    $('#d-title').textContent = run.model + ' · ' + t.name;
    var badge = $('#d-badge'); TL.clear(badge);
    if (run.model === t.deployed) badge.appendChild(el('span', { class: 'badge ok', text: 'Used on the website' }));
    var tiles = $('#d-tiles'); TL.clear(tiles);
    [['Accuracy', run.accuracy], ['Precision', run.precision], ['Recall', run.recall], ['F1', run.f1], ['AUC', run.auc]].forEach(function (m) { tiles.appendChild(metric(m[0], (m[1] * 100).toFixed(1) + '%')); });
    tiles.appendChild(metric('5-fold CV F1', (run.cv_f1_mean * 100).toFixed(1) + ' ± ' + (run.cv_f1_sd * 100).toFixed(1)));
    Charts.confusion($('#d-matrix'), run, [t.neg, t.pos]);
    TL.clear($('#d-roc')).appendChild(el('div', { class: 'skeleton', style: 'height:300px' }));
    TL.api('/api/roc?task=' + run.task + '&model=' + encodeURIComponent(run.model)).then(function (r) {
      if (selected !== run) return;
      Charts.line($('#d-roc'), r.points, { color: 'primary', xLabel: 'False alarm rate', yLabel: 'Detection rate (recall)', aria: 'ROC curve of ' + run.model });
    }).catch(function () { TL.clear($('#d-roc')).appendChild(el('p', { class: 'muted', text: 'ROC data not available.' })); });
  }

  function board(task) {
    var list = runs.filter(function (r) { return r.task === task; });
    var best = Math.max.apply(null, list.map(function (r) { return r.f1; }));
    var rows = list.map(function (r) {
      var tr = el('tr', { class: 'clickable' + (r.f1 === best ? ' best' : ''), 'data-run': String(r.run_id), tabindex: '0', role: 'button' }, [
        el('td', {}, [r.model, r.model === TASK[task].deployed ? el('span', { class: 'badge info', style: 'margin-left:8px', text: 'live' }) : null]),
        el('td', { class: 'num', text: (r.accuracy * 100).toFixed(1) }), el('td', { class: 'num', text: (r.precision * 100).toFixed(1) }),
        el('td', { class: 'num', text: (r.recall * 100).toFixed(1) }), el('td', { class: 'num', text: (r.f1 * 100).toFixed(1) }),
        el('td', { class: 'num', text: (r.auc * 100).toFixed(1) })
      ]);
      tr.addEventListener('click', function () { showDetail(r); });
      tr.addEventListener('keydown', function (e) { if (e.key === 'Enter') showDetail(r); });
      return tr;
    });
    return el('div', { class: 'card' }, [
      el('div', { class: 'card-head' }, [el('h3', { text: TASK[task].name + ' models' }), el('span', { class: 'muted small', text: 'green row = best F1 · “live” = used by the website' })]),
      el('div', { class: 'table-wrap' }, [el('table', { class: 'table' }, [
        el('thead', {}, [el('tr', {}, ['Model', 'Acc.', 'Prec.', 'Recall', 'F1', 'AUC'].map(function (h, i) { return el('th', { class: i ? 'num' : '', text: h }); }))]),
        el('tbody', {}, rows)])])
    ]);
  }

  TL.api('/api/models').then(function (d) {
    runs = d.runs;
    var boards = $('#boards');
    ['fake_news', 'phishing'].forEach(function (t) { boards.appendChild(board(t)); });
    var first = runs.filter(function (r) { return r.task === 'phishing' && r.model === TASK.phishing.deployed; })[0] || runs[0];
    if (first) showDetail(first);

    var imp = d.url_importance.slice(0, 12);
    if (imp.length) Charts.hbars($('#m-importance'), imp.map(function (x) { return { label: pretty(x.feature), value: Math.round(x.importance * 1000) / 10 }; }), { max: Math.max(imp[0].importance * 100, 1), unit: '%' });

    function words(dir, sel, color) {
      var w = d.news_words.filter(function (x) { return x.direction === dir; }).slice(0, 10);
      var max = Math.max.apply(null, w.map(function (x) { return Math.abs(x.weight); }).concat([0.1]));
      Charts.hbars($(sel), w.map(function (x) { return { label: pretty(x.term), value: Math.round(Math.abs(x.weight) * 100) / 100, color: color }; }), { max: max, unit: '', compact: true });
    }
    words('fake', '#m-fake', 'danger'); words('real', '#m-real', 'ok');
  }).catch(function (e) { TL.toast('Could not load models: ' + e.message, true); });
})();
