// dashboard.js - charts for the dashboard page, all fed by SQL queries on the server
(function () {
  'use strict';
  var $ = TL.$, el = TL.el;

  function rateColor(r) { return r.value >= 50 ? 'danger' : 'ok'; }

  Promise.all([TL.api('/api/overview'), TL.api('/api/analytics')]).then(function (res) {
    var o = res[0], a = res[1];

    TL.countUp($('#k-articles'), o.articles);
    TL.countUp($('#k-urls'), o.urls);
    TL.countUp($('#k-fake'), o.fake_pct, { decimals: 1, suffix: '%' });
    TL.countUp($('#k-phish'), o.phishing_pct, { decimals: 1, suffix: '%' });

    // ---- fake news ----
    Charts.donut($('#c-news-balance'), a.news_balance.map(function (r) {
      return { label: r.class === 'fake' ? 'Fake' : 'Real', value: r.n, color: r.class === 'fake' ? 'danger' : 'ok' };
    }), { big: TL.num(o.articles), small: 'articles', aria: 'Fake versus real articles' });

    var st = {}; a.news_style.forEach(function (r) { st[r.class] = r; });
    Charts.paired($('#c-style'), [{ name: 'Real', color: 'ok' }, { name: 'Fake', color: 'danger' }], [
      { label: 'Average words per article', values: [st.real.avg_words, st.fake.avg_words], unit: '' },
      { label: 'Average exclamation marks', values: [st.real.avg_exclamations, st.fake.avg_exclamations], unit: '' },
      { label: 'Share of capital letters', values: [st.real.avg_caps_pct, st.fake.avg_caps_pct], unit: '%' }
    ]);

    Charts.hbars($('#c-source'), a.news_by_source.map(function (r) { return { label: r.source, value: r.pct_fake, note: r.articles + ' articles' }; }), { max: 100, colorFn: rateColor });
    Charts.hbars($('#c-subject'), a.news_by_subject.map(function (r) { return { label: r.subject, value: r.pct_fake, note: r.articles + ' articles' }; }), { max: 100, colorFn: rateColor });

    Charts.columns($('#c-year'), a.news_by_year.map(function (r) { return r.year; }), [
      { name: 'Real', color: 'ok', values: a.news_by_year.map(function (r) { return r.real_articles; }) },
      { name: 'Fake', color: 'danger', values: a.news_by_year.map(function (r) { return r.fake_articles; }) }
    ], { aria: 'Articles per year' });

    // ---- phishing ----
    Charts.donut($('#c-url-balance'), a.url_balance.map(function (r) {
      return { label: r.class === 'phishing' ? 'Phishing' : 'Legitimate', value: r.n, color: r.class === 'phishing' ? 'danger' : 'ok' };
    }), { big: TL.num(o.urls), small: 'addresses', aria: 'Phishing versus legitimate addresses' });

    var uf = {}; a.url_features.forEach(function (r) { uf[r.class] = r; });
    var L = uf.legitimate, P = uf.phishing;
    Charts.paired($('#c-flags'), [{ name: 'Legit', color: 'ok' }, { name: 'Phishing', color: 'danger' }], [
      { label: 'Use HTTPS', values: [L.pct_https, P.pct_https], unit: '%' },
      { label: 'Brand name on the wrong domain', values: [L.pct_brand_mismatch, P.pct_brand_mismatch], unit: '%' },
      { label: 'Suspicious ending (.xyz, .top ...)', values: [L.pct_bad_tld, P.pct_bad_tld], unit: '%' },
      { label: 'Raw IP address as host', values: [L.pct_ip_host, P.pct_ip_host], unit: '%' },
      { label: 'Average “urgent” keywords', values: [L.avg_keywords, P.avg_keywords], unit: '' }
    ]);
    $('#c-flags-note').textContent = 'HTTPS is not a safety guarantee: ' + P.pct_https + '% of phishing addresses use it too.';

    Charts.hbars($('#c-tld'), a.urls_by_tld.map(function (r) { return { label: '.' + r.tld, value: r.pct_phishing, note: r.urls + ' addresses' }; }), { max: 100, colorFn: rateColor });

    // ---- scans ----
    var box = $('#c-scans');
    if (!a.scans_by_verdict.length) {
      box.appendChild(el('p', { class: 'muted', style: 'margin:0' }, ['No scans yet. ', el('a', { href: '/scanner', text: 'Try the scanner' }), ' and they will show up here.']));
    } else {
      var kinds = {};
      a.scans_by_verdict.forEach(function (r) { (kinds[r.kind] = kinds[r.kind] || []).push(r); });
      Object.keys(kinds).forEach(function (k) {
        var row = el('div', { class: 'row', style: 'margin:6px 0' }, [el('b', { text: k === 'url' ? 'Links' : 'Articles', style: 'min-width:90px' })]);
        kinds[k].forEach(function (r) { row.appendChild(el('span', { class: 'badge ' + r.verdict, text: r.verdict.replace('_', ' ') + ': ' + r.n })); });
        box.appendChild(row);
      });
      box.appendChild(el('p', { class: 'small muted', style: 'margin:12px 0 0', text: TL.num(o.scans) + ' scans in total, stored in the scan_history table.' }));
    }
  }).catch(function (e) {
    TL.toast('Could not load dashboard data: ' + e.message, true);
  });
})();
