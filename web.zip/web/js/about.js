(function () { var n = TL.$('#ab1'); if (n) { n.innerHTML = TL.I.alert; n.style.cssText = 'display:inline-grid;flex:none'; } })();
