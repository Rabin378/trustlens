// sqllab.js - run the project's prepared SQL queries and show the results
(function () {
  'use strict';
  var el = TL.el, $ = TL.$;
  var queries = [], current = 0, currentSql = '';

  var KW = /^(select|from|where|group|by|order|having|limit|join|left|inner|on|as|and|or|not|in|is|null|case|when|then|else|end|with|over|desc|asc|distinct|union|like|between|exists|rank|count|sum|avg|round|min|max|strftime|row_number)$/i;
  var FN = /^(count|sum|avg|round|min|max|strftime|rank|row_number)$/i;

  // Simple syntax highlighter: builds DOM nodes with textContent, so nothing can inject HTML.
  function highlight(sql) {
    var pre = $('#q-code'); TL.clear(pre);
    var re = /(--[^\n]*)|('(?:[^']|'')*')|(\b\d+(?:\.\d+)?\b)|([A-Za-z_][A-Za-z_0-9]*)|(\s+|[\s\S])/g, m;
    while ((m = re.exec(sql)) !== null) {
      var t = m[0], cls = null;
      if (m[1]) cls = 'cm'; else if (m[2]) cls = 'str'; else if (m[3]) cls = 'num';
      else if (m[4] && FN.test(t)) cls = 'fn'; else if (m[4] && KW.test(t)) cls = 'kw';
      pre.appendChild(cls ? el('span', { class: cls, text: t }) : document.createTextNode(t));
    }
  }

  function run(id) {
    current = id;
    TL.$$('.query-btn').forEach(function (b) { b.setAttribute('aria-current', b.getAttribute('data-id') === String(id) ? 'true' : 'false'); });
    TL.api('/api/sql-lab/' + id).then(function (d) {
      if (current !== id) return;
      currentSql = d.sql;
      $('#q-title').textContent = d.title;
      highlight(d.sql);
      var head = $('#r-head'), body = $('#r-body');
      TL.clear(head).appendChild(el('tr', {}, d.result.columns.map(function (c) { return el('th', { text: c }); })));
      TL.clear(body);
      d.result.rows.forEach(function (r) {
        body.appendChild(el('tr', {}, r.map(function (v) { return el('td', { class: typeof v === 'number' ? 'num' : '', text: v === null ? 'NULL' : String(v) }); })));
      });
      if (!d.result.rows.length) body.appendChild(el('tr', {}, [el('td', { colspan: String(d.result.columns.length || 1), class: 'muted', text: 'The query returned no rows.' })]));
      $('#q-count').textContent = d.result.rows.length + ' row' + (d.result.rows.length === 1 ? '' : 's');
    }).catch(function (e) { TL.toast(e.message, true); });
  }

  $('#copy-sql').addEventListener('click', function () {
    if (navigator.clipboard) navigator.clipboard.writeText(currentSql).then(function () { TL.toast('SQL copied to clipboard'); }, function () { TL.toast('Could not copy', true); });
  });

  TL.api('/api/sql-lab').then(function (d) {
    queries = d.queries;
    var list = $('#qlist');
    queries.forEach(function (q) {
      list.appendChild(el('button', { class: 'query-btn', role: 'listitem', 'data-id': String(q.id), text: q.title, onclick: function () { run(q.id); } }));
    });
    var start = parseInt((location.hash.match(/q=(\d+)/) || [])[1] || '1', 10);
    run(Math.min(Math.max(start, 1), queries.length));
  }).catch(function (e) { TL.toast(e.message, true); });
})();
