// charts.js - a tiny chart toolkit written for this site (no external libraries).
// Everything is drawn with plain HTML/SVG and coloured through CSS variables,
// so charts follow the light/dark theme automatically.
(function () {
  'use strict';
  var el = TL.el, NS = 'http://www.w3.org/2000/svg';

  function svg(tag, attrs, children) {
    var n = document.createElementNS(NS, tag);
    Object.keys(attrs || {}).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    (children || []).forEach(function (c) { n.appendChild(c); });
    return n;
  }
  function svgText(str, attrs) { var t = svg('text', attrs); t.textContent = str; return t; }
  var COLORS = { primary: 'var(--primary)', accent: 'var(--accent)', danger: 'var(--danger)', ok: 'var(--ok)', warn: 'var(--warn)', muted: 'var(--muted)' };

  // --- horizontal bars: rows = [{label, value, note?, color?}] -------------------
  function hbars(host, rows, opts) {
    opts = opts || {};
    var max = opts.max || Math.max.apply(null, rows.map(function (r) { return r.value; }).concat([1]));
    var unit = opts.unit === undefined ? '%' : opts.unit;
    TL.clear(host);
    var wrap = el('div', { class: 'hbars' + (opts.compact ? ' compact' : '') });
    rows.forEach(function (r) {
      var color = r.color || (opts.colorFn ? opts.colorFn(r) : 'primary');
      var fill = el('span', { class: 'fill ' + (color === 'primary' ? '' : color) });
      if (color === 'primary') fill.style.background = 'var(--primary)';
      wrap.appendChild(el('div', { class: 'hbar', title: r.note || '' }, [
        el('span', { class: 'lab', text: r.label }),
        el('span', { class: 'track' }, [fill]),
        el('span', { class: 'val', text: (opts.format ? opts.format(r.value) : r.value) + unit })
      ]));
      requestAnimationFrame(function () { requestAnimationFrame(function () { fill.style.width = Math.max(1.5, 100 * r.value / max) + '%'; }); });
    });
    host.appendChild(wrap);
  }

  // --- donut: segs = [{label, value, color}] ---------------------------------------
  function donut(host, segs, opts) {
    opts = opts || {};
    TL.clear(host);
    var total = segs.reduce(function (s, x) { return s + x.value; }, 0) || 1;
    var R = 56, C = 2 * Math.PI * R, offset = 0;
    var root = svg('svg', { viewBox: '0 0 160 160', role: 'img', 'aria-label': opts.aria || 'Donut chart' });
    root.appendChild(svg('circle', { cx: 80, cy: 80, r: R, fill: 'none', stroke: 'var(--surface-2)', 'stroke-width': 22 }));
    segs.forEach(function (s) {
      var len = C * s.value / total;
      root.appendChild(svg('circle', {
        cx: 80, cy: 80, r: R, fill: 'none', stroke: COLORS[s.color] || s.color, 'stroke-width': 22,
        'stroke-dasharray': len + ' ' + (C - len), 'stroke-dashoffset': -offset, transform: 'rotate(-90 80 80)'
      }));
      offset += len;
    });
    root.appendChild(svgText(opts.big || TL.num(total), { x: 80, y: 82, 'text-anchor': 'middle', style: 'font-size:22px;font-weight:800;fill:var(--text)' }));
    root.appendChild(svgText(opts.small || 'total', { x: 80, y: 99, 'text-anchor': 'middle', style: 'font-size:10px' }));
    var legend = el('div', { class: 'legend', style: 'flex-direction:column;gap:8px;margin:0' }, segs.map(function (s) {
      var i = el('i'); i.style.background = COLORS[s.color] || s.color;
      return el('span', {}, [i, s.label + ' — ', el('b', { text: TL.num(s.value) }), ' (' + (100 * s.value / total).toFixed(1) + '%)']);
    }));
    host.appendChild(el('div', { class: 'donut-wrap' }, [root, legend]));
  }

  // --- grouped columns: cats = ['2023',...], series = [{name,color,values}] --------------
  function columns(host, cats, series, opts) {
    opts = opts || {};
    TL.clear(host);
    var W = 560, H = 250, pl = 38, pr = 10, pt = 14, pb = 34;
    var max = 0;
    series.forEach(function (s) { s.values.forEach(function (v) { max = Math.max(max, v); }); });
    max = Math.ceil(max / 50) * 50 || 1;
    var root = svg('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'chart-svg', role: 'img', 'aria-label': opts.aria || 'Column chart' });
    for (var g = 0; g <= 4; g++) {
      var y = pt + (H - pt - pb) * g / 4;
      root.appendChild(svg('line', { x1: pl, x2: W - pr, y1: y, y2: y, class: 'grid-line' }));
      root.appendChild(svgText(String(Math.round(max * (1 - g / 4))), { x: pl - 6, y: y + 4, 'text-anchor': 'end' }));
    }
    var gw = (W - pl - pr) / cats.length, bw = Math.min(34, gw / (series.length + 1));
    cats.forEach(function (c, i) {
      var gx = pl + gw * i + gw / 2 - (bw * series.length) / 2;
      series.forEach(function (s, j) {
        var h = (H - pt - pb) * s.values[i] / max;
        var r = svg('rect', { x: gx + j * bw, y: H - pb - h, width: bw - 3, height: Math.max(h, 0), rx: 4, fill: COLORS[s.color] || s.color });
        r.appendChild(svg('title', {}, [])); r.firstChild.textContent = s.name + ' ' + c + ': ' + s.values[i];
        root.appendChild(r);
        root.appendChild(svgText(String(s.values[i]), { x: gx + j * bw + (bw - 3) / 2, y: H - pb - h - 4, 'text-anchor': 'middle' }));
      });
      root.appendChild(svgText(c, { x: pl + gw * i + gw / 2, y: H - 12, 'text-anchor': 'middle' }));
    });
    host.appendChild(root);
    var legend = el('div', { class: 'legend' }, series.map(function (s) {
      var i = el('i'); i.style.background = COLORS[s.color] || s.color; return el('span', {}, [i, s.name]);
    }));
    host.appendChild(legend);
  }

  // --- paired bars: compare two groups on several metrics ----------------------------------
  // groups = [{name,color}], metrics = [{label, values:[a,b], unit}]
  function paired(host, groups, metrics) {
    TL.clear(host);
    metrics.forEach(function (m) {
      var max = Math.max.apply(null, m.values.concat([1e-9]));
      var block = el('div', { style: 'margin-bottom:16px' }, [el('div', { class: 'small', style: 'font-weight:650;margin-bottom:6px', text: m.label })]);
      m.values.forEach(function (v, i) {
        var f = el('span', { class: 'fill' }); f.style.background = COLORS[groups[i].color] || groups[i].color;
        block.appendChild(el('div', { class: 'hbar', style: 'margin:4px 0;grid-template-columns:78px 1fr 70px' }, [
          el('span', { class: 'lab muted', text: groups[i].name }), el('span', { class: 'track' }, [f]),
          el('span', { class: 'val', text: v + (m.unit || '') })]));
        requestAnimationFrame(function () { requestAnimationFrame(function () { f.style.width = Math.max(1.5, 100 * v / max) + '%'; }); });
      });
      host.appendChild(block);
    });
  }

  // --- semicircle gauge (0..100) ---------------------------------------------------------------
  function gauge(host, value, opts) {
    opts = opts || {};
    TL.clear(host);
    var color = COLORS[opts.color] || opts.color || 'var(--primary)';
    var path = 'M 20 100 A 80 80 0 0 1 180 100';
    var bg = svg('path', { d: path, fill: 'none', stroke: 'var(--surface)', 'stroke-width': 18, 'stroke-linecap': 'round', pathLength: 100 });
    var fg = svg('path', { d: path, fill: 'none', stroke: color, 'stroke-width': 18, 'stroke-linecap': 'round', pathLength: 100, 'stroke-dasharray': '0 100', style: 'transition:stroke-dasharray 1s cubic-bezier(.2,.8,.2,1)' });
    var root = svg('svg', { viewBox: '0 0 200 112', role: 'img', 'aria-label': (opts.caption || 'Score') + ' ' + value + ' percent' }, [bg, fg]);
    host.appendChild(root);
    host.appendChild(el('div', { class: 'g-num', text: value + '%' }));
    host.appendChild(el('div', { class: 'g-cap', text: opts.caption || '' }));
    requestAnimationFrame(function () { requestAnimationFrame(function () { fg.setAttribute('stroke-dasharray', Math.max(0.6, value) + ' 100'); }); });
  }

  // --- line chart (used for ROC curves) ------------------------------------------------------------
  function line(host, points, opts) {
    opts = opts || {};
    TL.clear(host);
    var W = 420, H = 380, pl = 46, pr = 14, pt = 12, pb = 44, w = W - pl - pr, h = H - pt - pb;
    var root = svg('svg', { viewBox: '0 0 ' + W + ' ' + H, class: 'chart-svg', role: 'img', 'aria-label': opts.aria || 'Line chart' });
    for (var g = 0; g <= 5; g++) {
      var v = g / 5, x = pl + w * v, y = pt + h * (1 - v);
      root.appendChild(svg('line', { x1: pl, x2: W - pr, y1: y, y2: y, class: 'grid-line' }));
      root.appendChild(svg('line', { x1: x, x2: x, y1: pt, y2: H - pb, class: 'grid-line' }));
      root.appendChild(svgText(v.toFixed(1), { x: pl - 7, y: y + 4, 'text-anchor': 'end' }));
      root.appendChild(svgText(v.toFixed(1), { x: x, y: H - pb + 16, 'text-anchor': 'middle' }));
    }
    root.appendChild(svg('line', { x1: pl, y1: pt + h, x2: pl + w, y2: pt, stroke: 'var(--muted)', 'stroke-dasharray': '5 5', 'stroke-width': 1.2 }));
    var d = points.map(function (p, i) { return (i ? 'L' : 'M') + (pl + w * p[0]).toFixed(1) + ' ' + (pt + h * (1 - p[1])).toFixed(1); }).join(' ');
    root.appendChild(svg('path', { d: d + ' L ' + (pl + w) + ' ' + (pt + h) + ' L ' + pl + ' ' + (pt + h) + ' Z', fill: COLORS[opts.color] || 'var(--primary)', opacity: 0.12 }));
    root.appendChild(svg('path', { d: d, fill: 'none', stroke: COLORS[opts.color] || 'var(--primary)', 'stroke-width': 3, 'stroke-linejoin': 'round' }));
    root.appendChild(svgText(opts.xLabel || '', { x: pl + w / 2, y: H - 6, 'text-anchor': 'middle', style: 'font-weight:600' }));
    var yl = svgText(opts.yLabel || '', { x: 12, y: pt + h / 2, 'text-anchor': 'middle', transform: 'rotate(-90 12 ' + (pt + h / 2) + ')', style: 'font-weight:600' });
    root.appendChild(yl);
    host.appendChild(root);
  }

  // --- 2x2 confusion matrix ---------------------------------------------------------------------------
  function confusion(host, m, names) {
    TL.clear(host);
    var total = m.tn + m.fp + m.fn + m.tp || 1;
    function cell(v, good, label) {
      var c = el('div', { class: 'c ' + (good ? 'good' : 'bad') }, [el('b', { text: TL.num(v) }), el('span', { text: label + ' · ' + (100 * v / total).toFixed(1) + '%' })]);
      c.style.setProperty('--k', Math.min(1, v / (good ? Math.max(m.tn, m.tp) : Math.max(m.fp, m.fn, 1))));
      return c;
    }
    host.appendChild(el('div', { class: 'matrix' }, [
      el('div', { class: 'h' }), el('div', { class: 'h', text: 'Predicted ' + names[0] }), el('div', { class: 'h', text: 'Predicted ' + names[1] }),
      el('div', { class: 'h', text: 'Actually ' + names[0] }), cell(m.tn, true, 'correct'), cell(m.fp, false, 'false alarm'),
      el('div', { class: 'h', text: 'Actually ' + names[1] }), cell(m.fn, false, 'missed'), cell(m.tp, true, 'caught')
    ]));
  }

  window.Charts = { hbars: hbars, donut: donut, columns: columns, paired: paired, gauge: gauge, line: line, confusion: confusion };
})();
