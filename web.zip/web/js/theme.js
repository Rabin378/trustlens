// theme.js - runs in <head> BEFORE the page paints, so there is no light/dark flash.
(function () {
  var saved = null;
  try { saved = localStorage.getItem('tl-theme'); } catch (e) {}
  var dark = saved ? saved === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
  document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
})();
