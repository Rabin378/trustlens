// home.js - landing page: live numbers, icons, hero form
(function () {
  'use strict';
  var I = TL.I, $ = TL.$;

  function put(id, name) { var n = $('#' + id); if (n) n.innerHTML = I[name]; }
  put('ic-link', 'link'); put('ic-news', 'news');
  ['ic1:eye', 'ic2:lock', 'ic3:db', 'ic4:chart', 'ic5:zap', 'ic6:info'].forEach(function (s) { var p = s.split(':'); put(p[0], p[1]); });
  ['pi1', 'pi2', 'pi3'].forEach(function (id) { put(id, 'alert'); $('#' + id).style.cssText = 'display:inline-grid;color:var(--danger);width:20px;flex:none'; });

  Charts.gauge($('#preview-gauge'), 96, { color: 'danger', caption: 'Risk score' });

  $('#hero-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var v = $('#hero-url').value.trim();
    window.location.href = '/scanner' + (v ? '?url=' + encodeURIComponent(v) : '');
  });

  TL.api('/api/overview').then(function (o) {
    TL.countUp($('#st-articles'), o.articles);
    TL.countUp($('#st-urls'), o.urls);
    o.best_models.forEach(function (m) {
      var target = m.task === 'phishing' ? '#st-phish' : '#st-news';
      TL.countUp($(target), m.accuracy * 100, { decimals: 1, suffix: '%' });
    });
  }).catch(function () {
    ['#st-articles', '#st-urls', '#st-phish', '#st-news'].forEach(function (s) { $(s).textContent = 'n/a'; });
  });
})();
