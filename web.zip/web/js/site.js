// site.js - shared by every page: header, footer, theme switch, API helper, tiny DOM helpers.
(function () {
  'use strict';

  // ---------- icons (constant, trusted markup) ----------
  var I = {
    shield: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 5v6c0 5 3.400 9.200 8 11 4.600-1.800 8-6 8-11V5z"/><path d="m9 12 2 2 4-4"/></svg>',
    shieldAlert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 4 5v6c0 5 3.400 9.200 8 11 4.600-1.800 8-6 8-11V5z"/><path d="M12 8v4M12 16h.01"/></svg>',
    link: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg>',
    news: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h13a2 2 0 0 1 2 2v14H6a2 2 0 0 1-2-2z"/><path d="M19 8h2v10a2 2 0 0 1-2 2M8 8h7M8 12h7M8 16h4"/></svg>',
    chart: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3v18h18"/><path d="M7 15v3M12 9v9M17 5v13"/></svg>',
    db: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v6c0 1.700 3.600 3 8 3s8-1.300 8-3V5M4 11v6c0 1.700 3.600 3 8 3s8-1.300 8-3v-6"/></svg>',
    cpu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 2v3M15 2v3M9 19v3M15 19v3M2 9h3M2 15h3M19 9h3M19 15h3"/></svg>',
    check: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.400" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/></svg>',
    alert: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17h.01"/></svg>',
    x: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.400" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/></svg>',
    info: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/></svg>',
    search: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.500-3.500"/></svg>',
    sun: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.900 4.900l1.400 1.400M17.700 17.700l1.400 1.400M2 12h2M20 12h2M4.900 19.100l1.400-1.400M17.700 6.300l1.400-1.400"/></svg>',
    moon: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 13A9 9 0 1 1 11 3a7 7 0 0 0 10 10z"/></svg>',
    menu: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round"><path d="M4 7h16M4 12h16M4 17h16"/></svg>',
    lock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg>',
    zap: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 4 14h7l-1 8 9-12h-7z"/></svg>',
    eye: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3.500-7 10-7 10 7 10 7-3.500 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
    code: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m8 8-5 4 5 4M16 8l5 4-5 4M14 4l-4 16"/></svg>',
    arrow: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>',
    close: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.200" stroke-linecap="round"><path d="M6 6l12 12M18 6 6 18"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="11" height="11" rx="2"/><path d="M5 15V6a2 2 0 0 1 2-2h9"/></svg>'
  };

  // ---------- tiny DOM helper (uses textContent, so data can never inject HTML) ----------
  function el(tag, attrs, children) {
    var node = document.createElement(tag);
    attrs = attrs || {};
    Object.keys(attrs).forEach(function (k) {
      var v = attrs[k];
      if (v === null || v === undefined || v === false) return;
      if (k === 'class') node.className = v;
      else if (k === 'text') node.textContent = v;
      else if (k === 'html') node.innerHTML = v;            // only ever used with constant strings
      else if (k.slice(0, 2) === 'on' && typeof v === 'function') node.addEventListener(k.slice(2), v);
      else node.setAttribute(k, v === true ? '' : v);
    });
    (children || []).forEach(function (c) {
      if (c === null || c === undefined || c === false) return;
      node.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    });
    return node;
  }
  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); return node; }
  function icon(name, cls) { var s = el('span', { class: cls || 'ico', html: I[name] || '' }); s.style.display = 'inline-grid'; return s; }

  // ---------- API ----------
  function api(path, opts) {
    return fetch(path, opts).then(function (r) {
      return r.json().catch(function () { return null; }).then(function (data) {
        if (!r.ok) throw new Error((data && data.error) || ('Request failed (' + r.status + ')'));
        return data;
      });
    });
  }
  function postJson(path, body) {
    return api(path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  }

  // ---------- formatting ----------
  function num(n) { return Number(n).toLocaleString('en-US'); }
  function pct(n, d) { return Number(n).toFixed(d === undefined ? 1 : d) + '%'; }
  function countUp(node, to, opts) {
    opts = opts || {};
    var dec = opts.decimals || 0, suffix = opts.suffix || '', t0 = null, dur = 900;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) { node.textContent = to.toFixed(dec) + suffix; return; }
    function step(ts) {
      if (!t0) t0 = ts;
      var k = Math.min(1, (ts - t0) / dur), e = 1 - Math.pow(1 - k, 3);
      node.textContent = (dec ? (to * e).toFixed(dec) : num(Math.round(to * e))) + suffix;
      if (k < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  // ---------- toast ----------
  function toast(msg, isError) {
    var host = $('.toast-host');
    if (!host) { host = el('div', { class: 'toast-host', 'aria-live': 'polite' }); document.body.appendChild(host); }
    var t = el('div', { class: 'toast' + (isError ? ' error' : ''), text: msg });
    host.appendChild(t);
    setTimeout(function () { t.remove(); }, 3800);
  }

  // ---------- modal ----------
  function openModal(title, bodyNode, badges) {
    var prev = document.activeElement;
    var back = el('div', { class: 'modal-back', role: 'dialog', 'aria-modal': 'true', 'aria-label': title });
    var closeBtn = el('button', { class: 'icon-btn', 'aria-label': 'Close', html: I.close });
    var head = el('div', { class: 'modal-head' }, [el('h3', { text: title })].concat(badges || []).concat([closeBtn]));
    var box = el('div', { class: 'modal' }, [head, bodyNode]);
    back.appendChild(box);
    function close() { back.remove(); document.removeEventListener('keydown', onKey); if (prev && prev.focus) prev.focus(); }
    function onKey(e) { if (e.key === 'Escape') close(); }
    closeBtn.addEventListener('click', close);
    back.addEventListener('click', function (e) { if (e.target === back) close(); });
    document.addEventListener('keydown', onKey);
    document.body.appendChild(back);
    closeBtn.focus();
    return close;
  }

  // ---------- header / footer ----------
  var NAV = [
    ['/', 'Home', 'home'], ['/scanner', 'Scanner', 'scanner'], ['/dashboard', 'Dashboard', 'dashboard'],
    ['/explorer', 'Data', 'explorer'], ['/models', 'Models', 'models'], ['/sql-lab', 'SQL Lab', 'sql'], ['/about', 'About', 'about']
  ];

  function buildHeader() {
    var host = $('#site-header');
    if (!host) return;
    var page = document.body.getAttribute('data-page');
    var links = el('nav', { class: 'nav-links', id: 'nav-links', 'aria-label': 'Main' },
      NAV.map(function (n) { return el('a', { href: n[0], text: n[1], 'aria-current': n[2] === page ? 'page' : null }); }));
    var theme = el('button', { class: 'icon-btn', id: 'theme-btn', 'aria-label': 'Toggle dark mode' });
    var menu = el('button', { class: 'icon-btn menu-btn', 'aria-label': 'Open menu', 'aria-expanded': 'false', html: I.menu });
    menu.addEventListener('click', function () {
      var open = links.classList.toggle('open');
      menu.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    function paintTheme() {
      var dark = document.documentElement.getAttribute('data-theme') === 'dark';
      theme.innerHTML = dark ? I.sun : I.moon;
    }
    theme.addEventListener('click', function () {
      var dark = document.documentElement.getAttribute('data-theme') !== 'dark';
      document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
      try { localStorage.setItem('tl-theme', dark ? 'dark' : 'light'); } catch (e) {}
      paintTheme();
      document.dispatchEvent(new CustomEvent('themechange'));
    });
    paintTheme();
    host.className = 'site-header';
    host.appendChild(el('div', { class: 'container nav' }, [
      el('a', { class: 'brand', href: '/', 'aria-label': 'TrustLens home' }, [el('span', { html: I.shield, style: 'display:inline-grid;color:var(--primary)' }), el('span', { html: 'Trust<b>Lens</b>' })]),
      links, el('span', { class: 'spacer' }), theme, menu
    ]));
  }

  function buildFooter() {
    var host = $('#site-footer');
    if (!host) return;
    host.className = 'site-footer';
    function col(title, items) {
      return el('div', {}, [el('h4', { text: title })].concat(items.map(function (i) { return el('a', { href: i[0], text: i[1] }); })));
    }
    host.appendChild(el('div', { class: 'container' }, [
      el('div', { class: 'foot-grid' }, [
        el('div', {}, [
          el('a', { class: 'brand', href: '/' }, [el('span', { html: I.shield, style: 'display:inline-grid;color:var(--primary)' }), el('span', { html: 'Trust<b>Lens</b>' })]),
          el('p', { class: 'muted small', style: 'margin-top:12px;max-width:26em', text: 'Fake news and phishing detection, explained. A data science project written end to end in C++ with a SQL database.' })
        ]),
        col('Tools', [['/scanner', 'Link scanner'], ['/scanner?tab=news', 'Article checker'], ['/explorer', 'Data explorer']]),
        col('Insights', [['/dashboard', 'Dashboard'], ['/models', 'Model performance'], ['/sql-lab', 'SQL Lab']]),
        col('Project', [['/about', 'How it works'], ['/about#limits', 'Limitations'], ['/about#data', 'Use your own data']])
      ]),
      el('div', { class: 'foot-bottom' }, [
        el('span', { text: '© ' + new Date().getFullYear() + ' TrustLens · Built with C++17, SQLite, HTML & CSS' }),
        el('span', { text: 'Predictions are estimates, not guarantees. Always double-check important links and claims.' })
      ])
    ]));
  }

  document.addEventListener('DOMContentLoaded', function () {
    buildHeader();
    buildFooter();
    var main = $('main');
    if (main && !main.id) main.id = 'main';
  });

  window.TL = { I: I, el: el, $: $, $$: $$, clear: clear, icon: icon, api: api, postJson: postJson, num: num, pct: pct, countUp: countUp, toast: toast, openModal: openModal };
})();
