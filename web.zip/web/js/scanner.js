// scanner.js - the main tool: scan a URL or check a news article through the C++ API.
(function () {
  'use strict';
  var el = TL.el, $ = TL.$, I = TL.I;

  var ICON = { safe: 'check', real: 'check', leans_real: 'check', suspicious: 'alert', leans_fake: 'alert', phishing: 'shieldAlert', fake: 'shieldAlert' };
  var COLOR = { safe: 'ok', real: 'ok', leans_real: 'ok', suspicious: 'warn', leans_fake: 'danger', phishing: 'danger', fake: 'danger' };
  var LABEL = { safe: 'Safe', real: 'Real', leans_real: 'Leans real', suspicious: 'Suspicious', leans_fake: 'Leans fake', phishing: 'Phishing', fake: 'Fake' };

  $('#tic-url').innerHTML = I.link; $('#tic-news').innerHTML = I.news;
  $('#n1').innerHTML = I.lock; $('#n2').innerHTML = I.info;
  ['n1', 'n2'].forEach(function (id) { $('#' + id).style.cssText = 'display:inline-grid;flex:none'; });

  // ---------------- tabs ----------------
  function showTab(name) {
    ['url', 'news'].forEach(function (t) {
      $('#tab-' + t).setAttribute('aria-selected', t === name ? 'true' : 'false');
      $('#panel-' + t).classList.toggle('hidden', t !== name);
    });
    var u = new URL(window.location); u.searchParams.set('tab', name); u.searchParams.delete('url');
    history.replaceState(null, '', u);
  }
  TL.$$('.tab').forEach(function (b) { b.addEventListener('click', function () { showTab(b.getAttribute('data-tab')); }); });

  function setBusy(btn, busy, label) {
    btn.disabled = busy;
    TL.clear(btn);
    if (busy) { btn.appendChild(el('span', { class: 'spinner' })); btn.appendChild(document.createTextNode(' Checking...')); }
    else btn.textContent = label;
  }
  function showError(host, msg) {
    TL.clear(host);
    host.appendChild(el('div', { class: 'result' }, [el('div', { class: 'notice warn' }, [el('span', { html: I.alert, style: 'display:inline-grid;flex:none' }), el('span', { text: msg })])]));
  }
  function short(s, n) { return s.length > n ? s.slice(0, n - 1) + '…' : s; }

  // ---------------- URL scanner ----------------
  function meter(label, value) {
    var cls = value >= 70 ? 'danger' : value >= 40 ? 'warn' : 'ok';
    var f = el('span', { class: 'fill ' + cls });
    requestAnimationFrame(function () { requestAnimationFrame(function () { f.style.width = Math.max(1.5, value) + '%'; }); });
    return el('div', { class: 'meter' }, [el('span', { text: label }), el('span', { class: 'track' }, [f]), el('b', { text: value + '%' })]);
  }

  function renderUrl(r) {
    var host = $('#url-result');
    TL.clear(host);
    var g = el('div', { class: 'gauge' });
    var banner = el('div', { class: 'verdict ' + r.verdict }, [
      el('div', { class: 'v-icon', html: I[ICON[r.verdict]] }),
      el('div', {}, [el('h3', { text: r.title }), el('div', { class: 'target', text: r.url }), el('p', { class: 'small', style: 'margin:10px 0 0', text: r.advice })]),
      g
    ]);

    var flagsCard;
    if (r.flags.length) {
      flagsCard = el('ul', { class: 'flag-list' }, r.flags.map(function (f) {
        return el('li', {}, [el('span', { html: I.alert, style: 'display:inline-grid;flex:none' }), el('span', { text: 'This address ' + f + '.' })]);
      }));
    } else {
      flagsCard = el('ul', { class: 'flag-list good' }, [el('li', {}, [el('span', { html: I.check, style: 'display:inline-grid;flex:none' }), el('span', { text: 'No classic red flags found in the address.' })])]);
    }

    var p = r.parsed;
    var kv = el('dl', { class: 'kv' });
    [['Protocol', p.scheme || '(none)'], ['Host', p.host], ['Main domain', p.registered_domain], ['Ending (TLD)', '.' + p.tld],
     ['Subdomains', String(p.subdomains)], ['Path', p.path || '/'], ['IP address as host', p.is_ip ? 'yes' : 'no']].forEach(function (row) {
      kv.appendChild(el('dt', { text: row[0] })); kv.appendChild(el('dd', { text: row[1] }));
    });

    var rows = r.features.map(function (f) { return el('tr', {}, [el('td', { class: 'mono', text: f.name }), el('td', { class: 'num', text: String(f.value) })]); });
    var featTable = el('details', {}, [
      el('summary', { text: 'Show the 21 numbers the model saw' }),
      el('p', { class: 'small muted', text: 'The model cannot read text, so each address is converted into these numbers first (this is called feature engineering).' }),
      el('div', { class: 'table-wrap' }, [el('table', { class: 'table' }, [el('thead', {}, [el('tr', {}, [el('th', { text: 'Feature' }), el('th', { class: 'num', text: 'Value' })])]), el('tbody', {}, rows)])])
    ]);

    host.appendChild(el('div', { class: 'result' }, [
      banner,
      el('div', { class: 'result-grid' }, [
        el('div', { class: 'card flat' }, [el('h3', { text: r.flags.length ? 'Why we flagged it' : 'What we checked' }), flagsCard]),
        el('div', { class: 'card flat' }, [el('h3', { text: 'Address breakdown' }), kv])
      ]),
      el('div', { class: 'card flat', style: 'margin-top:20px' }, [
        el('h3', { text: 'What each model thinks' }),
        meter('Random forest', r.risk_forest), meter('Logistic regression', r.risk_logistic),
        el('p', { class: 'small muted', style: 'margin:10px 0 0', text: 'The headline score comes from the random forest, which handles combinations of warning signs best.' })
      ]),
      el('div', { style: 'margin-top:20px' }, [featTable])
    ]));
    Charts.gauge(g, r.risk, { color: COLOR[r.verdict], caption: 'Phishing risk' });
  }

  function scanUrl(value) {
    var btn = $('#url-btn');
    setBusy(btn, true);
    TL.postJson('/api/scan-url', { url: value }).then(function (r) {
      renderUrl(r); loadHistory();
    }).catch(function (e) {
      showError($('#url-result'), e.message);
    }).then(function () { setBusy(btn, false, 'Scan link'); });
  }

  $('#url-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var v = $('#url-input').value.trim();
    if (!v) { showError($('#url-result'), 'Paste a link first, for example https://example.com'); $('#url-input').focus(); return; }
    scanUrl(v);
  });

  // ---------------- news checker ----------------
  function renderNews(r) {
    var host = $('#news-result');
    TL.clear(host);
    var g = el('div', { class: 'gauge' });
    var confBadge = el('span', { class: 'badge ' + (r.confidence === 'high' ? 'ok' : r.confidence === 'medium' ? 'warn' : 'danger'), text: 'Confidence: ' + r.confidence });
    var banner = el('div', { class: 'verdict ' + r.verdict }, [
      el('div', { class: 'v-icon', html: I[ICON[r.verdict]] }),
      el('div', {}, [el('h3', { text: r.title }), el('div', { class: 'row', style: 'margin-top:6px' }, [confBadge, el('span', { class: 'small muted', text: r.recognised_terms + ' known terms recognised' })]),
        el('p', { class: 'small', style: 'margin:10px 0 0', text: r.confidence === 'low' ? 'The model is unsure here. Treat this result with extra caution and check the story with trusted sources.' : 'Check the original source and look for the same story on reputable news sites before sharing.' })]),
      g
    ]);

    var chips = el('div', { class: 'reason-chips' }, r.reasons.map(function (x) {
      return el('span', { class: 'reason ' + x.direction, title: x.kind === 'style' ? 'Writing-style signal' : 'Word or phrase (shown as a word stem)' },
        [x.term, el('small', { text: x.direction === 'fake' ? '→ fake' : '→ real' })]);
    }));

    function tile(t, n) { return el('div', { class: 'tile' }, [el('div', { class: 't', text: t }), el('div', { class: 'n', text: String(n) })]); }
    var s = r.stats;
    host.appendChild(el('div', { class: 'result' }, [
      banner,
      el('div', { class: 'result-grid' }, [
        el('div', { class: 'card flat' }, [el('h3', { text: 'What influenced the result' }),
          el('p', { class: 'small muted', text: 'Red chips pushed the model towards “fake”, green chips towards “real”. Words are shown as stems (e.g. “shock” covers shocking, shocked).' }), chips]),
        el('div', { class: 'card flat' }, [el('h3', { text: 'Writing style' }),
          el('div', { class: 'metric-tiles' }, [tile('Words', s.words), tile('Exclamation marks', s.exclamations), tile('SHOUTING words', s.shouting_words), tile('Capital letters', s.caps_pct + '%')])])
      ])
    ]));
    Charts.gauge(g, r.p_fake, { color: COLOR[r.verdict], caption: 'Chance it is fake' });
  }

  $('#news-input').addEventListener('input', function () { $('#news-count').textContent = TL.num(this.value.length); });
  $('#news-clear').addEventListener('click', function () {
    $('#news-input').value = ''; $('#news-count').textContent = '0'; TL.clear($('#news-result')); $('#news-input').focus();
  });
  $('#news-form').addEventListener('submit', function (e) {
    e.preventDefault();
    var v = $('#news-input').value.trim();
    var btn = $('#news-btn');
    if (v.length < 20) { showError($('#news-result'), 'Please paste at least a sentence or two (20+ characters).'); return; }
    setBusy(btn, true);
    TL.postJson('/api/check-news', { text: v }).then(function (r) { renderNews(r); loadHistory(); })
      .catch(function (err) { showError($('#news-result'), err.message); })
      .then(function () { setBusy(btn, false, 'Check article'); });
  });

  // ---------------- examples (random rows from the database) ----------------
  function loadExamples() {
    TL.api('/api/examples').then(function (ex) {
      var box = $('#url-examples');
      ex.legit.slice(0, 2).forEach(function (u) {
        box.appendChild(el('button', { type: 'button', class: 'chip safe', title: 'Looks safe: ' + u.url, text: '✓ ' + short(u.url.replace(/^https?:\/\//, ''), 32), onclick: function () { $('#url-input').value = u.url; scanUrl(u.url); } }));
      });
      ex.phishing.slice(0, 2).forEach(function (u) {
        box.appendChild(el('button', { type: 'button', class: 'chip phishing', title: 'Known phishing: ' + u.url, text: '⚠ ' + short(u.url.replace(/^https?:\/\//, ''), 32), onclick: function () { $('#url-input').value = u.url; scanUrl(u.url); } }));
      });
      var nb = $('#news-examples');
      function fill(a) { $('#news-input').value = a.title + '. ' + a.text; $('#news-count').textContent = TL.num($('#news-input').value.length); $('#news-form').requestSubmit(); }
      if (ex.real[0]) nb.appendChild(el('button', { type: 'button', class: 'chip real', text: 'Sober news sample', onclick: function () { fill(ex.real[0]); } }));
      if (ex.fake[0]) nb.appendChild(el('button', { type: 'button', class: 'chip fake', text: 'Sensational sample', onclick: function () { fill(ex.fake[0]); } }));
    }).catch(function () {});
  }

  // ---------------- recent scans ----------------
  function loadHistory() {
    TL.api('/api/history?limit=8').then(function (d) {
      var body = $('#history-body');
      TL.clear(body);
      if (!d.scans.length) { body.appendChild(el('tr', {}, [el('td', { colspan: '5', class: 'muted', text: 'No scans yet. Try one above!' })])); return; }
      d.scans.forEach(function (s) {
        body.appendChild(el('tr', {}, [
          el('td', {}, [el('span', { class: 'badge info', text: s.kind === 'url' ? 'Link' : 'Article' })]),
          el('td', { class: 'ellip mono', title: s.input, text: short(s.input, 70) }),
          el('td', {}, [el('span', { class: 'badge ' + s.verdict, text: LABEL[s.verdict] || s.verdict })]),
          el('td', { class: 'num', text: s.score + '%' }),
          el('td', { class: 'nowrap muted', text: s.scanned_at })
        ]));
      });
    }).catch(function () { TL.clear($('#history-body')).appendChild(el('tr', {}, [el('td', { colspan: '5', class: 'muted', text: 'History unavailable.' })])); });
  }

  // ---------------- start ----------------
  var params = new URLSearchParams(window.location.search);
  if (params.get('tab') === 'news') showTab('news');
  loadExamples();
  loadHistory();
  if (params.get('url')) { $('#url-input').value = params.get('url'); scanUrl(params.get('url')); }
})();
