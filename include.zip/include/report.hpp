// report.hpp
// Writes results/report.html - a self-contained web page (no internet needed)
// with the model table, confusion matrices and feature-importance bars.
// C++ has no matplotlib, so we draw the "charts" with plain HTML/CSS bars.
#pragma once

#include "common.hpp"
#include "metrics.hpp"

namespace tl {

using NamedScore = std::pair<std::string, double>;

struct ReportData {
    std::vector<ModelResult> results;
    std::vector<NamedScore> url_importance;   // sorted, biggest first
    std::vector<NamedScore> fake_words;       // words pushing towards "fake"
    std::vector<NamedScore> real_words;       // words pushing towards "real"
    std::string news_info, url_info;          // one-line dataset descriptions
};

inline void html_bars(std::ostream& o, const std::vector<NamedScore>& v, const std::string& color) {
    double mx = 1e-12;
    for (auto& p : v) mx = std::max(mx, std::fabs(p.second));
    for (auto& p : v) {
        o << "<div class='row'><span class='lab'>" << html_escape(p.first) << "</span>"
          << "<span class='track'><span class='fill' style='width:" << fmt(100.0 * std::fabs(p.second) / mx, 1)
          << "%;background:" << color << "'></span></span><span class='val'>" << fmt(p.second, 3) << "</span></div>\n";
    }
}

inline void write_html_report(const std::string& path, const ReportData& d) {
    std::ofstream o(path);
    o << "<!doctype html><html><head><meta charset='utf-8'><title>TrustLens report</title><style>"
         "body{font-family:Segoe UI,Arial,sans-serif;max-width:980px;margin:30px auto;padding:0 16px;color:#1d2433;background:#f7f8fb}"
         "h1{margin-bottom:0}h2{margin-top:34px;border-bottom:2px solid #dfe3ee;padding-bottom:6px}"
         ".sub{color:#5b6478}table{border-collapse:collapse;width:100%;background:#fff}"
         "th,td{padding:8px 10px;border:1px solid #dfe3ee;text-align:right}th:first-child,td:first-child,th:nth-child(2),td:nth-child(2){text-align:left}"
         "th{background:#eef1f8}.best{background:#e6f6ea;font-weight:600}"
         ".row{display:flex;align-items:center;margin:4px 0}.lab{width:230px;font-family:Consolas,monospace;font-size:13px}"
         ".track{flex:1;background:#e8ebf3;height:14px;border-radius:7px;overflow:hidden}.fill{display:block;height:100%}"
         ".val{width:70px;text-align:right;font-size:13px;color:#5b6478}.cols{display:flex;gap:30px}.cols>div{flex:1}"
         ".cm{display:inline-block;margin:6px 14px 6px 0;background:#fff;border:1px solid #dfe3ee;padding:8px 12px;border-radius:6px;font-size:13px}"
         "</style></head><body>"
         "<h1>TrustLens</h1><div class='sub'>Fake news &amp; phishing website classification &mdash; generated "
      << now_string() << "</div>";

    o << "<h2>Datasets</h2><p>" << html_escape(d.news_info) << "</p><p>" << html_escape(d.url_info) << "</p>";

    // best F1 per task gets highlighted
    std::map<std::string, double> best;
    for (auto& r : d.results) best[r.task] = std::max(best[r.task], r.test.f1);

    o << "<h2>Model comparison (held-out test set)</h2><table><tr><th>Task</th><th>Model</th><th>Accuracy</th>"
         "<th>Precision</th><th>Recall</th><th>F1</th><th>AUC</th><th>5-fold CV F1</th></tr>";
    for (auto& r : d.results) {
        bool is_best = r.test.f1 >= best[r.task] - 1e-12;
        o << "<tr" << (is_best ? " class='best'" : "") << "><td>" << r.task << "</td><td>" << r.model << "</td><td>"
          << fmt(r.test.accuracy, 3) << "</td><td>" << fmt(r.test.precision, 3) << "</td><td>" << fmt(r.test.recall, 3)
          << "</td><td>" << fmt(r.test.f1, 3) << "</td><td>" << fmt(r.test.auc, 3) << "</td><td>"
          << (r.has_cv ? fmt(r.cv.mean_f1, 3) + " &plusmn; " + fmt(r.cv.sd_f1, 3) : std::string("-")) << "</td></tr>";
    }
    o << "</table><p class='sub'>Green row = best F1 for that task.</p>";

    o << "<h2>Confusion matrices</h2>";
    for (auto& r : d.results) {
        o << "<div class='cm'><b>" << r.model << "</b> <span class='sub'>(" << r.task << ")</span><br>"
          << "TN " << r.test.tn << " &nbsp; FP " << r.test.fp << "<br>FN " << r.test.fn << " &nbsp; TP " << r.test.tp << "</div>";
    }

    o << "<h2>Phishing: which URL features matter most? (Random Forest importance)</h2>";
    html_bars(o, d.url_importance, "#3b6fd4");

    o << "<h2>Fake news: words the model relies on (Logistic Regression weights)</h2><div class='cols'><div><h3>Pushes towards FAKE</h3>";
    html_bars(o, d.fake_words, "#d9534f");
    o << "</div><div><h3>Pushes towards REAL</h3>";
    html_bars(o, d.real_words, "#3d9a5a");
    o << "</div></div>";

    o << "<h2>Honest limitations</h2><ul>"
         "<li>The bundled data is synthetic, so scores on real-world data will be lower. Re-run with real datasets.</li>"
         "<li>Models learn <i>style and URL patterns</i>, not truth. A well-written lie can fool the news model.</li>"
         "<li>Attackers adapt: phishing features need regular retraining.</li></ul></body></html>";
}

}  // namespace tl
