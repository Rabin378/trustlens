// metrics.hpp
// MODEL EVALUATION: confusion matrix, accuracy, precision, recall, F1, ROC-AUC,
// plus stratified train/test split and stratified k-fold cross-validation.
//
// Why not just accuracy? In phishing detection, missing a real phishing site
// (a false negative) is far worse than flagging a safe site. So we always look
// at precision AND recall AND F1, not accuracy alone.
#pragma once

#include "common.hpp"

namespace tl {

struct Metrics {
    int tp = 0, fp = 0, tn = 0, fn = 0;
    double accuracy = 0, precision = 0, recall = 0, f1 = 0, auc = 0;
};

// AUC = probability that a random positive gets a higher score than a random
// negative. Computed from ranks (ties get the average rank).
inline double roc_auc(const std::vector<int>& y, const std::vector<double>& p) {
    const size_t n = y.size();
    std::vector<size_t> ord(n);
    std::iota(ord.begin(), ord.end(), 0);
    std::sort(ord.begin(), ord.end(), [&](size_t a, size_t b) { return p[a] < p[b]; });
    double rank_sum_pos = 0;
    double npos = 0;
    size_t i = 0;
    while (i < n) {
        size_t j = i;
        while (j + 1 < n && p[ord[j + 1]] == p[ord[i]]) ++j;
        double avg_rank = (static_cast<double>(i) + static_cast<double>(j)) / 2.0 + 1.0;
        for (size_t k = i; k <= j; ++k) if (y[ord[k]] == 1) { rank_sum_pos += avg_rank; npos += 1; }
        i = j + 1;
    }
    double nneg = static_cast<double>(n) - npos;
    if (npos == 0 || nneg == 0) return 0.5;
    return (rank_sum_pos - npos * (npos + 1) / 2.0) / (npos * nneg);
}

inline Metrics evaluate(const std::vector<int>& y, const std::vector<double>& p, double thr = 0.5) {
    Metrics m;
    for (size_t i = 0; i < y.size(); ++i) {
        int pred = p[i] >= thr ? 1 : 0;
        if (pred == 1 && y[i] == 1) ++m.tp;
        else if (pred == 1 && y[i] == 0) ++m.fp;
        else if (pred == 0 && y[i] == 0) ++m.tn;
        else ++m.fn;
    }
    double n = static_cast<double>(y.size());
    m.accuracy = n > 0 ? (m.tp + m.tn) / n : 0;
    m.precision = (m.tp + m.fp) > 0 ? static_cast<double>(m.tp) / (m.tp + m.fp) : 0;
    m.recall = (m.tp + m.fn) > 0 ? static_cast<double>(m.tp) / (m.tp + m.fn) : 0;
    m.f1 = (m.precision + m.recall) > 0 ? 2 * m.precision * m.recall / (m.precision + m.recall) : 0;
    m.auc = roc_auc(y, p);
    return m;
}

inline void print_metrics(const std::string& name, const Metrics& m) {
    std::cout << "  " << std::left << std::setw(22) << name << std::right
              << " acc " << fmt(m.accuracy, 3) << " | prec " << fmt(m.precision, 3)
              << " | recall " << fmt(m.recall, 3) << " | F1 " << fmt(m.f1, 3)
              << " | AUC " << fmt(m.auc, 3) << "\n";
}

inline void print_confusion(const Metrics& m, const std::string& neg, const std::string& pos) {
    std::cout << "                      predicted " << std::setw(10) << neg << " predicted " << pos << "\n"
              << "    actual " << std::setw(10) << std::left << neg << std::right
              << std::setw(10) << m.tn << std::setw(18) << m.fp << "\n"
              << "    actual " << std::setw(10) << std::left << pos << std::right
              << std::setw(10) << m.fn << std::setw(18) << m.tp << "\n";
}

// Points of the ROC curve (false-positive rate, true-positive rate).
inline std::vector<std::pair<double, double>> roc_curve(const std::vector<int>& y, const std::vector<double>& p) {
    std::vector<size_t> ord(y.size());
    std::iota(ord.begin(), ord.end(), 0);
    std::sort(ord.begin(), ord.end(), [&](size_t a, size_t b) { return p[a] > p[b]; });
    double P = std::count(y.begin(), y.end(), 1), N = static_cast<double>(y.size()) - P;
    std::vector<std::pair<double, double>> pts = {{0.0, 0.0}};
    double tp = 0, fp = 0;
    for (size_t k = 0; k < ord.size(); ++k) {
        if (y[ord[k]] == 1) ++tp; else ++fp;
        bool last_of_tie = (k + 1 == ord.size()) || p[ord[k + 1]] != p[ord[k]];
        if (last_of_tie) pts.push_back({N > 0 ? fp / N : 0, P > 0 ? tp / P : 0});
    }
    return pts;
}

// ---- splitting --------------------------------------------------------------

struct Split { std::vector<int> train, test; };

// Keeps the fake/real (or phish/legit) ratio the same in both parts.
inline Split stratified_split(const std::vector<int>& y, double test_ratio, unsigned seed) {
    std::mt19937 rng(seed);
    std::vector<int> cls[2];
    for (size_t i = 0; i < y.size(); ++i) cls[y[i]].push_back(static_cast<int>(i));
    Split s;
    for (auto& c : cls) {
        std::shuffle(c.begin(), c.end(), rng);
        size_t n_test = static_cast<size_t>(std::round(c.size() * test_ratio));
        for (size_t k = 0; k < c.size(); ++k) (k < n_test ? s.test : s.train).push_back(c[k]);
    }
    std::shuffle(s.train.begin(), s.train.end(), rng);
    std::shuffle(s.test.begin(), s.test.end(), rng);
    return s;
}

// k folds, each with roughly the same class balance.
inline std::vector<std::vector<int>> stratified_folds(const std::vector<int>& y, int k, unsigned seed) {
    std::mt19937 rng(seed);
    std::vector<int> cls[2];
    for (size_t i = 0; i < y.size(); ++i) cls[y[i]].push_back(static_cast<int>(i));
    std::vector<std::vector<int>> folds(k);
    for (auto& c : cls) {
        std::shuffle(c.begin(), c.end(), rng);
        for (size_t i = 0; i < c.size(); ++i) folds[i % k].push_back(c[i]);
    }
    return folds;
}

template <typename T>
std::vector<T> pick_rows(const std::vector<T>& v, const std::vector<int>& idx) {
    std::vector<T> o;
    o.reserve(idx.size());
    for (int i : idx) o.push_back(v[i]);
    return o;
}

struct CvResult { double mean_f1 = 0, sd_f1 = 0, mean_acc = 0; };

inline CvResult summarize_cv(const std::vector<Metrics>& ms) {
    CvResult r;
    for (auto& m : ms) { r.mean_f1 += m.f1; r.mean_acc += m.accuracy; }
    r.mean_f1 /= ms.size();
    r.mean_acc /= ms.size();
    for (auto& m : ms) r.sd_f1 += (m.f1 - r.mean_f1) * (m.f1 - r.mean_f1);
    r.sd_f1 = std::sqrt(r.sd_f1 / ms.size());
    return r;
}

// One row of the final results table (also written to CSV / SQL / HTML).
struct ModelResult {
    std::string task, model;
    Metrics test;
    CvResult cv;
    bool has_cv = false;
};

}  // namespace tl
