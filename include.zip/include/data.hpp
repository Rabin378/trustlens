// data.hpp
// Step 1 and 2 of the data science life-cycle: DATA COLLECTION + DATA CLEANING.
//
// We read the raw CSV files and then:
//   * trim stray whitespace
//   * throw away rows with missing / too-short content
//   * throw away rows whose label is not exactly 0 or 1
//   * drop exact duplicates (same text, or same URL)
// and we keep a CleaningReport so the numbers can be shown to a human.
#pragma once

#include "common.hpp"
#include "csv.hpp"

namespace tl {

struct NewsRecord {
    int id = 0;
    std::string title, text, subject, source, date;
    int label = 0;  // 0 = real, 1 = fake
};

struct UrlRecord {
    int id = 0;
    std::string url, source, date;
    int label = 0;  // 0 = legitimate, 1 = phishing
};

struct CleaningReport {
    size_t raw_rows = 0;
    size_t missing_content = 0;
    size_t bad_label = 0;
    size_t duplicates = 0;
    size_t kept = 0;

    void print(const std::string& name) const {
        std::cout << "  " << name << " cleaning report\n"
                  << "    raw rows            : " << raw_rows << "\n"
                  << "    missing/short       : " << missing_content << "\n"
                  << "    invalid label       : " << bad_label << "\n"
                  << "    duplicates removed  : " << duplicates << "\n"
                  << "    rows kept           : " << kept << "\n";
    }
};

inline bool parse_label(const std::string& s, int& out) {
    std::string t = trim(s);
    if (t == "0") { out = 0; return true; }
    if (t == "1") { out = 1; return true; }
    return false;
}

inline std::vector<NewsRecord> load_news(const std::string& path, CleaningReport& rep) {
    Row header;
    auto rows = read_csv(path, header);
    int ci_id = column_index(header, "id"), ci_title = column_index(header, "title"),
        ci_text = column_index(header, "text"), ci_subj = column_index(header, "subject"),
        ci_src = column_index(header, "source"), ci_date = column_index(header, "published_date"),
        ci_label = column_index(header, "label");
    if (ci_text < 0 || ci_label < 0)
        throw std::runtime_error("news.csv needs at least the columns: text, label");

    auto get = [](const Row& r, int idx) -> std::string {
        return (idx >= 0 && idx < static_cast<int>(r.size())) ? trim(r[idx]) : std::string();
    };

    std::vector<NewsRecord> out;
    std::unordered_set<std::string> seen;
    rep = CleaningReport();
    rep.raw_rows = rows.size();

    int auto_id = 1;
    for (const auto& r : rows) {
        NewsRecord n;
        n.title = get(r, ci_title);
        n.text = get(r, ci_text);
        n.subject = get(r, ci_subj);
        n.source = get(r, ci_src);
        n.date = get(r, ci_date);
        std::string idtxt = get(r, ci_id);
        n.id = idtxt.empty() ? auto_id : std::atoi(idtxt.c_str());
        ++auto_id;

        if (!parse_label(get(r, ci_label), n.label)) { ++rep.bad_label; continue; }
        if (n.title.size() + n.text.size() < 40) { ++rep.missing_content; continue; }

        std::string key = to_lower(n.title + "|" + n.text);
        if (!seen.insert(key).second) { ++rep.duplicates; continue; }
        out.push_back(std::move(n));
    }
    rep.kept = out.size();
    return out;
}

inline std::vector<UrlRecord> load_urls(const std::string& path, CleaningReport& rep) {
    Row header;
    auto rows = read_csv(path, header);
    int ci_id = column_index(header, "id"), ci_url = column_index(header, "url"),
        ci_label = column_index(header, "label"), ci_src = column_index(header, "source"),
        ci_date = column_index(header, "collected_date");
    if (ci_url < 0 || ci_label < 0)
        throw std::runtime_error("urls.csv needs at least the columns: url, label");

    auto get = [](const Row& r, int idx) -> std::string {
        return (idx >= 0 && idx < static_cast<int>(r.size())) ? trim(r[idx]) : std::string();
    };

    std::vector<UrlRecord> out;
    std::unordered_set<std::string> seen;
    rep = CleaningReport();
    rep.raw_rows = rows.size();

    int auto_id = 1;
    for (const auto& r : rows) {
        UrlRecord u;
        u.url = get(r, ci_url);
        u.source = get(r, ci_src);
        u.date = get(r, ci_date);
        std::string idtxt = get(r, ci_id);
        u.id = idtxt.empty() ? auto_id : std::atoi(idtxt.c_str());
        ++auto_id;

        if (!parse_label(get(r, ci_label), u.label)) { ++rep.bad_label; continue; }
        if (u.url.size() < 4 || u.url.find('.') == std::string::npos) { ++rep.missing_content; continue; }

        std::string key = to_lower(u.url);
        if (!seen.insert(key).second) { ++rep.duplicates; continue; }
        out.push_back(std::move(u));
    }
    rep.kept = out.size();
    return out;
}

}  // namespace tl
