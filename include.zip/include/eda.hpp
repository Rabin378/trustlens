// eda.hpp
// EXPLORATORY DATA ANALYSIS (EDA): look at the data BEFORE modelling.
// We print class balance, descriptive statistics split by class, and the
// correlation of every numeric feature with the label.
#pragma once

#include "common.hpp"

namespace tl {

struct Summary { double mean = 0, sd = 0, min = 0, median = 0, max = 0; };

inline Summary summarize(std::vector<double> v) {
    Summary s;
    if (v.empty()) return s;
    std::sort(v.begin(), v.end());
    s.min = v.front();
    s.max = v.back();
    s.median = v.size() % 2 ? v[v.size() / 2] : 0.5 * (v[v.size() / 2 - 1] + v[v.size() / 2]);
    s.mean = std::accumulate(v.begin(), v.end(), 0.0) / v.size();
    double var = 0;
    for (double x : v) var += (x - s.mean) * (x - s.mean);
    s.sd = std::sqrt(var / v.size());
    return s;
}

// Pearson correlation between a numeric feature and the 0/1 label
// (this special case is called the "point-biserial" correlation).
inline double correlation(const std::vector<double>& x, const std::vector<int>& y) {
    const double n = static_cast<double>(x.size());
    if (n < 2) return 0;
    double mx = std::accumulate(x.begin(), x.end(), 0.0) / n;
    double my = std::accumulate(y.begin(), y.end(), 0.0) / n;
    double sxy = 0, sxx = 0, syy = 0;
    for (size_t i = 0; i < x.size(); ++i) {
        sxy += (x[i] - mx) * (y[i] - my);
        sxx += (x[i] - mx) * (x[i] - mx);
        syy += (y[i] - my) * (y[i] - my);
    }
    if (sxx <= 0 || syy <= 0) return 0;
    return sxy / std::sqrt(sxx * syy);
}

inline void print_class_balance(const std::string& title, const std::vector<int>& y,
                                const std::string& name0, const std::string& name1) {
    double n0 = static_cast<double>(std::count(y.begin(), y.end(), 0));
    double n1 = static_cast<double>(std::count(y.begin(), y.end(), 1));
    double n = n0 + n1;
    std::cout << "  " << title << " (n = " << static_cast<long>(n) << ")\n";
    std::cout << "    " << std::left << std::setw(12) << name0 << std::right << std::setw(6)
              << static_cast<long>(n0) << "  " << bar(n0 / n, 30) << " " << fmt(100 * n0 / n, 1) << "%\n";
    std::cout << "    " << std::left << std::setw(12) << name1 << std::right << std::setw(6)
              << static_cast<long>(n1) << "  " << bar(n1 / n, 30) << " " << fmt(100 * n1 / n, 1) << "%\n";
    std::cout << "    majority-class baseline accuracy: " << fmt(100 * std::max(n0, n1) / n, 1) << "%\n";
}

// Compare a single numeric column between the two classes.
inline void print_feature_by_class(const std::string& name, const std::vector<double>& x,
                                   const std::vector<int>& y) {
    std::vector<double> a, b;
    for (size_t i = 0; i < x.size(); ++i) (y[i] ? b : a).push_back(x[i]);
    Summary sa = summarize(a), sb = summarize(b);
    std::cout << "  " << std::left << std::setw(22) << name << std::right
              << " class0 mean " << std::setw(8) << fmt(sa.mean, 2) << " (sd " << fmt(sa.sd, 2) << ")"
              << " | class1 mean " << std::setw(8) << fmt(sb.mean, 2) << " (sd " << fmt(sb.sd, 2) << ")"
              << " | corr " << std::setw(7) << fmt(correlation(x, y), 3) << "\n";
}

}  // namespace tl
