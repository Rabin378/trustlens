// csv.hpp
// A small, honest CSV reader/writer. It understands quoted fields, commas inside
// quotes, doubled quotes ("") and even line breaks inside quotes - which real
// news datasets love to contain.
#pragma once

#include "common.hpp"

namespace tl {

using Row = std::vector<std::string>;

inline Row parse_csv_record(const std::string& rec) {
    Row out;
    std::string cur;
    bool in_quotes = false;
    for (size_t i = 0; i < rec.size(); ++i) {
        char c = rec[i];
        if (in_quotes) {
            if (c == '"') {
                if (i + 1 < rec.size() && rec[i + 1] == '"') { cur += '"'; ++i; }
                else in_quotes = false;
            } else cur += c;
        } else {
            if (c == '"') in_quotes = true;
            else if (c == ',') { out.push_back(cur); cur.clear(); }
            else if (c != '\r') cur += c;
        }
    }
    out.push_back(cur);
    return out;
}

// Reads one logical record (it may span several physical lines if a quoted
// field contains a newline).
inline bool read_csv_record(std::istream& in, Row& row) {
    std::string line;
    if (!std::getline(in, line)) return false;
    auto quote_count = [](const std::string& s) {
        return std::count(s.begin(), s.end(), '"');
    };
    while (quote_count(line) % 2 != 0) {
        std::string more;
        if (!std::getline(in, more)) break;
        line += "\n" + more;
    }
    row = parse_csv_record(line);
    return true;
}

// Loads a whole CSV file. The first row is returned through `header`.
inline std::vector<Row> read_csv(const std::string& path, Row& header) {
    std::ifstream in(path);
    if (!in) throw std::runtime_error("Cannot open CSV file: " + path +
                                      "  (did you run `make data` first?)");
    std::vector<Row> rows;
    Row r;
    bool first = true;
    while (read_csv_record(in, r)) {
        if (r.size() == 1 && r[0].empty()) continue;  // blank line
        if (first) { header = r; first = false; }
        else rows.push_back(r);
    }
    return rows;
}

inline std::string csv_escape(const std::string& s) {
    bool needs = s.find_first_of(",\"\n\r") != std::string::npos;
    if (!needs) return s;
    std::string o = "\"";
    for (char c : s) {
        if (c == '"') o += "\"\"";
        else o += c;
    }
    o += "\"";
    return o;
}

inline void write_csv_row(std::ostream& out, const Row& row) {
    for (size_t i = 0; i < row.size(); ++i) {
        if (i) out << ',';
        out << csv_escape(row[i]);
    }
    out << '\n';
}

// Find a column by name (returns -1 if it is missing).
inline int column_index(const Row& header, const std::string& name) {
    for (size_t i = 0; i < header.size(); ++i)
        if (to_lower(trim(header[i])) == name) return static_cast<int>(i);
    return -1;
}

}  // namespace tl
