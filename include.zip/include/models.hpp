// models.hpp
// The machine learning algorithms, written from scratch (no libraries!).
//
//   LogisticRegression : linear classifier trained with mini-batch gradient descent
//   NaiveBayes         : multinomial Naive Bayes, the classic text baseline
//   DecisionTree       : CART tree using Gini impurity
//   RandomForest       : many decorrelated trees, averaged
//   StandardScaler     : (x - mean) / std, so features live on the same scale
//
// Every model exposes   double predict_proba(x)   -> probability of class 1
// (class 1 = "fake news" or "phishing"; that's the thing we want to catch).
#pragma once

#include "common.hpp"
#include "text.hpp"

namespace tl {

using Dense = std::vector<std::vector<double>>;

inline double sigmoid(double z) {
    if (z >= 0) { double e = std::exp(-z); return 1.0 / (1.0 + e); }
    double e = std::exp(z);
    return e / (1.0 + e);
}

inline SparseVec to_sparse(const std::vector<double>& x) {
    SparseVec s;
    for (size_t j = 0; j < x.size(); ++j) if (x[j] != 0.0) s.push_back({static_cast<int>(j), x[j]});
    return s;
}

// ----------------------------------------------------------------------------
//  Standard scaler
// ----------------------------------------------------------------------------
class StandardScaler {
public:
    void fit(const Dense& X) {
        size_t d = X.empty() ? 0 : X[0].size();
        mean_.assign(d, 0.0);
        std_.assign(d, 1.0);
        for (const auto& row : X) for (size_t j = 0; j < d; ++j) mean_[j] += row[j];
        for (auto& m : mean_) m /= static_cast<double>(X.size());
        std::vector<double> var(d, 0.0);
        for (const auto& row : X) for (size_t j = 0; j < d; ++j) var[j] += (row[j] - mean_[j]) * (row[j] - mean_[j]);
        for (size_t j = 0; j < d; ++j) {
            double s = std::sqrt(var[j] / static_cast<double>(X.size()));
            std_[j] = s < 1e-9 ? 1.0 : s;   // constant columns: avoid dividing by zero
        }
    }
    std::vector<double> transform(const std::vector<double>& x) const {
        std::vector<double> o(x.size());
        for (size_t j = 0; j < x.size(); ++j) o[j] = (x[j] - mean_[j]) / std_[j];
        return o;
    }
    Dense transform(const Dense& X) const {
        Dense o;
        o.reserve(X.size());
        for (const auto& r : X) o.push_back(transform(r));
        return o;
    }
    void save(std::ostream& out) const {
        out << "SCALER " << mean_.size() << "\n";
        out.precision(12);
        for (size_t j = 0; j < mean_.size(); ++j) out << mean_[j] << " " << std_[j] << "\n";
    }
    bool load(std::istream& in) {
        std::string tag; size_t d;
        in >> tag >> d;
        if (tag != "SCALER") return false;
        mean_.assign(d, 0); std_.assign(d, 1);
        for (size_t j = 0; j < d; ++j) in >> mean_[j] >> std_[j];
        return true;
    }
private:
    std::vector<double> mean_, std_;
};

// ----------------------------------------------------------------------------
//  Logistic regression
// ----------------------------------------------------------------------------
class LogisticRegression {
public:
    struct Params {
        double lr = 1.0;       // learning rate (decays a little every epoch)
        double l2 = 1e-4;      // L2 regularisation strength ("weight decay")
        int epochs = 60;
        int batch = 32;
        unsigned seed = 42;
    };

    LogisticRegression() = default;
    explicit LogisticRegression(Params p) : p_(p) {}

    void fit(const std::vector<SparseVec>& X, const std::vector<int>& y, int dim) {
        w_.assign(dim, 0.0);
        b_ = 0.0;
        std::mt19937 rng(p_.seed);
        std::vector<int> order(X.size());
        std::iota(order.begin(), order.end(), 0);
        std::vector<double> grad(dim, 0.0);
        std::vector<char> mark(dim, 0);
        std::vector<int> touched;

        for (int epoch = 0; epoch < p_.epochs; ++epoch) {
            std::shuffle(order.begin(), order.end(), rng);
            const double lr = p_.lr / (1.0 + 0.05 * epoch);
            for (size_t start = 0; start < order.size(); start += p_.batch) {
                size_t end = std::min(order.size(), start + static_cast<size_t>(p_.batch));
                double gb = 0.0;
                touched.clear();
                for (size_t k = start; k < end; ++k) {
                    int i = order[k];
                    double err = sigmoid(score(X[i])) - y[i];     // gradient of the log-loss
                    gb += err;
                    for (auto& pr : X[i]) {
                        if (!mark[pr.first]) { mark[pr.first] = 1; touched.push_back(pr.first); }
                        grad[pr.first] += err * pr.second;
                    }
                }
                const double m = static_cast<double>(end - start);
                for (int j : touched) { w_[j] -= lr * grad[j] / m; grad[j] = 0.0; mark[j] = 0; }
                b_ -= lr * gb / m;
                if (p_.l2 > 0) {
                    const double shrink = 1.0 - lr * p_.l2;
                    for (auto& wj : w_) wj *= shrink;
                }
            }
        }
    }

    double score(const SparseVec& x) const {
        double z = b_;
        for (auto& pr : x) z += w_[pr.first] * pr.second;
        return z;
    }
    double predict_proba(const SparseVec& x) const { return sigmoid(score(x)); }
    double predict_proba_dense(const std::vector<double>& x) const { return predict_proba(to_sparse(x)); }

    const std::vector<double>& weights() const { return w_; }
    double bias() const { return b_; }

    void save(std::ostream& out) const {
        out << "LR " << w_.size() << "\n";
        out.precision(12);
        out << b_ << "\n";
        for (double w : w_) out << w << " ";
        out << "\n";
    }
    bool load(std::istream& in) {
        std::string tag; size_t d;
        in >> tag >> d;
        if (tag != "LR") return false;
        w_.assign(d, 0.0);
        in >> b_;
        for (size_t j = 0; j < d; ++j) in >> w_[j];
        return true;
    }

private:
    Params p_;
    std::vector<double> w_;
    double b_ = 0.0;
};

// ----------------------------------------------------------------------------
//  Multinomial Naive Bayes
// ----------------------------------------------------------------------------
class NaiveBayes {
public:
    explicit NaiveBayes(double alpha = 0.5) : alpha_(alpha) {}

    void fit(const std::vector<SparseVec>& X, const std::vector<int>& y, int dim) {
        std::vector<std::vector<double>> sum(2, std::vector<double>(dim, 0.0));
        std::vector<double> total(2, 0.0), count(2, 0.0);
        for (size_t i = 0; i < X.size(); ++i) {
            count[y[i]] += 1.0;
            for (auto& pr : X[i]) { sum[y[i]][pr.first] += pr.second; total[y[i]] += pr.second; }
        }
        for (int c = 0; c < 2; ++c) {
            log_prior_[c] = std::log((count[c] + 1.0) / (static_cast<double>(X.size()) + 2.0));
            log_like_[c].assign(dim, 0.0);
            for (int j = 0; j < dim; ++j)
                log_like_[c][j] = std::log((sum[c][j] + alpha_) / (total[c] + alpha_ * dim));
        }
    }

    double predict_proba(const SparseVec& x) const {
        double s0 = log_prior_[0], s1 = log_prior_[1];
        for (auto& pr : x) {
            // TF-IDF values are tiny compared with raw counts, so we scale them up a bit
            // to let the likelihood speak louder than the prior.
            s0 += 10.0 * pr.second * log_like_[0][pr.first];
            s1 += 10.0 * pr.second * log_like_[1][pr.first];
        }
        return sigmoid(s1 - s0);   // = softmax over the two classes
    }

private:
    double alpha_;
    double log_prior_[2] = {0, 0};
    std::vector<double> log_like_[2];
};

// ----------------------------------------------------------------------------
//  Decision tree (CART, Gini impurity)
// ----------------------------------------------------------------------------
struct TreeParams {
    int max_depth = 8;
    int min_samples_split = 10;
    int min_samples_leaf = 3;
    int max_features = -1;   // -1 = look at every feature; a forest uses sqrt(d)
};

class DecisionTree {
public:
    struct Node {
        int feat = -1;         // -1 means "leaf"
        double thr = 0.0;
        int left = -1, right = -1;
        double prob = 0.0;     // P(class 1) among training samples that reached this node
    };

    void fit(const Dense& X, const std::vector<int>& y, std::vector<int> idx,
             const TreeParams& p, std::mt19937& rng) {
        X_ = &X; y_ = &y; p_ = p; rng_ = &rng;
        nodes_.clear();
        importance_.assign(X.empty() ? 0 : X[0].size(), 0.0);
        build(idx, 0);
        X_ = nullptr; y_ = nullptr; rng_ = nullptr;
    }

    double predict_proba(const std::vector<double>& x) const {
        int cur = 0;
        while (nodes_[cur].feat >= 0) {
            cur = x[nodes_[cur].feat] <= nodes_[cur].thr ? nodes_[cur].left : nodes_[cur].right;
        }
        return nodes_[cur].prob;
    }

    const std::vector<double>& importance() const { return importance_; }
    size_t node_count() const { return nodes_.size(); }

    void save(std::ostream& out) const {
        out << "TREE " << nodes_.size() << "\n";
        out.precision(12);
        for (auto& n : nodes_) out << n.feat << " " << n.thr << " " << n.left << " " << n.right << " " << n.prob << "\n";
    }
    bool load(std::istream& in) {
        std::string tag; size_t n;
        in >> tag >> n;
        if (tag != "TREE") return false;
        nodes_.assign(n, Node());
        for (auto& nd : nodes_) in >> nd.feat >> nd.thr >> nd.left >> nd.right >> nd.prob;
        return true;
    }

private:
    static double gini(double pos, double n) {
        if (n <= 0) return 0.0;
        double p = pos / n;
        return 2.0 * p * (1.0 - p);
    }

    int build(std::vector<int>& idx, int depth) {
        const int id = static_cast<int>(nodes_.size());
        nodes_.push_back(Node());
        const double n = static_cast<double>(idx.size());
        double pos = 0;
        for (int i : idx) pos += (*y_)[i];
        nodes_[id].prob = pos / n;

        if (depth >= p_.max_depth || idx.size() < static_cast<size_t>(p_.min_samples_split) || pos == 0 || pos == n)
            return id;   // stop: leaf

        const size_t nf = (*X_)[0].size();
        std::vector<int> feats(nf);
        std::iota(feats.begin(), feats.end(), 0);
        if (p_.max_features > 0 && static_cast<size_t>(p_.max_features) < nf) {
            std::shuffle(feats.begin(), feats.end(), *rng_);
            feats.resize(p_.max_features);
        }

        const double parent = gini(pos, n);
        double best_gain = 1e-9, best_thr = 0.0;
        int best_feat = -1;
        std::vector<std::pair<double, int>> vals(idx.size());

        for (int f : feats) {
            for (size_t k = 0; k < idx.size(); ++k) vals[k] = {(*X_)[idx[k]][f], (*y_)[idx[k]]};
            std::sort(vals.begin(), vals.end());
            double left_pos = 0;
            for (size_t k = 0; k + 1 < vals.size(); ++k) {
                left_pos += vals[k].second;
                if (vals[k].first == vals[k + 1].first) continue;   // can't split between equal values
                double nl = static_cast<double>(k + 1), nr = n - nl;
                if (nl < p_.min_samples_leaf || nr < p_.min_samples_leaf) continue;
                double weighted = (nl * gini(left_pos, nl) + nr * gini(pos - left_pos, nr)) / n;
                double gain = parent - weighted;
                if (gain > best_gain) {
                    best_gain = gain; best_feat = f;
                    best_thr = 0.5 * (vals[k].first + vals[k + 1].first);
                    // two almost-equal doubles can have a midpoint that rounds UP to the
                    // larger one, which would send everything left. Stay on the safe side.
                    if (best_thr >= vals[k + 1].first) best_thr = vals[k].first;
                }
            }
        }
        if (best_feat < 0) return id;   // nothing helps: leaf

        std::vector<int> L, R;
        for (int i : idx) ((*X_)[i][best_feat] <= best_thr ? L : R).push_back(i);
        if (L.empty() || R.empty()) return id;   // paranoia: never create an empty child

        importance_[best_feat] += n * best_gain;
        nodes_[id].feat = best_feat;
        nodes_[id].thr = best_thr;
        int l = build(L, depth + 1);
        int r = build(R, depth + 1);
        nodes_[id].left = l;
        nodes_[id].right = r;
        return id;
    }

    const Dense* X_ = nullptr;
    const std::vector<int>* y_ = nullptr;
    std::mt19937* rng_ = nullptr;
    TreeParams p_;
    std::vector<Node> nodes_;
    std::vector<double> importance_;
};

// ----------------------------------------------------------------------------
//  Random forest
// ----------------------------------------------------------------------------
class RandomForest {
public:
    RandomForest(int n_trees = 100, TreeParams p = TreeParams(), unsigned seed = 7)
        : n_trees_(n_trees), params_(p), seed_(seed) {}

    void fit(const Dense& X, const std::vector<int>& y) {
        trees_.clear();
        std::mt19937 rng(seed_);
        const size_t nf = X[0].size();
        TreeParams tp = params_;
        if (tp.max_features <= 0) tp.max_features = std::max(1, static_cast<int>(std::sqrt(static_cast<double>(nf))));
        importance_.assign(nf, 0.0);

        for (int t = 0; t < n_trees_; ++t) {
            // bootstrap sample: draw n rows WITH replacement
            std::vector<int> idx(X.size());
            std::uniform_int_distribution<int> pick(0, static_cast<int>(X.size()) - 1);
            for (auto& i : idx) i = pick(rng);
            DecisionTree tree;
            tree.fit(X, y, idx, tp, rng);
            for (size_t j = 0; j < nf; ++j) importance_[j] += tree.importance()[j];
            trees_.push_back(std::move(tree));
        }
        double total = std::accumulate(importance_.begin(), importance_.end(), 0.0);
        if (total > 0) for (auto& v : importance_) v /= total;
    }

    double predict_proba(const std::vector<double>& x) const {
        double s = 0.0;
        for (auto& t : trees_) s += t.predict_proba(x);
        return trees_.empty() ? 0.5 : s / static_cast<double>(trees_.size());
    }

    const std::vector<double>& importance() const { return importance_; }
    size_t size() const { return trees_.size(); }

    void save(std::ostream& out) const {
        out << "FOREST " << trees_.size() << "\n";
        for (auto& t : trees_) t.save(out);
    }
    bool load(std::istream& in) {
        std::string tag; size_t n;
        in >> tag >> n;
        if (tag != "FOREST") return false;
        trees_.assign(n, DecisionTree());
        for (auto& t : trees_) if (!t.load(in)) return false;
        return true;
    }

private:
    int n_trees_;
    TreeParams params_;
    unsigned seed_;
    std::vector<DecisionTree> trees_;
    std::vector<double> importance_;
};

}  // namespace tl
