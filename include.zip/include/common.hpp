// common.hpp
// Small helper functions that every other file in TrustLens leans on.
// Nothing fancy here - just the boring-but-necessary string and printing tools.
#pragma once

#include <algorithm>
#include <cctype>
#include <cmath>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <functional>
#include <map>
#include <memory>
#include <mutex>
#include <numeric>
#include <random>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <unordered_set>
#include <utility>
#include <vector>

namespace tl {

inline std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
    while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
    return s.substr(a, b - a);
}

inline std::string to_lower(std::string s) {
    for (auto& c : s) c = static_cast<char>(std::tolower(static_cast<unsigned char>(c)));
    return s;
}

inline std::vector<std::string> split(const std::string& s, char delim) {
    std::vector<std::string> out;
    std::string cur;
    for (char c : s) {
        if (c == delim) { out.push_back(cur); cur.clear(); }
        else cur += c;
    }
    out.push_back(cur);
    return out;
}

inline bool starts_with(const std::string& s, const std::string& p) {
    return s.size() >= p.size() && s.compare(0, p.size(), p) == 0;
}
inline bool ends_with(const std::string& s, const std::string& p) {
    return s.size() >= p.size() && s.compare(s.size() - p.size(), p.size(), p) == 0;
}

inline std::string now_string() {
    std::time_t t = std::time(nullptr);
    char buf[32];
    std::strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", std::localtime(&t));
    return buf;
}

inline void ensure_dir(const std::string& path) {
    std::filesystem::create_directories(path);
}

inline std::string html_escape(const std::string& s) {
    std::string o;
    for (char c : s) {
        switch (c) {
            case '&': o += "&amp;"; break;
            case '<': o += "&lt;"; break;
            case '>': o += "&gt;"; break;
            case '"': o += "&quot;"; break;
            default: o += c;
        }
    }
    return o;
}

// Wrap text in single quotes for SQL, doubling any quote inside it.
inline std::string sql_quote(const std::string& s) {
    std::string o = "'";
    for (char c : s) {
        if (c == '\'') o += "''";
        else o += c;
    }
    o += "'";
    return o;
}

inline std::string fmt(double v, int digits = 4) {
    std::ostringstream os;
    os << std::fixed << std::setprecision(digits) << v;
    return os.str();
}

// ---- pretty console output -------------------------------------------------

inline void banner(const std::string& title) {
    std::cout << "\n" << std::string(70, '=') << "\n  " << title << "\n"
              << std::string(70, '=') << "\n";
}

inline void section(const std::string& title) {
    std::cout << "\n--- " << title << " ---\n";
}

// A tiny text bar, e.g. bar(0.5, 20) -> "##########          "
inline std::string bar(double frac, int width = 30) {
    frac = std::max(0.0, std::min(1.0, frac));
    int n = static_cast<int>(std::round(frac * width));
    return std::string(n, '#') + std::string(width - n, ' ');
}

}  // namespace tl
