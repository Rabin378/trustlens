// http.hpp
// A tiny HTTP/1.1 web server built on plain POSIX sockets (Linux, macOS, WSL).
// No libraries needed. It is intentionally small so you can read and explain it:
//
//   accept a connection -> read the request -> find a matching route
//   -> let the handler fill in a Response -> write it back -> close.
//
// Every connection is served on its own thread. The server answers
// "Connection: close" to keep the logic simple and robust.
#pragma once

#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <csignal>
#include <thread>

#include "common.hpp"

// macOS has no MSG_NOSIGNAL (Linux only). It is not needed there because we ignore
// SIGPIPE ourselves, so we simply define it as "no flag".
#ifndef MSG_NOSIGNAL
#define MSG_NOSIGNAL 0
#endif

namespace tl {

struct Request {
    std::string method, path, body, remote;
    std::map<std::string, std::string> query;     // ?a=1&b=2  (already decoded)
    std::map<std::string, std::string> headers;   // lower-case names

    std::string param(const std::string& k, const std::string& def = "") const {
        auto it = query.find(k);
        return it == query.end() ? def : it->second;
    }
};

struct Response {
    int status = 200;
    std::string content_type = "text/plain; charset=utf-8";
    std::string body;
    std::map<std::string, std::string> headers;

    void json(const std::string& j, int code = 200) {
        status = code; content_type = "application/json; charset=utf-8"; body = j;
    }
    void error(int code, const std::string& message) {
        std::string esc;
        for (char c : message) { if (c == '"' || c == '\\') esc += '\\'; esc += c; }
        json("{\"error\":\"" + esc + "\"}", code);
    }
};

using Handler = std::function<void(const Request&, Response&)>;

inline std::string url_decode(const std::string& s) {
    std::string o;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '%' && i + 2 < s.size() && std::isxdigit(static_cast<unsigned char>(s[i + 1])) &&
            std::isxdigit(static_cast<unsigned char>(s[i + 2]))) {
            o += static_cast<char>(std::stoi(s.substr(i + 1, 2), nullptr, 16));
            i += 2;
        } else if (s[i] == '+') o += ' ';
        else o += s[i];
    }
    return o;
}

inline const char* status_text(int code) {
    switch (code) {
        case 200: return "OK";
        case 204: return "No Content";
        case 400: return "Bad Request";
        case 404: return "Not Found";
        case 405: return "Method Not Allowed";
        case 413: return "Payload Too Large";
        case 500: return "Internal Server Error";
        case 503: return "Service Unavailable";
        default: return "OK";
    }
}

class HttpServer {
public:
    static constexpr size_t kMaxHeader = 16 * 1024;
    static constexpr size_t kMaxBody = 256 * 1024;

    void route(const std::string& method, const std::string& path, Handler h) {
        exact_[method + " " + path] = std::move(h);
    }
    // Matches every path that STARTS with `prefix` (used for /api/data/news/<id>).
    void route_prefix(const std::string& method, const std::string& prefix, Handler h) {
        prefix_.push_back({method, prefix, std::move(h)});
    }
    void fallback(Handler h) { fallback_ = std::move(h); }

    bool serve(const std::string& host, int port) {
        std::signal(SIGPIPE, SIG_IGN);
        int srv = ::socket(AF_INET, SOCK_STREAM, 0);
        if (srv < 0) { std::perror("socket"); return false; }
        int yes = 1;
        setsockopt(srv, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));

        sockaddr_in addr{};
        addr.sin_family = AF_INET;
        addr.sin_port = htons(static_cast<uint16_t>(port));
        if (inet_pton(AF_INET, host.c_str(), &addr.sin_addr) != 1) {
            std::cerr << "Invalid host address: " << host << "\n";
            return false;
        }
        if (::bind(srv, reinterpret_cast<sockaddr*>(&addr), sizeof(addr)) < 0) {
            std::perror("bind (is the port already in use?)");
            return false;
        }
        if (::listen(srv, 64) < 0) { std::perror("listen"); return false; }

        while (true) {
            sockaddr_in cli{};
            socklen_t len = sizeof(cli);
            int fd = ::accept(srv, reinterpret_cast<sockaddr*>(&cli), &len);
            if (fd < 0) continue;
            if (active_ >= 64) { send_simple(fd, 503, "Server busy"); ::close(fd); continue; }
#ifdef SO_NOSIGPIPE   // macOS/BSD: don't die if the browser closes the connection early
            { int one = 1; setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof(one)); }
#endif
            char ip[64] = {0};
            inet_ntop(AF_INET, &cli.sin_addr, ip, sizeof(ip));
            ++active_;
            std::thread([this, fd, remote = std::string(ip)]() {
                handle(fd, remote);
                ::close(fd);
                --active_;
            }).detach();
        }
    }

private:
    struct Prefix { std::string method, prefix; Handler handler; };

    enum class ReadResult { Ok, Bad, TooLarge };

    ReadResult read_request(int fd, Request& req) {
        timeval tv{5, 0};
        setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof(tv));

        std::string buf;
        char tmp[4096];
        size_t header_end = std::string::npos;
        while ((header_end = buf.find("\r\n\r\n")) == std::string::npos) {
            if (buf.size() > kMaxHeader) return ReadResult::TooLarge;
            ssize_t n = ::recv(fd, tmp, sizeof(tmp), 0);
            if (n <= 0) return ReadResult::Bad;
            buf.append(tmp, static_cast<size_t>(n));
        }
        std::string head = buf.substr(0, header_end);
        req.body = buf.substr(header_end + 4);

        std::istringstream hs(head);
        std::string line;
        std::getline(hs, line);
        std::istringstream rl(line);
        std::string target, version;
        rl >> req.method >> target >> version;
        if (req.method.empty() || target.empty()) return ReadResult::Bad;

        size_t qpos = target.find('?');
        req.path = url_decode(target.substr(0, qpos));
        if (qpos != std::string::npos) {
            for (auto& kv : split(target.substr(qpos + 1), '&')) {
                if (kv.empty()) continue;
                size_t eq = kv.find('=');
                std::string k = url_decode(kv.substr(0, eq));
                std::string v = eq == std::string::npos ? "" : url_decode(kv.substr(eq + 1));
                req.query[k] = v;
            }
        }
        while (std::getline(hs, line)) {
            if (!line.empty() && line.back() == '\r') line.pop_back();
            size_t c = line.find(':');
            if (c == std::string::npos) continue;
            req.headers[to_lower(trim(line.substr(0, c)))] = trim(line.substr(c + 1));
        }

        size_t want = 0;
        auto it = req.headers.find("content-length");
        if (it != req.headers.end()) want = static_cast<size_t>(std::atoll(it->second.c_str()));
        if (want > kMaxBody) return ReadResult::TooLarge;
        while (req.body.size() < want) {
            ssize_t n = ::recv(fd, tmp, sizeof(tmp), 0);
            if (n <= 0) return ReadResult::Bad;
            req.body.append(tmp, static_cast<size_t>(n));
        }
        req.body.resize(want);
        return ReadResult::Ok;
    }

    static void send_all(int fd, const std::string& data) {
        size_t sent = 0;
        while (sent < data.size()) {
            ssize_t n = ::send(fd, data.data() + sent, data.size() - sent, MSG_NOSIGNAL);
            if (n <= 0) return;
            sent += static_cast<size_t>(n);
        }
    }

    static void write_response(int fd, const Response& r, bool head_only = false) {
        std::ostringstream o;
        o << "HTTP/1.1 " << r.status << " " << status_text(r.status) << "\r\n"
          << "Content-Type: " << r.content_type << "\r\n"
          << "Content-Length: " << r.body.size() << "\r\n"
          << "Connection: close\r\n"
          << "X-Content-Type-Options: nosniff\r\n"
          << "X-Frame-Options: DENY\r\n"
          << "Referrer-Policy: no-referrer\r\n"
          << "Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:\r\n";
        for (auto& h : r.headers) o << h.first << ": " << h.second << "\r\n";
        o << "\r\n";
        send_all(fd, o.str());
        if (!head_only) send_all(fd, r.body);
    }

    static void send_simple(int fd, int code, const std::string& msg) {
        Response r;
        r.status = code;
        r.body = msg;
        write_response(fd, r);
    }

    void handle(int fd, const std::string& remote) {
        auto t0 = std::chrono::steady_clock::now();
        Request req;
        req.remote = remote;
        ReadResult rr = read_request(fd, req);
        if (rr != ReadResult::Ok) {
            send_simple(fd, rr == ReadResult::TooLarge ? 413 : 400, rr == ReadResult::TooLarge ? "Too large" : "Bad request");
            return;
        }

        Response res;
        const bool is_head = req.method == "HEAD";
        const std::string method = is_head ? "GET" : req.method;
        try {
            auto it = exact_.find(method + " " + req.path);
            if (it != exact_.end()) {
                it->second(req, res);
            } else {
                bool done = false;
                for (auto& p : prefix_) {
                    if (p.method == method && starts_with(req.path, p.prefix)) { p.handler(req, res); done = true; break; }
                }
                if (!done) {
                    if (method != "GET") res.error(405, "Method not allowed");
                    else if (fallback_) fallback_(req, res);
                    else res.error(404, "Not found");
                }
            }
        } catch (const std::exception& e) {
            res.error(500, std::string("Server error: ") + e.what());
        }
        write_response(fd, res, is_head);

        auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();
        std::string line = "  " + req.method + " " + req.path + "  ->  " + std::to_string(res.status) + "  (" +
                           std::to_string(ms) + " ms)\n";
        std::lock_guard<std::mutex> lk(log_mutex_);
        std::cout << line << std::flush;
    }

    std::map<std::string, Handler> exact_;
    std::vector<Prefix> prefix_;
    Handler fallback_;
    std::atomic<int> active_{0};
    std::mutex log_mutex_;
};

}  // namespace tl
