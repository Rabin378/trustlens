// text.hpp
// NLP side of the project: turning raw news text into numbers.
//
//   raw text --> tokens (clean, stop-words removed, light stemming, bigrams)
//            --> TF-IDF vector (sparse)
//            --> + 3 hand-made "writing style" features
//
// IMPORTANT (data leakage!): the vectorizer must be fitted on the TRAINING
// articles only. The test set is only ever *transformed*. That is exactly how
// the code in main.cpp uses it.
#pragma once

#include "common.hpp"

namespace tl {

// A sparse vector is a list of (feature index, value) pairs, sorted by index.
using SparseVec = std::vector<std::pair<int, double>>;

inline const std::unordered_set<std::string>& stopwords() {
    static const std::unordered_set<std::string> sw = {
        "a", "an", "the", "and", "or", "but", "if", "of", "to", "in", "on", "at", "by", "for",
        "with", "about", "as", "is", "are", "was", "were", "be", "been", "being", "it", "its",
        "this", "that", "these", "those", "he", "she", "they", "them", "his", "her", "their",
        "we", "you", "your", "our", "i", "me", "my", "not", "no", "so", "than", "then", "there",
        "from", "into", "out", "up", "down", "over", "under", "again", "very", "can", "will",
        "just", "has", "have", "had", "do", "does", "did", "who", "whom", "which", "what",
        "when", "where", "while", "would", "could", "should", "also", "any", "all", "some",
        "more", "most", "other", "such", "only", "own", "same", "too", "s", "t", "re", "ve"};
    return sw;
}

// Very light "stemmer": chops common English endings. Not perfect, but good
// enough to merge "reports/reported/reporting" and keep the code short.
inline std::string stem(const std::string& w) {
    auto cut = [&](size_t n) { return w.substr(0, w.size() - n); };
    if (w.size() > 6 && ends_with(w, "ing")) return cut(3);
    if (w.size() > 5 && ends_with(w, "ed")) return cut(2);
    if (w.size() > 4 && ends_with(w, "ies")) return cut(3) + "y";
    if (w.size() > 4 && ends_with(w, "es")) return cut(2);
    if (w.size() > 3 && ends_with(w, "s") && !ends_with(w, "ss")) return cut(1);
    return w;
}

// lower-case -> keep letters/digits -> drop stop-words -> stem -> (+ bigrams)
inline std::vector<std::string> tokenize(const std::string& text, bool bigrams = true) {
    std::vector<std::string> words;
    std::string cur;
    auto flush = [&]() {
        if (cur.size() >= 2 && !stopwords().count(cur)) words.push_back(stem(cur));
        cur.clear();
    };
    for (unsigned char c : text) {
        if (std::isalnum(c)) cur += static_cast<char>(std::tolower(c));
        else flush();
    }
    flush();

    std::vector<std::string> tokens = words;
    if (bigrams) {
        for (size_t i = 0; i + 1 < words.size(); ++i) tokens.push_back(words[i] + "_" + words[i + 1]);
    }
    return tokens;
}

// Three tiny stylometric features. Fake news tends to SHOUT, so we measure it.
struct StyleFeatures {
    double exclaim_rate = 0, caps_ratio = 0, length = 0;
};

inline StyleFeatures style_features(const std::string& text) {
    StyleFeatures s;
    double letters = 0, upper = 0, excl = 0, words = 0;
    bool in_word = false;
    for (unsigned char c : text) {
        if (std::isalpha(c)) { ++letters; if (std::isupper(c)) ++upper; }
        if (c == '!') ++excl;
        if (std::isspace(c)) in_word = false;
        else if (!in_word) { in_word = true; ++words; }
    }
    s.exclaim_rate = words > 0 ? std::min(1.0, 5.0 * excl / words) : 0.0;
    s.caps_ratio = letters > 0 ? std::min(1.0, 3.0 * upper / letters) : 0.0;
    s.length = std::min(1.0, words / 300.0);
    return s;
}

class TfidfVectorizer {
public:
    static constexpr int kExtraFeatures = 3;

    // Learn the vocabulary and the IDF weights from training documents only.
    void fit(const std::vector<std::string>& docs, int min_df = 3, int max_features = 3000) {
        std::unordered_map<std::string, int> df;
        for (const auto& d : docs) {
            auto toks = tokenize(d);
            std::unordered_set<std::string> uniq(toks.begin(), toks.end());
            for (const auto& t : uniq) ++df[t];
        }
        std::vector<std::pair<std::string, int>> cand;
        for (auto& kv : df) if (kv.second >= min_df) cand.push_back(kv);
        std::sort(cand.begin(), cand.end(), [](const auto& a, const auto& b) {
            return a.second != b.second ? a.second > b.second : a.first < b.first;
        });
        if (static_cast<int>(cand.size()) > max_features) cand.resize(max_features);

        vocab_.clear(); terms_.clear(); idf_.clear();
        const double n = static_cast<double>(docs.size());
        for (auto& kv : cand) {
            vocab_[kv.first] = static_cast<int>(terms_.size());
            terms_.push_back(kv.first);
            idf_.push_back(std::log((1.0 + n) / (1.0 + kv.second)) + 1.0);  // smooth idf
        }
    }

    SparseVec transform(const std::string& doc) const {
        std::map<int, double> tf;
        for (const auto& t : tokenize(doc)) {
            auto it = vocab_.find(t);
            if (it != vocab_.end()) tf[it->second] += 1.0;
        }
        SparseVec v;
        double norm = 0.0;
        for (auto& kv : tf) {
            double w = (1.0 + std::log(kv.second)) * idf_[kv.first];   // sublinear tf * idf
            v.push_back({kv.first, w});
            norm += w * w;
        }
        norm = std::sqrt(norm);
        if (norm > 0) for (auto& p : v) p.second /= norm;               // L2 normalise

        StyleFeatures s = style_features(doc);
        int base = vocab_size();
        if (s.exclaim_rate > 0) v.push_back({base, s.exclaim_rate});
        if (s.caps_ratio > 0) v.push_back({base + 1, s.caps_ratio});
        if (s.length > 0) v.push_back({base + 2, s.length});
        return v;
    }

    int vocab_size() const { return static_cast<int>(terms_.size()); }
    int dim() const { return vocab_size() + kExtraFeatures; }

    // name of feature j (vocabulary word or style feature)
    std::string feature_name(int j) const {
        if (j < vocab_size()) return terms_[j];
        static const char* extra[kExtraFeatures] = {"<exclamation_rate>", "<caps_ratio>", "<article_length>"};
        return extra[j - vocab_size()];
    }

    void save(const std::string& path) const {
        std::ofstream out(path);
        out << "TFIDF " << terms_.size() << "\n";
        out.precision(10);
        for (size_t i = 0; i < terms_.size(); ++i) out << terms_[i] << " " << idf_[i] << "\n";
    }

    bool load(const std::string& path) {
        std::ifstream in(path);
        if (!in) return false;
        std::string tag; size_t n = 0;
        in >> tag >> n;
        if (tag != "TFIDF") return false;
        vocab_.clear(); terms_.clear(); idf_.clear();
        for (size_t i = 0; i < n; ++i) {
            std::string t; double idf;
            in >> t >> idf;
            vocab_[t] = static_cast<int>(terms_.size());
            terms_.push_back(t);
            idf_.push_back(idf);
        }
        return true;
    }

private:
    std::unordered_map<std::string, int> vocab_;
    std::vector<std::string> terms_;
    std::vector<double> idf_;
};

}  // namespace tl
