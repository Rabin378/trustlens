// json.hpp
// Just enough JSON for this project:
//   * jstr()/jnum()        build JSON text safely (escaping quotes, control characters...)
//   * json_get_string()    read ONE string field out of a flat request body like {"url":"..."}
//
// We do not need a full JSON parser because the website only ever sends tiny,
// flat objects, and everything we send back is built with the helpers below.
#pragma once

#include "common.hpp"

namespace tl {

inline std::string json_escape(const std::string& s) {
    std::string o;
    o.reserve(s.size() + 8);
    for (unsigned char c : s) {
        switch (c) {
            case '"': o += "\\\""; break;
            case '\\': o += "\\\\"; break;
            case '\n': o += "\\n"; break;
            case '\r': o += "\\r"; break;
            case '\t': o += "\\t"; break;
            default:
                if (c < 0x20) { char b[8]; std::snprintf(b, sizeof(b), "\\u%04x", c); o += b; }
                else o += static_cast<char>(c);
        }
    }
    return o;
}

inline std::string jstr(const std::string& s) { return "\"" + json_escape(s) + "\""; }

inline std::string jnum(double v) {
    if (!std::isfinite(v)) return "null";
    std::ostringstream os;
    os.precision(10);
    os << v;
    return os.str();
}

inline std::string jbool(bool b) { return b ? "true" : "false"; }

inline void append_utf8(std::string& out, unsigned cp) {
    if (cp < 0x80) out += static_cast<char>(cp);
    else if (cp < 0x800) { out += static_cast<char>(0xC0 | (cp >> 6)); out += static_cast<char>(0x80 | (cp & 0x3F)); }
    else if (cp < 0x10000) {
        out += static_cast<char>(0xE0 | (cp >> 12));
        out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
        out += static_cast<char>(0x80 | (cp & 0x3F));
    } else {
        out += static_cast<char>(0xF0 | (cp >> 18));
        out += static_cast<char>(0x80 | ((cp >> 12) & 0x3F));
        out += static_cast<char>(0x80 | ((cp >> 6) & 0x3F));
        out += static_cast<char>(0x80 | (cp & 0x3F));
    }
}

// Finds  "key": "value"  in a flat JSON object and returns the unescaped value.
inline bool json_get_string(const std::string& body, const std::string& key, std::string& out) {
    std::string needle = "\"" + key + "\"";
    size_t p = body.find(needle);
    if (p == std::string::npos) return false;
    p = body.find(':', p + needle.size());
    if (p == std::string::npos) return false;
    ++p;
    while (p < body.size() && std::isspace(static_cast<unsigned char>(body[p]))) ++p;
    if (p >= body.size() || body[p] != '"') return false;
    ++p;
    out.clear();
    while (p < body.size()) {
        char c = body[p];
        if (c == '"') return true;
        if (c == '\\' && p + 1 < body.size()) {
            char n = body[++p];
            switch (n) {
                case 'n': out += '\n'; break;
                case 't': out += '\t'; break;
                case 'r': out += '\r'; break;
                case 'b': out += '\b'; break;
                case 'f': out += '\f'; break;
                case 'u': {
                    if (p + 4 < body.size()) {
                        unsigned cp = static_cast<unsigned>(std::stoul(body.substr(p + 1, 4), nullptr, 16));
                        p += 4;
                        if (cp >= 0xD800 && cp < 0xDC00 && p + 6 < body.size() && body[p + 1] == '\\' && body[p + 2] == 'u') {
                            unsigned lo = static_cast<unsigned>(std::stoul(body.substr(p + 3, 4), nullptr, 16));
                            cp = 0x10000 + ((cp - 0xD800) << 10) + (lo - 0xDC00);
                            p += 6;
                        }
                        append_utf8(out, cp);
                    }
                    break;
                }
                default: out += n;
            }
        } else out += c;
        ++p;
    }
    return false;   // unterminated string
}

}  // namespace tl
