// url_features.hpp
// FEATURE ENGINEERING for the phishing task.
//
// A machine learning model cannot read a URL string, so we turn every URL into a
// row of 21 numbers. Each number is a "red flag" that security researchers have
// repeatedly found useful: raw IP addresses, '@' tricks, too many subdomains,
// shady TLDs, brand names living in the wrong place, and so on.
#pragma once

#include "common.hpp"

namespace tl {

struct ParsedUrl {
    std::string scheme, host, path, query, registered_domain, tld;
    bool has_port = false;
    bool is_ip = false;
    std::vector<std::string> labels;  // host split on '.'
};

inline bool all_digits(const std::string& s) {
    return !s.empty() && std::all_of(s.begin(), s.end(), [](unsigned char c) { return std::isdigit(c); });
}

inline ParsedUrl parse_url(const std::string& raw) {
    ParsedUrl u;
    std::string s = to_lower(trim(raw));

    size_t p = s.find("://");
    std::string rest;
    if (p != std::string::npos) { u.scheme = s.substr(0, p); rest = s.substr(p + 3); }
    else rest = s;

    size_t auth_end = rest.find_first_of("/?#");
    std::string authority = auth_end == std::string::npos ? rest : rest.substr(0, auth_end);
    std::string tail = auth_end == std::string::npos ? "" : rest.substr(auth_end);

    // user:pass@host  -> keep only what's after the last '@'
    size_t at = authority.rfind('@');
    if (at != std::string::npos) authority = authority.substr(at + 1);

    size_t colon = authority.find(':');
    if (colon != std::string::npos) { u.has_port = true; authority = authority.substr(0, colon); }
    u.host = authority;

    size_t q = tail.find('?');
    size_t h = tail.find('#');
    size_t path_end = std::min(q == std::string::npos ? tail.size() : q, h == std::string::npos ? tail.size() : h);
    u.path = tail.substr(0, path_end);
    if (q != std::string::npos) u.query = tail.substr(q + 1, (h == std::string::npos ? tail.size() : h) - q - 1);

    u.labels = split(u.host, '.');
    u.tld = u.labels.empty() ? "" : u.labels.back();

    u.is_ip = u.labels.size() == 4 &&
              std::all_of(u.labels.begin(), u.labels.end(),
                          [](const std::string& l) { return all_digits(l) && l.size() <= 3; });

    // registered domain: last two labels (three for things like example.co.uk)
    size_t n = u.labels.size();
    if (n >= 2) {
        static const std::set<std::string> second_level = {"co", "com", "org", "net", "ac", "gov", "edu"};
        bool three = n >= 3 && u.labels[n - 1].size() == 2 && second_level.count(u.labels[n - 2]);
        size_t take = three ? 3 : 2;
        for (size_t i = n - take; i < n; ++i) u.registered_domain += (i == n - take ? "" : ".") + u.labels[i];
    } else {
        u.registered_domain = u.host;
    }
    return u;
}

inline double shannon_entropy(const std::string& s) {
    if (s.empty()) return 0.0;
    std::map<char, int> freq;
    for (char c : s) ++freq[c];
    double h = 0.0;
    for (auto& kv : freq) {
        double p = static_cast<double>(kv.second) / s.size();
        h -= p * std::log2(p);
    }
    return h;
}

// The names must stay in the SAME ORDER as the values returned below.
// They are also used as column names in the SQL table `url_features`.
inline const std::vector<std::string>& url_feature_names() {
    static const std::vector<std::string> names = {
        "url_length", "host_length", "path_length", "num_dots", "num_hyphens_host",
        "num_digits", "digit_ratio", "num_subdomains", "has_ip_host", "has_at_symbol",
        "uses_https", "num_query_params", "has_port", "keyword_count", "is_shortener",
        "suspicious_tld", "host_entropy", "double_slash_in_path", "num_special_chars",
        "brand_mismatch", "path_depth"};
    return names;
}

inline std::vector<double> extract_url_features(const std::string& raw_url) {
    const std::string url = to_lower(trim(raw_url));
    const ParsedUrl u = parse_url(url);

    static const std::vector<std::string> keywords = {
        "login", "verify", "secure", "account", "update", "confirm", "signin",
        "password", "banking", "wallet", "billing", "support"};
    static const std::set<std::string> shorteners = {"bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly"};
    static const std::set<std::string> bad_tlds = {
        "xyz", "top", "tk", "ml", "ga", "cf", "gq", "click", "work", "online", "site", "ru", "cn", "zip"};
    static const std::vector<std::string> brands = {
        "paypal", "apple", "google", "amazon", "microsoft", "netflix", "facebook",
        "instagram", "dropbox", "linkedin", "ebay", "chase", "wellsfargo", "dhl"};

    double digits = static_cast<double>(std::count_if(url.begin(), url.end(),
                                        [](unsigned char c) { return std::isdigit(c); }));

    double dots = static_cast<double>(std::count(url.begin(), url.end(), '.'));
    double hyphens_host = static_cast<double>(std::count(u.host.begin(), u.host.end(), '-'));

    // how many labels sit in front of the registered domain?
    double subdomains = 0;
    if (!u.is_ip) {
        size_t reg_labels = split(u.registered_domain, '.').size();
        subdomains = u.labels.size() > reg_labels ? static_cast<double>(u.labels.size() - reg_labels) : 0.0;
    }

    double query_params = 0;
    if (!u.query.empty()) query_params = static_cast<double>(std::count(u.query.begin(), u.query.end(), '&')) + 1.0;

    double kw = 0;
    for (const auto& k : keywords) if (url.find(k) != std::string::npos) kw += 1.0;

    double special = 0;
    for (char c : url) if (c == '%' || c == '=' || c == '&' || c == '_' || c == '~' || c == '#') special += 1.0;

    double path_depth = static_cast<double>(std::count(u.path.begin(), u.path.end(), '/'));

    // A brand name appears somewhere in the URL, but the real owner's domain
    // (brand.com) is NOT the registered domain. Classic impersonation.
    double mismatch = 0;
    for (const auto& b : brands) {
        if (url.find(b) != std::string::npos && u.registered_domain != b + ".com") { mismatch = 1; break; }
    }

    std::vector<double> f;
    f.push_back(static_cast<double>(url.size()));                                     // url_length
    f.push_back(static_cast<double>(u.host.size()));                                  // host_length
    f.push_back(static_cast<double>(u.path.size()));                                  // path_length
    f.push_back(dots);                                                                // num_dots
    f.push_back(hyphens_host);                                                        // num_hyphens_host
    f.push_back(digits);                                                              // num_digits
    f.push_back(url.empty() ? 0.0 : digits / static_cast<double>(url.size()));        // digit_ratio
    f.push_back(subdomains);                                                          // num_subdomains
    f.push_back(u.is_ip ? 1.0 : 0.0);                                                 // has_ip_host
    f.push_back(url.find('@') != std::string::npos ? 1.0 : 0.0);                      // has_at_symbol
    f.push_back(u.scheme == "https" ? 1.0 : 0.0);                                     // uses_https
    f.push_back(query_params);                                                        // num_query_params
    f.push_back(u.has_port ? 1.0 : 0.0);                                              // has_port
    f.push_back(kw);                                                                  // keyword_count
    f.push_back(shorteners.count(u.registered_domain) ? 1.0 : 0.0);                   // is_shortener
    f.push_back(bad_tlds.count(u.tld) ? 1.0 : 0.0);                                   // suspicious_tld
    f.push_back(shannon_entropy(u.host));                                             // host_entropy
    f.push_back(u.path.find("//") != std::string::npos ? 1.0 : 0.0);                  // double_slash_in_path
    f.push_back(special);                                                             // num_special_chars
    f.push_back(mismatch);                                                            // brand_mismatch
    f.push_back(path_depth);                                                          // path_depth
    return f;
}

// Human-friendly explanation: which red flags fired for this URL?
inline std::vector<std::string> url_red_flags(const std::vector<double>& f) {
    const auto& n = url_feature_names();
    auto v = [&](const std::string& name) {
        for (size_t i = 0; i < n.size(); ++i) if (n[i] == name) return f[i];
        return 0.0;
    };
    std::vector<std::string> out;
    if (v("has_ip_host") > 0) out.push_back("uses a raw IP address instead of a domain name");
    if (v("has_at_symbol") > 0) out.push_back("contains an '@' symbol (can hide the real destination)");
    if (v("uses_https") == 0) out.push_back("does not use HTTPS");
    if (v("is_shortener") > 0) out.push_back("is a shortened link - the real target is hidden");
    if (v("suspicious_tld") > 0) out.push_back("ends with a top-level domain often abused by scammers");
    if (v("keyword_count") >= 2) out.push_back("contains several 'urgent account' words (login, verify, secure...)");
    if (v("brand_mismatch") > 0) out.push_back("mentions a famous brand but is not on that brand's real domain");
    if (v("num_subdomains") >= 3) out.push_back("has many subdomains stacked in front of the domain");
    if (v("num_hyphens_host") >= 2) out.push_back("has several hyphens in the hostname");
    if (v("url_length") > 75) out.push_back("is unusually long");
    return out;
}

}  // namespace tl
